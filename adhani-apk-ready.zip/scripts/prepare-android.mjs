// Usage:  node scripts/prepare-android.mjs check   → verifies the adhan audio files exist (fails the build if not)
//         node scripts/prepare-android.mjs patch   → run after `npx cap add android` (manifest, sounds, icon, signing)
import fs from 'node:fs';
import path from 'node:path';

const mode = process.argv[2];
const soundsDir = 'public/sounds';
const cfg = fs.readFileSync('src/config/adhanSounds.ts', 'utf8');
const files = [...cfg.matchAll(/src:\s*'sounds\/([^']+)'/g)].map((m) => m[1]);

if (mode === 'check') {
  const missing = files.filter((f) => !fs.existsSync(path.join(soundsDir, f)));
  if (missing.length) {
    console.error('\n❌ ملفات الأذان ناقصة في public/sounds/ :\n   ' + missing.join('\n   '));
    console.error('\nارفعها على GitHub بنفس الأسماء بالظبط (حروف إنجليزي صغيرة)، ثم أعد تشغيل الـ workflow.\n');
    process.exit(1);
  }
  console.log('✓ كل ملفات الأذان موجودة:', files.join(', '));
}

if (mode === 'patch') {
  const app = 'android/app';
  // 1) permissions
  const mp = `${app}/src/main/AndroidManifest.xml`;
  let m = fs.readFileSync(mp, 'utf8');
  const perms = [
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
    '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />',
    '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />',
    '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
    '<uses-permission android:name="android.permission.VIBRATE" />',
    '<uses-permission android:name="android.permission.WAKE_LOCK" />',
    '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
    '<uses-feature android:name="android.hardware.location.gps" android:required="false" />',
  ].filter((p) => !m.includes(p.match(/android:name="([^"]+)"/)[1]));
  if (perms.length) m = m.replace('<application', perms.join('\n    ') + '\n\n    <application');
  fs.writeFileSync(mp, m);

  // 2) adhan audio → res/raw (used by notification channels when the app is closed)
  const raw = `${app}/src/main/res/raw`;
  fs.mkdirSync(raw, { recursive: true });
  for (const f of files) fs.copyFileSync(path.join(soundsDir, f), path.join(raw, f));

  // 3) status-bar notification icon (white crescent)
  const dr = `${app}/src/main/res/drawable`;
  fs.mkdirSync(dr, { recursive: true });
  fs.writeFileSync(
    `${dr}/ic_stat_adhan.xml`,
    `<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:fillColor="#FFFFFFFF" android:pathData="M12,3a9,9 0 1,0 9,9c0,-0.46 -0.04,-0.92 -0.1,-1.36a5.389,5.389 0 0,1 -4.4,2.26 5.403,5.403 0 0,1 -3.14,-9.8c-0.44,-0.06 -0.9,-0.1 -1.36,-0.1z"/></vector>`
  );

  // 4) fixed signing key → every build is signed the same, so new APKs install OVER the old one (data kept)
  fs.copyFileSync('keystore/adhani.keystore', `${app}/adhani.keystore`);
  const gp = `${app}/build.gradle`;
  let g = fs.readFileSync(gp, 'utf8');
  if (!g.includes('adhani.keystore')) {
    g = g.replace(
      /buildTypes\s*\{/,
      `signingConfigs {\n        release {\n            storeFile file('adhani.keystore')\n            storePassword 'adhani123'\n            keyAlias 'adhani'\n            keyPassword 'adhani123'\n        }\n    }\n    buildTypes {`
    );
    g = g.replace(/release\s*\{(\s*)minifyEnabled/, `release {$1signingConfig signingConfigs.release\n            minifyEnabled`);
    fs.writeFileSync(gp, g);
  }
  console.log('✓ android patched');
}
