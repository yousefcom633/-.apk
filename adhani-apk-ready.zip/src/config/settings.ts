// Prayer / alert settings model + defaults (Domain layer).
import type { AlertMode, PrayerKey, Rec5 } from '../lib/types';

export const METHODS = [
  { id: 'egyptian', name: 'الهيئة المصرية العامة للمساحة' },
  { id: 'ummalqura', name: 'أم القرى (مكة المكرمة)' },
  { id: 'mwl', name: 'رابطة العالم الإسلامي' },
  { id: 'karachi', name: 'جامعة العلوم الإسلامية - كراتشي' },
  { id: 'dubai', name: 'دبي' },
  { id: 'kuwait', name: 'الكويت' },
  { id: 'qatar', name: 'قطر' },
  { id: 'singapore', name: 'سنغافورة' },
  { id: 'turkey', name: 'رئاسة الشؤون الدينية - تركيا' },
  { id: 'northamerica', name: 'أمريكا الشمالية (ISNA)' },
  { id: 'moonsighting', name: 'لجنة رؤية الهلال' },
  { id: 'tehran', name: 'معهد الجيوفيزياء - طهران' },
] as const;
export type MethodId = (typeof METHODS)[number]['id'];

export const VIBRATIONS: Record<string, { name: string; pattern: number[] }> = {
  none: { name: 'بدون اهتزاز', pattern: [] },
  short: { name: 'قصير', pattern: [250] },
  long: { name: 'طويل', pattern: [900] },
  pulse: { name: 'نبضات', pattern: [200, 120, 200, 120, 200] },
  wave: { name: 'موجة', pattern: [100, 60, 220, 60, 400, 60, 220, 60, 100] },
};

export interface Settings {
  method: MethodId;
  madhab: 'shafi' | 'hanafi';
  location: {
    mode: 'gps' | 'city';
    lat: number;
    lon: number;
    name: string;
    tz: string;
    cityId: string;
  };
  /** Manual minute adjustment per time (+/-) to match the local mosque. */
  adjust: Record<PrayerKey, number>;
  modes: Rec5<AlertMode>;
  /** 'auto' → Fajr uses fajrSoundId, others use defaultSoundId. */
  sounds: Rec5<string>;
  defaultSoundId: string;
  fajrSoundId: string;
  volume: number;
  gradual: boolean;
  vibration: string;
  iqamaMin: Rec5<number>;
  iqamaReminder: boolean;
  iqamaBefore: number;
  endReminder: boolean;
  endReminderMin: number;
  quietAfter: boolean;
  quietMinutes: number;
  showAdhkar: boolean;
  fridayReminder: boolean;
  kahfReminder: boolean;
  ramadanMode: boolean;
  preFajrMin: number;
  keepAwake: boolean;
  hijriOffset: number;
}

export const DEFAULT_SETTINGS: Settings = {
  method: 'egyptian',
  madhab: 'shafi',
  location: { mode: 'city', lat: 30.0444, lon: 31.2357, name: 'القاهرة', tz: 'Africa/Cairo', cityId: 'cairo' },
  adjust: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  modes: { fajr: 'full', dhuhr: 'full', asr: 'full', maghrib: 'full', isha: 'full' },
  sounds: { fajr: 'auto', dhuhr: 'auto', asr: 'auto', maghrib: 'auto', isha: 'auto' },
  defaultSoundId: 'afasy',
  fajrSoundId: 'fajr-salah',
  volume: 0.8,
  gradual: true,
  vibration: 'pulse',
  iqamaMin: { fajr: 20, dhuhr: 15, asr: 15, maghrib: 10, isha: 15 },
  iqamaReminder: true,
  iqamaBefore: 5,
  endReminder: false,
  endReminderMin: 20,
  quietAfter: false,
  quietMinutes: 15,
  showAdhkar: true,
  fridayReminder: true,
  kahfReminder: false,
  ramadanMode: true,
  preFajrMin: 45,
  keepAwake: false,
  hijriOffset: 0,
};
