// Offline city database used as the manual-location fallback and for offline reverse lookup of GPS.
// Format: [id, Arabic name, latitude, longitude, IANA timezone]
export interface City {
  id: string;
  name: string;
  lat: number;
  lon: number;
  tz: string;
}

const RAW: [string, string, number, number, string][] = [
  ['cairo', 'القاهرة', 30.0444, 31.2357, 'Africa/Cairo'],
  ['alex', 'الإسكندرية', 31.2001, 29.9187, 'Africa/Cairo'],
  ['giza', 'الجيزة', 30.0131, 31.2089, 'Africa/Cairo'],
  ['mansoura', 'المنصورة', 31.0409, 31.3785, 'Africa/Cairo'],
  ['tanta', 'طنطا', 30.7865, 31.0004, 'Africa/Cairo'],
  ['assiut', 'أسيوط', 27.1783, 31.1859, 'Africa/Cairo'],
  ['luxor', 'الأقصر', 25.6872, 32.6396, 'Africa/Cairo'],
  ['aswan', 'أسوان', 24.0889, 32.8998, 'Africa/Cairo'],
  ['portsaid', 'بورسعيد', 31.2653, 32.3019, 'Africa/Cairo'],
  ['suez', 'السويس', 29.9668, 32.5498, 'Africa/Cairo'],
  ['ismailia', 'الإسماعيلية', 30.5965, 32.2715, 'Africa/Cairo'],
  ['sharm', 'شرم الشيخ', 27.9158, 34.33, 'Africa/Cairo'],
  ['hurghada', 'الغردقة', 27.2579, 33.8116, 'Africa/Cairo'],
  ['fayoum', 'الفيوم', 29.3084, 30.8428, 'Africa/Cairo'],
  ['damietta', 'دمياط', 31.4165, 31.8133, 'Africa/Cairo'],
  ['makkah', 'مكة المكرمة', 21.3891, 39.8579, 'Asia/Riyadh'],
  ['madinah', 'المدينة المنورة', 24.5247, 39.5692, 'Asia/Riyadh'],
  ['riyadh', 'الرياض', 24.7136, 46.6753, 'Asia/Riyadh'],
  ['jeddah', 'جدة', 21.4858, 39.1925, 'Asia/Riyadh'],
  ['dammam', 'الدمام', 26.4207, 50.0888, 'Asia/Riyadh'],
  ['taif', 'الطائف', 21.2703, 40.4158, 'Asia/Riyadh'],
  ['abha', 'أبها', 18.2164, 42.5053, 'Asia/Riyadh'],
  ['tabuk', 'تبوك', 28.3838, 36.555, 'Asia/Riyadh'],
  ['dubai', 'دبي', 25.2048, 55.2708, 'Asia/Dubai'],
  ['abudhabi', 'أبوظبي', 24.4539, 54.3773, 'Asia/Dubai'],
  ['sharjah', 'الشارقة', 25.3463, 55.4209, 'Asia/Dubai'],
  ['kuwait', 'الكويت', 29.3759, 47.9774, 'Asia/Kuwait'],
  ['doha', 'الدوحة', 25.2854, 51.531, 'Asia/Qatar'],
  ['manama', 'المنامة', 26.2285, 50.586, 'Asia/Bahrain'],
  ['muscat', 'مسقط', 23.588, 58.3829, 'Asia/Muscat'],
  ['sanaa', 'صنعاء', 15.3694, 44.191, 'Asia/Aden'],
  ['aden', 'عدن', 12.7855, 45.0187, 'Asia/Aden'],
  ['amman', 'عمّان', 31.9454, 35.9284, 'Asia/Amman'],
  ['jerusalem', 'القدس', 31.7683, 35.2137, 'Asia/Jerusalem'],
  ['gaza', 'غزة', 31.5017, 34.4668, 'Asia/Gaza'],
  ['ramallah', 'رام الله', 31.9038, 35.2034, 'Asia/Hebron'],
  ['beirut', 'بيروت', 33.8938, 35.5018, 'Asia/Beirut'],
  ['damascus', 'دمشق', 33.5138, 36.2765, 'Asia/Damascus'],
  ['aleppo', 'حلب', 36.2021, 37.1343, 'Asia/Damascus'],
  ['baghdad', 'بغداد', 33.3152, 44.3661, 'Asia/Baghdad'],
  ['basra', 'البصرة', 30.5081, 47.7835, 'Asia/Baghdad'],
  ['erbil', 'أربيل', 36.1912, 44.0092, 'Asia/Baghdad'],
  ['tripoli', 'طرابلس (ليبيا)', 32.8872, 13.1913, 'Africa/Tripoli'],
  ['benghazi', 'بنغازي', 32.1167, 20.0667, 'Africa/Tripoli'],
  ['tunis', 'تونس', 36.8065, 10.1815, 'Africa/Tunis'],
  ['algiers', 'الجزائر', 36.7538, 3.0588, 'Africa/Algiers'],
  ['oran', 'وهران', 35.6971, -0.6308, 'Africa/Algiers'],
  ['rabat', 'الرباط', 34.0209, -6.8416, 'Africa/Casablanca'],
  ['casablanca', 'الدار البيضاء', 33.5731, -7.5898, 'Africa/Casablanca'],
  ['marrakesh', 'مراكش', 31.6295, -7.9811, 'Africa/Casablanca'],
  ['fes', 'فاس', 34.0331, -5.0003, 'Africa/Casablanca'],
  ['nouakchott', 'نواكشوط', 18.0735, -15.9582, 'Africa/Nouakchott'],
  ['khartoum', 'الخرطوم', 15.5007, 32.5599, 'Africa/Khartoum'],
  ['mogadishu', 'مقديشو', 2.0469, 45.3182, 'Africa/Mogadishu'],
  ['djibouti', 'جيبوتي', 11.5721, 43.1456, 'Africa/Djibouti'],
  ['istanbul', 'إسطنبول', 41.0082, 28.9784, 'Europe/Istanbul'],
  ['ankara', 'أنقرة', 39.9334, 32.8597, 'Europe/Istanbul'],
  ['london', 'لندن', 51.5074, -0.1278, 'Europe/London'],
  ['paris', 'باريس', 48.8566, 2.3522, 'Europe/Paris'],
  ['berlin', 'برلين', 52.52, 13.405, 'Europe/Berlin'],
  ['madrid', 'مدريد', 40.4168, -3.7038, 'Europe/Madrid'],
  ['newyork', 'نيويورك', 40.7128, -74.006, 'America/New_York'],
  ['toronto', 'تورنتو', 43.6532, -79.3832, 'America/Toronto'],
  ['losangeles', 'لوس أنجلوس', 34.0522, -118.2437, 'America/Los_Angeles'],
  ['karachi', 'كراتشي', 24.8607, 67.0011, 'Asia/Karachi'],
  ['islamabad', 'إسلام آباد', 33.6844, 73.0479, 'Asia/Karachi'],
  ['jakarta', 'جاكرتا', -6.2088, 106.8456, 'Asia/Jakarta'],
  ['kualalumpur', 'كوالالمبور', 3.139, 101.6869, 'Asia/Kuala_Lumpur'],
  ['dhaka', 'دكا', 23.8103, 90.4125, 'Asia/Dhaka'],
  ['tehran', 'طهران', 35.6892, 51.389, 'Asia/Tehran'],
  ['sydney', 'سيدني', -33.8688, 151.2093, 'Australia/Sydney'],
];

export const CITIES: City[] = RAW.map(([id, name, lat, lon, tz]) => ({ id, name, lat, lon, tz }));

export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/** Offline reverse geocoding: nearest known city within 60 km, otherwise null. */
export function nearestCity(lat: number, lon: number): City | null {
  let best: City | null = null, bd = Infinity;
  for (const c of CITIES) {
    const d = distanceKm(lat, lon, c.lat, c.lon);
    if (d < bd) { bd = d; best = c; }
  }
  return best && bd <= 60 ? best : null;
}
