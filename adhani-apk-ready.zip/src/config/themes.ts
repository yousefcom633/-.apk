// Central ThemeState: every color / font / size in the app is read from here. No hard-coded values in screens.
import { isColor, norm } from '../lib/color';
import type { DigitMode, PrayerKey, Weight } from '../lib/types';
import { ALL_KEYS } from '../lib/types';

export const COLOR_KEYS = [
  'bgStart', 'bgEnd', 'stars', 'crescent', 'card', 'textPrimary', 'textSecondary',
  'accent', 'ring', 'nextGlow', 'icons', 'button', 'notif',
] as const;
export type ColorKey = (typeof COLOR_KEYS)[number];

export const COLOR_META: Record<ColorKey, { label: string; group: string }> = {
  bgStart: { label: 'بداية تدرّج الخلفية', group: 'الخلفية' },
  bgEnd: { label: 'نهاية تدرّج الخلفية', group: 'الخلفية' },
  stars: { label: 'لون النجوم', group: 'الخلفية' },
  crescent: { label: 'لون الهلال', group: 'الخلفية' },
  card: { label: 'لون البطاقات وشفافيتها', group: 'البطاقات' },
  textPrimary: { label: 'النص الأساسي', group: 'النصوص' },
  textSecondary: { label: 'النص الثانوي', group: 'النصوص' },
  accent: { label: 'لون التمييز', group: 'العناصر' },
  ring: { label: 'حلقة العدّاد', group: 'العناصر' },
  nextGlow: { label: 'إضاءة الصلاة الجاية', group: 'العناصر' },
  icons: { label: 'الأيقونات', group: 'العناصر' },
  button: { label: 'الأزرار', group: 'العناصر' },
  notif: { label: 'لون الإشعار', group: 'العناصر' },
};

export type Colors = Record<ColorKey, string>;

export interface ThemeState {
  colors: Colors;
  fonts: { heading: string; body: string; numbers: string; widget: string };
  fontScale: number;
  fontWeight: Weight;
  bg: {
    type: 'gradient' | 'solid' | 'image';
    imageId: string;
    blur: number;
    dim: number;
    timeTint: boolean;
  };
  stars: { on: boolean; density: number; speed: number; size: number };
  crescent: { on: boolean; pos: 'right' | 'left' | 'center' };
  card: { style: 'glass' | 'solid' | 'transparent'; radius: number; border: number; blur: number };
  counter: 'ring' | 'bar' | 'digits';
  digits: DigitMode;
  hour12: boolean;
  hidden: Record<PrayerKey, boolean>;
  homeOrder: string[];
}

export const HOME_SECTIONS: Record<string, string> = {
  header: 'التاريخ والمدينة',
  countdown: 'العدّ التنازلي',
  cards: 'بطاقات الصلوات',
  extras: 'التنبيهات الإضافية',
};

const NIGHT: Colors = {
  bgStart: '#0b1026ff',
  bgEnd: '#1b2a5cff',
  stars: '#ffffffff',
  crescent: '#e8c877ff',
  card: '#ffffff14',
  textPrimary: '#f4f7ffff',
  textSecondary: '#a9b8e0ff',
  accent: '#8fb8ffff',
  ring: '#8fb8ffff',
  nextGlow: '#e8c877ff',
  icons: '#8fb8ffff',
  button: '#8fb8ffff',
  notif: '#e8c877ff',
};

export const DEFAULT_THEME: ThemeState = {
  colors: NIGHT,
  fonts: { heading: 'cairo', body: 'cairo', numbers: 'cairo', widget: 'cairo' },
  fontScale: 1,
  fontWeight: 'normal',
  bg: { type: 'gradient', imageId: '', blur: 8, dim: 0.35, timeTint: true },
  stars: { on: true, density: 0.5, speed: 0.3, size: 1 },
  crescent: { on: true, pos: 'left' },
  card: { style: 'glass', radius: 22, border: 1, blur: 14 },
  counter: 'ring',
  digits: 'arabic',
  hour12: true,
  hidden: { fajr: false, sunrise: false, dhuhr: false, asr: false, maghrib: false, isha: false },
  homeOrder: ['header', 'countdown', 'cards', 'extras'],
};

export interface ThemePreset {
  id: string;
  name: string;
  colors: Colors;
  stars?: Partial<ThemeState['stars']>;
}

const c = (o: Partial<Colors>): Colors => ({ ...NIGHT, ...o });

export const PRESETS: ThemePreset[] = [
  { id: 'night', name: 'نيلي ليلي', colors: NIGHT },
  {
    id: 'amoled',
    name: 'AMOLED أسود',
    colors: c({ bgStart: '#000000ff', bgEnd: '#050508ff', card: '#ffffff10', textSecondary: '#9aa3bfff' }),
  },
  {
    id: 'green',
    name: 'أخضر هادي',
    colors: c({
      bgStart: '#06201aff', bgEnd: '#0f4a3aff', accent: '#7fe0b0ff', ring: '#7fe0b0ff', icons: '#7fe0b0ff',
      button: '#7fe0b0ff', textPrimary: '#effff8ff', textSecondary: '#a6cdbfff',
    }),
  },
  {
    id: 'gold',
    name: 'ذهبي فخم',
    colors: c({
      bgStart: '#1a1206ff', bgEnd: '#3a2a0cff', accent: '#e8c877ff', ring: '#e8c877ff', icons: '#e8c877ff',
      button: '#e8c877ff', nextGlow: '#ffd98aff', textPrimary: '#fff6e0ff', textSecondary: '#cdb98aff',
      card: '#e8c87718', stars: '#ffe9a8ff', crescent: '#f6d98bff',
    }),
  },
  {
    id: 'purple',
    name: 'بنفسجي',
    colors: c({
      bgStart: '#150b2eff', bgEnd: '#3a1b6eff', accent: '#c6a8ffff', ring: '#c6a8ffff', icons: '#c6a8ffff',
      button: '#c6a8ffff', nextGlow: '#ff9ad5ff', textPrimary: '#f6f0ffff', textSecondary: '#bba9e0ff',
    }),
  },
  {
    id: 'light',
    name: 'فاتح',
    colors: c({
      bgStart: '#f5f7ffff', bgEnd: '#dce6ffff', stars: '#2f5fd0ff', crescent: '#c9a13dff', card: '#ffffffb3',
      textPrimary: '#111936ff', textSecondary: '#4a5578ff', accent: '#2f5fd0ff', ring: '#2f5fd0ff',
      nextGlow: '#c9a13dff', icons: '#2f5fd0ff', button: '#2f5fd0ff', notif: '#c9a13dff',
    }),
    stars: { density: 0.25 },
  },
];

// ── Validation (used when importing a theme from JSON or restoring a backup) ──
const num = (v: unknown, min: number, max: number, def: number) =>
  typeof v === 'number' && isFinite(v) ? Math.min(max, Math.max(min, v)) : def;
const oneOf = <T extends string>(v: unknown, list: readonly T[], def: T): T =>
  typeof v === 'string' && (list as readonly string[]).includes(v) ? (v as T) : def;
const bool = (v: unknown, def: boolean) => (typeof v === 'boolean' ? v : def);
const isRec = (v: unknown): v is Record<string, any> => !!v && typeof v === 'object' && !Array.isArray(v);

/**
 * Turns untrusted data into a safe ThemeState. Throws an Error with an Arabic message
 * when the file is not a theme at all, so the UI can show it without crashing.
 */
export function sanitizeTheme(input: unknown): ThemeState {
  let raw: unknown = input;
  if (isRec(raw) && isRec(raw.theme)) raw = raw.theme;
  if (!isRec(raw)) throw new Error('الملف ليس ثيمًا صالحًا');
  if (!isRec(raw.colors)) throw new Error('الملف لا يحتوي على ألوان الثيم');
  const colors = { ...DEFAULT_THEME.colors };
  let valid = 0;
  for (const k of COLOR_KEYS) {
    const v = raw.colors[k];
    if (isColor(v)) {
      colors[k] = norm(v);
      valid++;
    }
  }
  if (!valid) throw new Error('لا توجد ألوان صالحة داخل الملف');
  const d = DEFAULT_THEME;
  const f = isRec(raw.fonts) ? raw.fonts : {};
  const str = (v: unknown, def: string) => (typeof v === 'string' && v.length < 60 ? v : def);
  const bg = isRec(raw.bg) ? raw.bg : {};
  const st = isRec(raw.stars) ? raw.stars : {};
  const cr = isRec(raw.crescent) ? raw.crescent : {};
  const cd = isRec(raw.card) ? raw.card : {};
  const hidden = { ...d.hidden };
  if (isRec(raw.hidden)) for (const k of ALL_KEYS) hidden[k] = bool(raw.hidden[k], false);
  let order = Array.isArray(raw.homeOrder) ? raw.homeOrder.filter((x: unknown) => typeof x === 'string' && x in HOME_SECTIONS) : [];
  for (const k of Object.keys(HOME_SECTIONS)) if (!order.includes(k)) order.push(k);
  order = Array.from(new Set(order));
  return {
    colors,
    fonts: {
      heading: str(f.heading, d.fonts.heading),
      body: str(f.body, d.fonts.body),
      numbers: str(f.numbers, d.fonts.numbers),
      widget: str(f.widget, d.fonts.widget),
    },
    fontScale: num(raw.fontScale, 0.8, 1.4, 1),
    fontWeight: oneOf(raw.fontWeight, ['light', 'normal', 'bold'] as const, 'normal'),
    bg: {
      type: oneOf(bg.type, ['gradient', 'solid', 'image'] as const, 'gradient'),
      imageId: str(bg.imageId, ''),
      blur: num(bg.blur, 0, 40, d.bg.blur),
      dim: num(bg.dim, 0, 0.9, d.bg.dim),
      timeTint: bool(bg.timeTint, true),
    },
    stars: {
      on: bool(st.on, true),
      density: num(st.density, 0, 1, d.stars.density),
      speed: num(st.speed, 0, 1, d.stars.speed),
      size: num(st.size, 0.5, 2.5, d.stars.size),
    },
    crescent: { on: bool(cr.on, true), pos: oneOf(cr.pos, ['right', 'left', 'center'] as const, 'right') },
    card: {
      style: oneOf(cd.style, ['glass', 'solid', 'transparent'] as const, 'glass'),
      radius: num(cd.radius, 0, 40, d.card.radius),
      border: num(cd.border, 0, 4, d.card.border),
      blur: num(cd.blur, 0, 30, d.card.blur),
    },
    counter: oneOf(raw.counter, ['ring', 'bar', 'digits'] as const, 'ring'),
    digits: oneOf(raw.digits, ['arabic', 'latin'] as const, 'arabic'),
    hour12: bool(raw.hour12, true),
    hidden,
    homeOrder: order as string[],
  };
}
