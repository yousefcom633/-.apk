// ───────────────────────────────────────────────────────────────────────────
//  ADHAN SOUNDS CONFIG  —  the ONLY file you need to edit to add / swap muezzins.
//
//  • name : label shown in the app
//  • src  : path to the audio file (relative to the app root, e.g. files placed in
//           public/sounds/ are reachable as "sounds/<file>") OR a full https:// link
//  • fajr : true  → this is a Fajr adhan (contains "الصلاة خير من النوم")
//
//  The audio files themselves are NOT bundled. Drop your mp3/ogg files into
//  public/sounds/ using the file names below (or change the names here).
// ───────────────────────────────────────────────────────────────────────────

export interface AdhanSoundDef {
  id: string;
  name: string;
  src: string;
  fajr: boolean;
}

export const ADHAN_SOUNDS: AdhanSoundDef[] = [
  { id: 'afasy', name: 'مشاري العفاسي', src: 'sounds/afasy.mp3', fajr: false },
  { id: 'makkah', name: 'الحرم المكي', src: 'sounds/makkah.mp3', fajr: false },
  { id: 'madinah', name: 'الحرم المدني', src: 'sounds/madinah.mp3', fajr: false },
  { id: 'aqsa', name: 'المسجد الأقصى', src: 'sounds/aqsa.mp3', fajr: false },
  { id: 'tobar', name: 'نصر الدين طوبار', src: 'sounds/tobar.mp3', fajr: false },
  { id: 'fajr-salah', name: 'أذان الفجر (الصلاة خير من النوم)', src: 'sounds/fajr.mp3', fajr: true },
];

/** Built-in identifier for the synthesized tone used for the "short alert" mode / fallback. */
export const CHIME_ID = '__chime__';
