// Post-prayer adhkar shown after the adhan (optional) and in the Tasbih screen.
export interface Dhikr {
  text: string;
  count: number;
}

export const ADHKAR: Dhikr[] = [
  { text: 'أستغفر الله', count: 3 },
  { text: 'اللهم أنت السلام ومنك السلام تباركت يا ذا الجلال والإكرام', count: 1 },
  { text: 'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير', count: 1 },
  { text: 'اللهم لا مانع لما أعطيت ولا معطي لما منعت ولا ينفع ذا الجد منك الجد', count: 1 },
  { text: 'سبحان الله', count: 33 },
  { text: 'الحمد لله', count: 33 },
  { text: 'الله أكبر', count: 34 },
  { text: 'اللهم أعنّي على ذكرك وشكرك وحسن عبادتك', count: 1 },
  { text: 'قراءة آية الكرسي والمعوّذات', count: 1 },
];

export const TASBIH_PRESETS: { text: string; target: number }[] = [
  { text: 'سبحان الله', target: 33 },
  { text: 'الحمد لله', target: 33 },
  { text: 'الله أكبر', target: 34 },
  { text: 'لا إله إلا الله', target: 100 },
  { text: 'أستغفر الله', target: 100 },
  { text: 'اللهم صلّ على محمد', target: 100 },
  { text: 'لا حول ولا قوة إلا بالله', target: 100 },
];
