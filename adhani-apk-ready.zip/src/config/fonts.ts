// Built-in (bundled, offline) Arabic fonts. Imported fonts are handled in lib/assets.ts.
import '@fontsource/cairo/arabic-300.css';
import '@fontsource/cairo/arabic-400.css';
import '@fontsource/cairo/arabic-700.css';
import '@fontsource/cairo/latin-300.css';
import '@fontsource/cairo/latin-400.css';
import '@fontsource/cairo/latin-700.css';
import '@fontsource/tajawal/arabic-300.css';
import '@fontsource/tajawal/arabic-400.css';
import '@fontsource/tajawal/arabic-700.css';
import '@fontsource/tajawal/latin-300.css';
import '@fontsource/tajawal/latin-400.css';
import '@fontsource/tajawal/latin-700.css';
import '@fontsource/amiri/arabic-400.css';
import '@fontsource/amiri/arabic-700.css';
import '@fontsource/amiri/latin-400.css';
import '@fontsource/amiri/latin-700.css';
import '@fontsource/noto-naskh-arabic/arabic-400.css';
import '@fontsource/noto-naskh-arabic/arabic-700.css';
import '@fontsource/noto-naskh-arabic/latin-400.css';
import '@fontsource/noto-naskh-arabic/latin-700.css';
import '@fontsource/reem-kufi/arabic-400.css';
import '@fontsource/reem-kufi/arabic-700.css';
import '@fontsource/reem-kufi/latin-400.css';
import '@fontsource/reem-kufi/latin-700.css';
import '@fontsource/ibm-plex-sans-arabic/arabic-300.css';
import '@fontsource/ibm-plex-sans-arabic/arabic-400.css';
import '@fontsource/ibm-plex-sans-arabic/arabic-700.css';
import '@fontsource/ibm-plex-sans-arabic/latin-300.css';
import '@fontsource/ibm-plex-sans-arabic/latin-400.css';
import '@fontsource/ibm-plex-sans-arabic/latin-700.css';

export interface FontDef {
  id: string;
  name: string;
  family: string;
}

export const BUILTIN_FONTS: FontDef[] = [
  { id: 'cairo', name: 'Cairo', family: 'Cairo' },
  { id: 'tajawal', name: 'Tajawal', family: 'Tajawal' },
  { id: 'amiri', name: 'Amiri', family: 'Amiri' },
  { id: 'naskh', name: 'Noto Naskh Arabic', family: 'Noto Naskh Arabic' },
  { id: 'reem', name: 'Reem Kufi', family: 'Reem Kufi' },
  { id: 'plex', name: 'IBM Plex Sans Arabic', family: 'IBM Plex Sans Arabic' },
];

export const FONT_SLOTS = ['heading', 'body', 'numbers', 'widget'] as const;
export type FontSlot = (typeof FONT_SLOTS)[number];
export const FONT_SLOT_LABELS: Record<FontSlot, string> = {
  heading: 'خط العناوين',
  body: 'خط النصوص',
  numbers: 'خط الأرقام والعدّاد',
  widget: 'خط الويدجت',
};

export const PREVIEW_TEXT = 'بسم الله الرحمن الرحيم — حيّ على الصلاة ٠١٢٣٤٥٦٧٨٩ / 0123456789';

/** Registry of custom fonts currently registered in document.fonts: id -> family */
export const customFamilies = new Map<string, string>();

/** CSS font-family stack for a font id (builtin id or "custom:<id>"). */
export function fontStack(id: string): string {
  const b = BUILTIN_FONTS.find((f) => f.id === id);
  if (b) return `"${b.family}", "Cairo", system-ui, sans-serif`;
  if (id.startsWith('custom:')) {
    const fam = customFamilies.get(id.slice(7));
    if (fam) return `"${fam}", "Cairo", system-ui, sans-serif`;
  }
  return `"Cairo", system-ui, sans-serif`;
}

export const WEIGHT_VALUES = { light: 300, normal: 400, bold: 700 } as const;
