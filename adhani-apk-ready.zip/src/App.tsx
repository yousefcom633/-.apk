// App shell: starts the clock/scheduler, mounts theme + background, bottom navigation and screens.
import { Home as HomeIcon, Menu, Palette, Smartphone, Volume2, type LucideIcon } from 'lucide-react';
import { useEffect, type ReactNode } from 'react';
import { stopPlayback, unlockAudio } from './lib/audio';
import { loadCustomFonts } from './lib/assets';
import { startLocationWatcher } from './lib/location';
import { isNative } from './lib/native';
import { startNativeAlarms } from './lib/nativeAlarms';
import { setWakeLock } from './lib/notify';
import { startScheduler } from './lib/scheduler';
import { startTicker } from './lib/ticker';
import Appearance from './screens/Appearance';
import { CalendarScreen, RamadanScreen } from './screens/CalendarRamadan';
import { QiblaScreen, TasbihScreen, TrackerScreen } from './screens/Extras';
import { BatteryScreen, LimitsScreen } from './screens/Guides';
import Home from './screens/Home';
import More, { BackupScreen } from './screens/More';
import Permissions from './screens/Permissions';
import Settings, { LocationScreen } from './screens/Settings';
import Sounds from './screens/Sounds';
import WidgetEditor from './screens/WidgetEditor';
import { go, navStore, type Screen } from './state/nav';
import { adhanStore, onboardStore, settingsStore } from './state/stores';
import { AdhanOverlay } from './ui/AdhanOverlay';
import { Background } from './ui/Background';
import { Toaster } from './ui/controls';
import { ThemeHost } from './ui/ThemeHost';

const TAB_DEFS: { id: Screen; label: string; icon: LucideIcon }[] = [
  { id: 'home', label: 'الرئيسية', icon: HomeIcon },
  { id: 'sounds', label: 'الأذان', icon: Volume2 },
  { id: 'widgets', label: 'الويدجت', icon: Smartphone },
  { id: 'appearance', label: 'المظهر', icon: Palette },
  { id: 'more', label: 'المزيد', icon: Menu },
];

const SCREENS: Record<Screen, () => ReactNode> = {
  home: () => <Home />,
  sounds: () => <Sounds />,
  widgets: () => <WidgetEditor />,
  appearance: () => <Appearance />,
  more: () => <More />,
  settings: () => <Settings />,
  qibla: () => <QiblaScreen />,
  tracker: () => <TrackerScreen />,
  tasbih: () => <TasbihScreen />,
  calendar: () => <CalendarScreen />,
  ramadan: () => <RamadanScreen />,
  backup: () => <BackupScreen />,
  permissions: () => <Permissions />,
  battery: () => <BatteryScreen />,
  limits: () => <LimitsScreen />,
  location: () => <LocationScreen />,
};

export default function App() {
  const { stack } = navStore.use();
  const screen = stack[stack.length - 1];
  const onboard = onboardStore.use();
  const keepAwake = settingsStore.use().keepAwake;

  useEffect(() => {
    startTicker();
    startScheduler();
    startLocationWatcher();
    void startNativeAlarms();
    void loadCustomFonts();
    window.addEventListener('pointerdown', unlockAudio, { once: true });
    // "Stop adhan" action from the notification
    const onMsg = (e: MessageEvent) => {
      if (e.data?.type === 'stop-adhan') {
        stopPlayback();
        adhanStore.set({ active: false });
      }
    };
    navigator.serviceWorker?.addEventListener('message', onMsg);
    if (import.meta.env.PROD && !isNative() && 'serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => undefined);
    return () => navigator.serviceWorker?.removeEventListener('message', onMsg);
  }, []);

  useEffect(() => {
    void setWakeLock(keepAwake);
  }, [keepAwake]);

  const activeTab = TAB_DEFS.some((t) => t.id === screen) ? screen : 'more';

  return (
    <div className="relative h-full" data-edit="bgStart">
      <ThemeHost />
      <Background />
      <div className="relative z-10 mx-auto flex h-full max-w-lg flex-col">
        <main key={screen} className="no-scrollbar flex-1 overflow-y-auto px-4 pb-32 pt-4" style={{ paddingTop: 'max(1rem, var(--safe-area-inset-top, env(safe-area-inset-top, 0px)))' }}>
          {onboard.done ? SCREENS[screen]() : <Permissions onboarding />}
        </main>
      </div>
      {onboard.done && (
        <nav
          data-no-edit
          className="gcard fixed inset-x-3 bottom-3 z-30 mx-auto flex max-w-md items-center justify-around px-2 py-1.5"
          style={{ borderRadius: 28, paddingBottom: 'max(0.375rem, var(--safe-area-inset-bottom, env(safe-area-inset-bottom, 0px)))' }}
        >
          {TAB_DEFS.map((t) => {
            const on = activeTab === t.id;
            return (
              <button key={t.id} onClick={() => go(t.id)} className="flex min-w-[3.6rem] flex-col items-center gap-0.5 rounded-2xl px-2 py-1.5 transition-all" style={{ background: on ? 'var(--c-button)' : 'transparent', color: on ? 'var(--c-buttonText)' : 'var(--c-textSecondary)' }}>
                <t.icon size={20} />
                <span className="text-[0.65rem] leading-none">{t.label}</span>
              </button>
            );
          })}
        </nav>
      )}
      <AdhanOverlay />
      <Toaster />
    </div>
  );
}
