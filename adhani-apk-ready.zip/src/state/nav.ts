// Minimal screen navigation with browser/hardware back-button support.
import { createStore } from '../lib/store';

export type Screen =
  | 'home' | 'sounds' | 'widgets' | 'appearance' | 'more' | 'settings' | 'qibla' | 'tracker'
  | 'tasbih' | 'calendar' | 'ramadan' | 'backup' | 'permissions' | 'battery' | 'limits' | 'location';

export const TABS: Screen[] = ['home', 'sounds', 'widgets', 'appearance', 'more'];

export const navStore = createStore<{ stack: Screen[] }>(null, { stack: ['home'] });

export function go(s: Screen) {
  const st = navStore.get().stack;
  if (st[st.length - 1] === s) return;
  if (TABS.includes(s)) {
    navStore.set({ stack: [s] });
    return;
  }
  navStore.set({ stack: [...st, s] });
  history.pushState({ s }, '');
}

export function back() {
  const st = navStore.get().stack;
  if (st.length > 1) history.back();
}

window.addEventListener('popstate', () => {
  const st = navStore.get().stack;
  if (st.length > 1) navStore.set({ stack: st.slice(0, -1) });
});
