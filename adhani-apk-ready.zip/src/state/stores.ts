// All app stores in one place (persisted ones act as the DataStore equivalent).
import { DEFAULT_SETTINGS, type Settings } from '../config/settings';
import { DEFAULT_THEME, type ColorKey, type ThemeState } from '../config/themes';
import { createStore, uid } from '../lib/store';
import type { Prayer5 } from '../lib/types';
import { makeWidget, type WidgetDesign } from '../lib/widgetTypes';

export const settingsStore = createStore<Settings>('settings', DEFAULT_SETTINGS);
export const themeStore = createStore<ThemeState>('theme', DEFAULT_THEME);

export interface SavedTheme {
  id: string;
  name: string;
  theme: ThemeState;
}
export const savedThemesStore = createStore<{ items: SavedTheme[] }>('savedThemes', { items: [] });

// Metadata of imported binary assets (blobs live in IndexedDB).
export const fontsStore = createStore<{ items: { id: string; name: string }[] }>('fontsMeta', { items: [] });
export const soundsStore = createStore<{ items: { id: string; name: string; fajr: boolean }[] }>('soundsMeta', { items: [] });
export const imagesStore = createStore<{ items: { id: string; name: string; w: number; h: number }[] }>('imagesMeta', { items: [] });
export const fontsRev = createStore<{ rev: number }>(null, { rev: 0 });

const firstWidget = makeWidget('night', 'medium', 'ويدجت ليلي');
const secondWidget = makeWidget('gold', 'small', 'ويدجت ذهبي');
export const widgetsStore = createStore<{
  items: WidgetDesign[];
  activeId: string;
  saved: { id: string; name: string; design: WidgetDesign }[];
}>('widgets', { items: [firstWidget, secondWidget], activeId: firstWidget.id, saved: [] });

export type TrackerDays = Record<string, Partial<Record<Prayer5, boolean>>>;
export const trackerStore = createStore<{ days: TrackerDays }>('tracker', { days: {} }, false);
export const tasbihStore = createStore<{ count: number; target: number; preset: string; total: number }>('tasbih', {
  count: 0, target: 33, preset: 'سبحان الله', total: 0,
});
export const firedStore = createStore<{ ids: Record<string, number> }>('fired', { ids: {} }, false);
export const quietStore = createStore<{ until: number }>('quiet', { until: 0 });
export const onboardStore = createStore<{ done: boolean }>('onboard', { done: false });

// ── Non persisted UI state ──
export const uiStore = createStore<{ editMode: boolean; editKey: ColorKey | null }>(null, { editMode: false, editKey: null });

export interface AdhanSession {
  active: boolean;
  prayer: Prayer5 | null;
  phase: 'playing' | 'adhkar';
  note: string;
  blocked: boolean;
  startedAt: number;
}
export const adhanStore = createStore<AdhanSession>(null, {
  active: false, prayer: null, phase: 'playing', note: '', blocked: false, startedAt: 0,
});

export interface Toast {
  id: string;
  msg: string;
  kind: 'info' | 'error' | 'ok';
}
export const toastStore = createStore<{ items: Toast[] }>(null, { items: [] });
export function toast(msg: string, kind: Toast['kind'] = 'info') {
  const id = uid();
  toastStore.set((s) => ({ items: [...s.items.slice(-3), { id, msg, kind }] }));
  setTimeout(() => toastStore.set((s) => ({ items: s.items.filter((t) => t.id !== id) })), kind === 'error' ? 5500 : 2800);
}
