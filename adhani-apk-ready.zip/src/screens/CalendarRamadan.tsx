// Hijri calendar with Islamic occasions + Ramadan mode screen.
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useMemo, useState } from 'react';
import { HIJRI_MONTHS, hijriOf, weekdayInTz, ymdInTz } from '../lib/format';
import { useDisplay } from '../lib/hooks';
import { calcTimes } from '../lib/prayer';
import { back } from '../state/nav';
import { settingsStore } from '../state/stores';
import { PageHeader, Row, Section, ToggleRow } from '../ui/controls';

const OCCASIONS: Record<string, string> = {
  '1-1': 'رأس السنة الهجرية',
  '10-1': 'يوم عاشوراء',
  '12-3': 'المولد النبوي الشريف',
  '27-7': 'ليلة الإسراء والمعراج',
  '15-8': 'ليلة النصف من شعبان',
  '1-9': 'أول أيام رمضان',
  '27-9': 'ليلة القدر (ليلة ٢٧ ترجيحًا)',
  '1-10': 'عيد الفطر المبارك',
  '9-12': 'يوم عرفة',
  '10-12': 'عيد الأضحى المبارك',
  '11-12': 'أيام التشريق',
};
const DAYS = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
const noon = (y: number, m: number, d: number) => new Date(Date.UTC(y, m - 1, d, 12));

export function CalendarScreen() {
  const d = useDisplay();
  const off = d.settings.hijriOffset;
  const t = ymdInTz(new Date(), d.tz);
  const todayDate = noon(t.y, t.m, t.d);
  const todayH = hijriOf(todayDate, 'UTC', off);
  const [anchor, setAnchor] = useState(todayDate);

  const view = useMemo(() => {
    const h = hijriOf(anchor, 'UTC', off);
    const first = new Date(anchor.getTime() - (h.d - 1) * 86400000);
    const cells: { date: Date; h: ReturnType<typeof hijriOf> }[] = [];
    for (let i = 0; i < 31; i++) {
      const date = new Date(first.getTime() + i * 86400000);
      const hh = hijriOf(date, 'UTC', off);
      if (hh.m !== h.m) break;
      cells.push({ date, h: hh });
    }
    return { h, first, cells };
  }, [anchor, off]);

  const lead = (weekdayInTz(view.first, 'UTC') + 1) % 7; // Saturday-first grid
  const shift = (dir: number) =>
    setAnchor(dir < 0 ? new Date(view.first.getTime() - 86400000) : new Date(view.first.getTime() + 31 * 86400000));
  const events = view.cells.filter((c) => OCCASIONS[`${c.h.d}-${c.h.m}`] || [13, 14, 15].includes(c.h.d));

  return (
    <div className="screen-enter">
      <PageHeader title="التقويم الهجري" onBack={back} />
      <div className="gcard mb-3 p-4" data-edit="card">
        <div className="mb-3 flex items-center justify-between">
          <button className="btn btn-ghost !p-2" onClick={() => shift(1)} aria-label="الشهر التالي"><ChevronRight size={18} /></button>
          <div className="text-center">
            <div className="f-heading t1 text-lg">{HIJRI_MONTHS[view.h.m - 1]} {d.num(view.h.y)}</div>
            <div className="t2 text-xs">
              {new Intl.DateTimeFormat('ar-EG-u-nu-latn-ca-gregory', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(view.first).replace(/\d/g, (x) => d.num(x))}
            </div>
          </div>
          <button className="btn btn-ghost !p-2" onClick={() => shift(-1)} aria-label="الشهر السابق"><ChevronLeft size={18} /></button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center">
          {DAYS.map((x, i) => (
            <div key={x} className="t2 pb-1 text-[0.62rem]" style={{ color: i === 6 ? 'var(--c-nextGlow)' : undefined }}>{x}</div>
          ))}
          {Array.from({ length: lead }).map((_, i) => <div key={'e' + i} />)}
          {view.cells.map((c) => {
            const isToday = c.date.getTime() === todayDate.getTime() && view.h.m === todayH.m;
            const ev = OCCASIONS[`${c.h.d}-${c.h.m}`];
            return (
              <div key={c.h.d} className="relative flex aspect-square flex-col items-center justify-center rounded-xl" style={{ background: isToday ? 'var(--c-button)' : ev ? 'var(--card-bc)' : undefined, color: isToday ? 'var(--c-buttonText)' : undefined }}>
                <span className="f-num f-heading text-sm leading-none">{d.num(c.h.d)}</span>
                <span className="f-num text-[0.5rem] opacity-60">{d.num(c.date.getUTCDate())}</span>
                {ev && <span className="absolute bottom-0.5 h-1 w-1 rounded-full" style={{ background: 'var(--c-nextGlow)' }} />}
              </div>
            );
          })}
        </div>
        <button className="btn btn-ghost mx-auto mt-3 !py-1.5 !text-xs" onClick={() => setAnchor(todayDate)}>اليوم</button>
      </div>
      <Section title="المناسبات في هذا الشهر">
        {events.map((c) => (
          <Row key={c.h.d} label={OCCASIONS[`${c.h.d}-${c.h.m}`] ?? 'من الأيام البيض (يُستحب صيامها)'} sub={`${d.num(c.h.d)} ${HIJRI_MONTHS[c.h.m - 1]} · ${d.num(c.date.getUTCDate())}/${d.num(c.date.getUTCMonth() + 1)}`} />
        ))}
        {!events.length && <p className="t2 p-4 text-center text-xs">لا مناسبات في هذا الشهر</p>}
      </Section>
      <p className="t2 px-2 text-xs">التقويم أم القرى المحسوب؛ قد يختلف يومًا عن رؤية بلدك — عدّله من الإعدادات (فرق التاريخ الهجري).</p>
    </div>
  );
}

export function RamadanScreen() {
  const d = useDisplay();
  const s = d.settings;
  const now = new Date();
  const h = hijriOf(now, s.location.tz, s.hijriOffset);
  const isRamadan = h.m === 9;

  // days until 1 Ramadan
  let daysTo = 0;
  if (!isRamadan) {
    for (let i = 1; i < 400; i++) {
      const x = hijriOf(new Date(now.getTime() + i * 86400000), s.location.tz, s.hijriOffset);
      if (x.m === 9 && x.d === 1) {
        daysTo = i;
        break;
      }
    }
  }
  const rows = isRamadan
    ? Array.from({ length: 31 - h.d + 1 }, (_, i) => ({ day: h.d + i, t: calcTimes(s, now, i) })).filter((r) => r.day <= 30)
    : [];

  return (
    <div className="screen-enter">
      <PageHeader title="وضع رمضان" onBack={back} />
      <div className="gcard mb-3 p-5 text-center" data-edit="card" style={{ borderColor: 'var(--c-nextGlow)' }}>
        {isRamadan ? (
          <>
            <div className="f-heading t1 text-xl">رمضان كريم 🌙</div>
            <div className="t2 mt-1 text-sm">اليوم {d.num(h.d)} رمضان {d.num(h.y)} هـ</div>
          </>
        ) : (
          <>
            <div className="f-heading t1 text-lg">باقٍ على رمضان تقريبًا</div>
            <div className="f-num f-heading mt-1 text-5xl" style={{ color: 'var(--c-nextGlow)' }}>{d.num(daysTo)}</div>
            <div className="t2 text-sm">يوم</div>
          </>
        )}
      </div>
      <Section title="الإعدادات">
        <ToggleRow label="تفعيل وضع رمضان" sub="يظهر العدّ التنازلي في الرئيسية وينبّهك للسحور" on={s.ramadanMode} onChange={(v) => settingsStore.set({ ramadanMode: v })} />
      </Section>
      {isRamadan && (
        <Section title="إمساكية الشهر" hint="الإمساك = أذان الفجر · الإفطار = أذان المغرب (يتأثر بتعديلاتك اليدوية).">
          <div className="grid grid-cols-3 px-4 py-2 text-center text-xs t2"><span>اليوم</span><span>الإمساك</span><span>الإفطار</span></div>
          {rows.map((r) => (
            <div key={r.day} className="grid grid-cols-3 px-4 py-2 text-center text-sm" style={{ background: r.day === h.d ? 'var(--card-bc)' : undefined }}>
              <span className="f-num t1">{d.num(r.day)}</span>
              <span className="f-num t1">{d.time(r.t.fajr)}</span>
              <span className="f-num t1">{d.time(r.t.maghrib)}</span>
            </div>
          ))}
        </Section>
      )}
    </div>
  );
}
