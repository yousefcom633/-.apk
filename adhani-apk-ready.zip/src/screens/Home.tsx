// Home: header (dates + city), big countdown, prayer cards and extras. Layout order comes from ThemeState.
import {
  Bell, BellDot, BellOff, BellRing, CheckCircle2, Circle, MapPin, Moon, MoonStar, Sun, SunMedium, Sunrise, Sunset,
  UtensilsCrossed, Moon as MoonIcon, BookOpen, VolumeX, ShieldAlert,
} from 'lucide-react';
import type { ReactNode } from 'react';
import { fmtGregorian, fmtHijri, dayKey, hijriOf, weekdayInTz } from '../lib/format';
import { useDisplay, useSchedule } from '../lib/hooks';
import { notifPermission } from '../lib/notify';
import { MODE_LABELS, MODE_ORDER, PRAYER_NAMES, type AlertMode, type Prayer5, type PrayerKey } from '../lib/types';
import { go } from '../state/nav';
import { quietStore, settingsStore, toast, trackerStore } from '../state/stores';

const ICONS: Record<PrayerKey, typeof Sun> = {
  fajr: MoonStar, sunrise: Sunrise, dhuhr: Sun, asr: SunMedium, maghrib: Sunset, isha: Moon,
};
const MODE_ICONS: Record<AlertMode, typeof Bell> = { full: BellRing, short: Bell, notify: BellDot, silent: BellOff };

function Header() {
  const d = useDisplay();
  const { now, sch } = useSchedule();
  const afterMaghrib = now.getTime() >= sch.today.maghrib.getTime();
  const h = hijriOf(now, d.tz, d.settings.hijriOffset + (afterMaghrib ? 1 : 0));
  return (
    <div className="pt-2">
      <button className="t2 flex items-center gap-1 text-sm" data-edit="textSecondary" onClick={() => go('location')}>
        <MapPin size={15} className="ticon" data-edit="icons" />
        <span>{d.settings.location.name}</span>
        <span className="text-xs opacity-70">{d.settings.location.mode === 'gps' ? '· GPS' : ''}</span>
      </button>
      <h1 data-edit="textPrimary" className="f-heading t1 mt-1 text-[1.65rem] leading-tight">
        {fmtHijri(h, d.digits)}
      </h1>
      <p data-edit="textSecondary" className="t2 mt-0.5 text-sm">{fmtGregorian(now, d.tz, d.digits)}</p>
    </div>
  );
}

function Countdown() {
  const d = useDisplay();
  const { now, sch } = useSchedule();
  const { next, prev } = sch;
  const total = next.at.getTime() - prev.at.getTime();
  const remain = next.at.getTime() - now.getTime();
  const progress = Math.min(1, Math.max(0, 1 - remain / total));
  const style = d.theme.counter;
  const name = PRAYER_NAMES[next.key];
  const sub = `الأذان ${d.time(next.at)}`;

  if (style === 'bar') {
    return (
      <div className="gcard p-5" data-edit="card">
        <div className="flex items-end justify-between">
          <div>
            <div className="t2 text-xs" data-edit="textSecondary">الصلاة الجاية</div>
            <div className="f-heading t1 text-2xl" data-edit="textPrimary">{name}</div>
          </div>
          <div className="f-num tacc text-3xl" data-edit="ring" style={{ color: 'var(--c-ring)' }}>{d.dur(remain)}</div>
        </div>
        <div className="mt-4 h-2.5 overflow-hidden rounded-full" style={{ background: 'var(--card-bc)' }}>
          <div className="h-full rounded-full transition-all duration-1000" data-edit="ring" style={{ width: `${progress * 100}%`, background: 'var(--c-ring)', boxShadow: '0 0 12px var(--c-ring)' }} />
        </div>
        <div className="t2 mt-2 text-xs" data-edit="textSecondary">{sub}</div>
      </div>
    );
  }
  if (style === 'digits') {
    return (
      <div className="py-6 text-center">
        <div className="f-heading t2 text-base" data-edit="textSecondary">متبقٍ على {name}</div>
        <div className="f-num mt-1 text-[3.6rem] leading-none" data-edit="ring" style={{ color: 'var(--c-ring)', textShadow: '0 0 28px var(--c-ring)' }}>
          {d.dur(remain)}
        </div>
        <div className="t2 mt-2 text-sm" data-edit="textSecondary">{sub}</div>
      </div>
    );
  }
  const R = 118, C = 2 * Math.PI * R;
  return (
    <div className="flex justify-center py-2">
      <div className="relative" style={{ width: 272, height: 272 }}>
        <svg viewBox="0 0 272 272" className="absolute inset-0" style={{ transform: 'rotate(-90deg)' }}>
          <circle cx="136" cy="136" r={R} fill="none" stroke="var(--card-bc)" strokeWidth="10" />
          <circle
            cx="136" cy="136" r={R} fill="none" stroke="var(--c-ring)" strokeWidth="10" strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - progress)} data-edit="ring"
            style={{ filter: 'drop-shadow(0 0 8px var(--c-ring))', transition: 'stroke-dashoffset 1s linear', pointerEvents: 'stroke' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="t2 text-xs" data-edit="textSecondary">الصلاة الجاية</div>
          <div className="f-heading t1 text-[2rem] leading-tight" data-edit="textPrimary">{name}</div>
          <div className="f-num mt-1 text-[2.1rem] leading-none" data-edit="ring" style={{ color: 'var(--c-ring)' }}>{d.dur(remain)}</div>
          <div className="t2 mt-2 text-xs" data-edit="textSecondary">{sub}</div>
        </div>
      </div>
    </div>
  );
}

function Cards() {
  const d = useDisplay();
  const { now, sch } = useSchedule();
  const key = dayKey(now, d.tz);
  const tracker = trackerStore.use().days[key] ?? {};
  const keys = (['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as PrayerKey[]).filter((k) => !d.theme.hidden[k]);

  const cycle = (p: Prayer5) => {
    const cur = d.settings.modes[p];
    const nx = MODE_ORDER[(MODE_ORDER.indexOf(cur) + 1) % MODE_ORDER.length];
    settingsStore.setPath('modes.' + p, nx);
    toast(`${PRAYER_NAMES[p]}: ${MODE_LABELS[nx]}`);
  };

  return (
    <div className="space-y-2.5">
      {keys.map((k) => {
        const at = sch.today[k];
        const isNext = k === sch.next.key;
        const past = at.getTime() <= now.getTime();
        const Icon = ICONS[k];
        const is5 = k !== 'sunrise';
        const mode = is5 ? d.settings.modes[k as Prayer5] : 'silent';
        const MIcon = MODE_ICONS[mode];
        return (
          <div
            key={k}
            data-edit="card"
            className="gcard flex items-center gap-3 px-4 py-3.5 transition-all duration-500"
            style={{
              opacity: past && !isNext ? 0.5 : 1,
              borderColor: isNext ? 'var(--c-nextGlow)' : undefined,
              boxShadow: isNext ? '0 0 26px -6px var(--c-nextGlow), inset 0 0 18px -10px var(--c-nextGlow)' : undefined,
              animation: isNext ? 'pulseGlow 4s ease-in-out infinite' : undefined,
              transform: isNext ? 'scale(1.015)' : undefined,
            }}
          >
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full" style={{ background: 'var(--card-bc)' }}>
              <Icon size={20} className="ticon" data-edit="icons" style={{ color: isNext ? 'var(--c-nextGlow)' : undefined }} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="f-heading t1 text-base" data-edit="textPrimary">{PRAYER_NAMES[k]}</div>
              {is5 && (
                <div className="t2 text-[0.7rem]" data-edit="textSecondary">
                  الإقامة بعد {d.num(d.settings.iqamaMin[k as Prayer5])} د
                </div>
              )}
            </div>
            <div className="f-num t1 text-lg" data-edit="textPrimary" style={{ color: isNext ? 'var(--c-nextGlow)' : undefined }}>
              {d.time(at)}
            </div>
            {is5 ? (
              <>
                <button
                  aria-label="تمت الصلاة"
                  className="p-1"
                  data-no-edit
                  onClick={() => trackerStore.set((s) => ({ days: { ...s.days, [key]: { ...s.days[key], [k]: !s.days[key]?.[k as Prayer5] } } }))}
                  disabled={!past}
                  style={{ opacity: past ? 1 : 0.25 }}
                >
                  {tracker[k as Prayer5] ? <CheckCircle2 size={22} style={{ color: 'var(--c-accent)' }} /> : <Circle size={22} className="t2" />}
                </button>
                <button aria-label="تغيير نوع التنبيه" className="p-1" data-no-edit onClick={() => cycle(k as Prayer5)}>
                  <MIcon size={22} className="ticon" style={{ opacity: mode === 'silent' ? 0.45 : 1 }} />
                </button>
              </>
            ) : (
              <span className="w-[3.4rem]" />
            )}
          </div>
        );
      })}
      <p className="t2 px-2 pt-1 text-center text-[0.7rem]">
        الجرس: يتنقّل بين (أذان كامل ← تنبيه قصير ← إشعار فقط ← صامت) · الدائرة: علامة "صليت"
      </p>
    </div>
  );
}

function Banner({ icon, title, sub, onClick, accent }: { icon: ReactNode; title: string; sub?: string; onClick?: () => void; accent?: boolean }) {
  return (
    <button onClick={onClick} data-edit="card" className="gcard flex w-full items-center gap-3 px-4 py-3 text-start" style={accent ? { borderColor: 'var(--c-notif)' } : undefined}>
      <span className="ticon shrink-0" style={accent ? { color: 'var(--c-notif)' } : undefined}>{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="t1 block text-sm" data-edit="textPrimary">{title}</span>
        {sub && <span className="t2 block text-xs" data-edit="textSecondary">{sub}</span>}
      </span>
    </button>
  );
}

function Extras() {
  const d = useDisplay();
  const { now, sch } = useSchedule();
  const quiet = quietStore.use();
  const perm = notifPermission();
  const h = hijriOf(now, d.tz, d.settings.hijriOffset);
  const ramadan = d.settings.ramadanMode && h.m === 9;
  const friday = weekdayInTz(now, d.tz) === 5;
  const items: ReactNode[] = [];

  if (quiet.until > now.getTime()) {
    items.push(
      <Banner key="q" accent icon={<VolumeX size={22} />} title="وضع الهدوء بعد الأذان"
        sub={`ينتهي ${d.time(new Date(quiet.until))} — التذكيرات الصوتية متوقفة`} onClick={() => quietStore.set({ until: 0 })} />
    );
  }
  if (ramadan) {
    const nowMs = now.getTime();
    const iftar = sch.today.maghrib.getTime();
    const imsak = nowMs < sch.today.fajr.getTime() ? sch.today.fajr : nowMs < iftar ? null : sch.tomorrow.fajr;
    const target = imsak ?? sch.today.maghrib;
    items.push(
      <div key="r" data-edit="card" className="gcard p-4" style={{ borderColor: 'var(--c-nextGlow)' }}>
        <div className="flex items-center justify-between">
          <span className="f-heading t1 flex items-center gap-2 text-sm"><UtensilsCrossed size={18} className="ticon" /> رمضان</span>
          <span className="t2 text-xs">{imsak ? 'حتى الإمساك' : 'حتى الإفطار'}</span>
        </div>
        <div className="f-num mt-1 text-3xl text-center" style={{ color: 'var(--c-nextGlow)' }}>{d.dur(target.getTime() - nowMs)}</div>
        <div className="mt-2 flex justify-around text-xs">
          <span className="t2">الإمساك <b className="t1 f-num">{d.time(sch.today.fajr)}</b></span>
          <span className="t2">الإفطار <b className="t1 f-num">{d.time(sch.today.maghrib)}</b></span>
        </div>
      </div>
    );
  }
  if (friday) {
    items.push(<Banner key="f" icon={<BookOpen size={22} />} title="اليوم الجمعة" sub="الصلاة على النبي ﷺ، وسورة الكهف، وساعة الإجابة" />);
  }
  if (perm !== 'granted') {
    items.push(
      <Banner key="p" accent icon={<ShieldAlert size={22} />} title={perm === 'unsupported' ? 'الإشعارات غير مدعومة في هذا المتصفح' : 'فعّل الإشعارات والصلاحيات'}
        sub="لتصلك تنبيهات الأذان والإقامة — اضغط للشرح" onClick={() => go('permissions')} />
    );
  } else {
    items.push(<Banner key="s" icon={<MoonIcon size={22} />} title="الأذان التلقائي يعمل والتطبيق مفتوح" sub="لمعرفة حدود الويب وكيفية الاعتماد عليه اضغط هنا" onClick={() => go('limits')} />);
  }
  return <div className="space-y-2.5">{items}</div>;
}

export default function Home() {
  const d = useDisplay();
  const parts: Record<string, ReactNode> = {
    header: <Header key="h" />,
    countdown: <Countdown key="c" />,
    cards: <Cards key="k" />,
    extras: <Extras key="e" />,
  };
  return (
    <div className="screen-enter space-y-4">
      {d.theme.homeOrder.map((k) => parts[k])}
    </div>
  );
}
