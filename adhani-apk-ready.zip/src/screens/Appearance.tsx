// Appearance: themes, colors, background, shapes, display options and fonts. Everything edits the central ThemeState.
import { Download, Eye, Save, Trash2, Type, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { BUILTIN_FONTS, FONT_SLOTS, FONT_SLOT_LABELS, PREVIEW_TEXT, fontStack, type FontSlot } from '../config/fonts';
import { COLOR_KEYS, COLOR_META, DEFAULT_THEME, HOME_SECTIONS, PRESETS, sanitizeTheme, type ColorKey, type ThemeState } from '../config/themes';
import { deleteFont, ensureFontReady, importFont } from '../lib/assets';
import { contrast } from '../lib/color';
import { downloadJson, readJsonFile } from '../lib/files';
import { uid } from '../lib/store';
import { ALL_KEYS, PRAYER_NAMES } from '../lib/types';
import { go } from '../state/nav';
import { fontsRev, fontsStore, imagesStore, savedThemesStore, themeStore, toast, uiStore } from '../state/stores';
import { ColorField, PageHeader, Row, Section, SliderRow, Segmented, ToggleRow } from '../ui/controls';
import { ImageLibrary } from '../ui/ImageLibrary';
import { Sortable } from '../ui/Sortable';
import { BUILTIN_IMAGES } from '../lib/assets';

type Tab = 'themes' | 'colors' | 'bg' | 'shape' | 'display' | 'fonts';
const TABS: { id: Tab; label: string }[] = [
  { id: 'themes', label: 'ثيمات' },
  { id: 'colors', label: 'ألوان' },
  { id: 'bg', label: 'الخلفية' },
  { id: 'shape', label: 'الشكل' },
  { id: 'display', label: 'العرض' },
  { id: 'fonts', label: 'الخطوط' },
];

/** Safe theme application: invalid images / fonts fall back instead of breaking the app. */
function applyTheme(t: ThemeState) {
  const imgOk = t.bg.imageId && (BUILTIN_IMAGES.some((b) => b.id === t.bg.imageId) || imagesStore.get().items.some((i) => i.id === t.bg.imageId));
  const next = { ...t, bg: { ...t.bg, type: t.bg.type === 'image' && !imgOk ? ('gradient' as const) : t.bg.type } };
  themeStore.replace(next);
}

function MiniPreview() {
  return (
    <div className="gcard mb-4 flex items-center gap-3 px-4 py-3" data-edit="card">
      <span className="grid h-10 w-10 place-items-center rounded-full" style={{ background: 'var(--card-bc)', color: 'var(--c-nextGlow)' }}>☾</span>
      <div className="flex-1">
        <div className="f-heading t1 text-base" data-edit="textPrimary">معاينة حية</div>
        <div className="t2 text-xs" data-edit="textSecondary">أي تعديل يظهر هنا وفي التطبيق فورًا</div>
      </div>
      <div className="f-num text-lg" data-edit="ring" style={{ color: 'var(--c-ring)' }}>٠٤:١٢</div>
      <span className="btn !px-3 !py-1.5 !text-xs" data-edit="button">زر</span>
    </div>
  );
}

function ThemesPanel() {
  const theme = themeStore.use();
  const saved = savedThemesStore.use();
  const ui = uiStore.use();
  const [name, setName] = useState('');
  const file = useRef<HTMLInputElement>(null);

  const importTheme = async (f?: File) => {
    if (!f) return;
    try {
      const t = sanitizeTheme(await readJsonFile(f));
      applyTheme(t);
      toast('تم استيراد الثيم وتطبيقه', 'ok');
    } catch (e: any) {
      toast(`ثيم غير صالح: ${e.message}. لم يتغيّر أي شيء.`, 'error');
    }
  };

  return (
    <>
      <Section title="التعديل بالضغط المطوّل" hint="فعّل الوضع، ثم اذهب للرئيسية واضغط مطوّلًا على أي عنصر (نص، بطاقة، حلقة، أيقونة، هلال، الخلفية) لفتح محرر لونه مباشرة.">
        <Row label="وضع التعديل بالضغط المطوّل">
          <button className="btn" onClick={() => { uiStore.set({ editMode: !ui.editMode }); if (!ui.editMode) go('home'); }}>
            <Eye size={16} /> {ui.editMode ? 'إيقاف' : 'تفعيل والذهاب للرئيسية'}
          </button>
        </Row>
      </Section>

      <Section title="ثيمات جاهزة">
        <div className="grid grid-cols-3 gap-2 p-3">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              className="overflow-hidden rounded-2xl text-center"
              style={{ border: '1px solid var(--card-bc)' }}
              onClick={() => {
                themeStore.set((t) => ({ ...t, colors: { ...p.colors }, bg: { ...t.bg, type: 'gradient' }, stars: { ...t.stars, ...DEFAULT_THEME.stars, ...p.stars } }));
                toast(`تم تطبيق ثيم ${p.name}`);
              }}
            >
              <div className="h-16" style={{ background: `linear-gradient(160deg, ${p.colors.bgStart}, ${p.colors.bgEnd})` }}>
                <div className="flex h-full items-end justify-center gap-1 pb-2">
                  {[p.colors.accent, p.colors.nextGlow, p.colors.textPrimary].map((c, i) => (
                    <span key={i} className="h-3 w-3 rounded-full" style={{ background: c }} />
                  ))}
                </div>
              </div>
              <div className="t1 py-1.5 text-xs">{p.name}</div>
            </button>
          ))}
        </div>
      </Section>

      <Section title="ثيماتي">
        <div className="flex gap-2 p-3">
          <input type="text" placeholder="اسم الثيم الحالي" value={name} onChange={(e) => setName(e.target.value)} />
          <button
            className="btn shrink-0"
            onClick={() => {
              if (!name.trim()) return toast('اكتب اسمًا للثيم أولًا', 'error');
              savedThemesStore.set((s) => ({ items: [...s.items, { id: uid(), name: name.trim(), theme: theme }] }));
              setName('');
              toast('تم حفظ الثيم', 'ok');
            }}
          >
            <Save size={16} /> حفظ
          </button>
        </div>
        {saved.items.map((s) => (
          <div key={s.id} className="flex items-center gap-2 px-4 py-2.5">
            <span className="h-8 w-8 shrink-0 rounded-full" style={{ background: `linear-gradient(160deg, ${s.theme.colors.bgStart}, ${s.theme.colors.bgEnd})`, border: '2px solid var(--card-bc)' }} />
            <span className="t1 flex-1 truncate text-sm">{s.name}</span>
            <button className="btn btn-ghost !px-3 !py-1.5 !text-xs" onClick={() => { applyTheme(s.theme); toast('تم تطبيق الثيم'); }}>تطبيق</button>
            <button className="p-1.5 ticon" aria-label="تصدير" onClick={() => downloadJson('adhani-theme-' + s.name, { format: 'adhani-theme', version: 1, name: s.name, theme: s.theme })}><Download size={17} /></button>
            <button className="p-1.5 text-red-400" aria-label="حذف" onClick={() => savedThemesStore.set((x) => ({ items: x.items.filter((i) => i.id !== s.id) }))}><Trash2 size={17} /></button>
          </div>
        ))}
        {!saved.items.length && <p className="t2 p-4 text-center text-xs">لم تحفظ أي ثيم بعد</p>}
      </Section>

      <Section title="تصدير / استيراد / إعادة ضبط">
        <div className="flex flex-wrap gap-2 p-3">
          <button className="btn" onClick={() => downloadJson('adhani-theme', { format: 'adhani-theme', version: 1, name: 'الثيم الحالي', theme })}>
            <Download size={16} /> تصدير الثيم الحالي
          </button>
          <button className="btn btn-ghost" onClick={() => file.current?.click()}>
            <Upload size={16} /> استيراد ثيم (JSON)
          </button>
          <input ref={file} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { void importTheme(e.target.files?.[0]); e.target.value = ''; }} />
          <button
            className="btn btn-danger"
            onClick={() => {
              if (confirm('إعادة ضبط كل إعدادات المظهر للافتراضي؟')) {
                themeStore.reset();
                toast('تمت إعادة الضبط');
              }
            }}
          >
            إعادة ضبط الكل
          </button>
        </div>
      </Section>
    </>
  );
}

function ColorsPanel() {
  const theme = themeStore.use();
  const groups = Array.from(new Set(COLOR_KEYS.map((k) => COLOR_META[k].group)));
  const c = theme.colors;
  const checks: { label: string; key: ColorKey }[] = [
    { label: 'النص الأساسي', key: 'textPrimary' },
    { label: 'النص الثانوي', key: 'textSecondary' },
    { label: 'لون التمييز', key: 'accent' },
    { label: 'حلقة العدّاد', key: 'ring' },
  ];
  const warns = checks
    .map((x) => ({ ...x, r: Math.min(contrast(c[x.key], c.bgStart), contrast(c[x.key], c.bgEnd)) }))
    .filter((x) => x.r < (x.key === 'textPrimary' ? 4.5 : 3));
  const contrastKeys: ColorKey[] = ['textPrimary', 'textSecondary', 'accent', 'ring', 'icons', 'nextGlow'];
  return (
    <>
      {warns.length > 0 && (
        <div className="mb-4 rounded-2xl px-4 py-3 text-xs leading-relaxed" style={{ background: 'rgba(245,165,36,.16)' }}>
          {warns.map((w) => (
            <div key={w.key}>⚠️ {w.label}: التباين مع الخلفية {w.r.toFixed(1)}:1 — قد يصعب قراءته.</div>
          ))}
        </div>
      )}
      {groups.map((g) => (
        <Section key={g} title={g}>
          {COLOR_KEYS.filter((k) => COLOR_META[k].group === g).map((k) => (
            <ColorField
              key={k}
              label={COLOR_META[k].label}
              value={c[k]}
              onChange={(v) => themeStore.setPath('colors.' + k, v)}
              onReset={() => themeStore.setPath('colors.' + k, DEFAULT_THEME.colors[k])}
              contrastWith={contrastKeys.includes(k) ? [c.bgStart, c.bgEnd] : undefined}
            />
          ))}
        </Section>
      ))}
    </>
  );
}

function BackgroundPanel() {
  const t = themeStore.use();
  return (
    <>
      <Section title="نوع الخلفية">
        <div className="p-3">
          <Segmented
            value={t.bg.type}
            onChange={(v) => themeStore.setPath('bg.type', v)}
            options={[{ id: 'gradient', label: 'تدرّج' }, { id: 'solid', label: 'لون ثابت' }, { id: 'image', label: 'صورة من المعرض' }]}
          />
        </div>
        {t.bg.type !== 'image' && <ColorField label={t.bg.type === 'solid' ? 'لون الخلفية' : 'بداية التدرّج'} value={t.colors.bgStart} onChange={(v) => themeStore.setPath('colors.bgStart', v)} />}
        {t.bg.type === 'gradient' && <ColorField label="نهاية التدرّج" value={t.colors.bgEnd} onChange={(v) => themeStore.setPath('colors.bgEnd', v)} />}
        {t.bg.type === 'image' && (
          <>
            <div className="p-3">
              <ImageLibrary selected={t.bg.imageId} onPick={(id) => themeStore.set((x) => ({ ...x, bg: { ...x.bg, imageId: id } }))} />
            </div>
            <SliderRow label="التغبيش (Blur)" value={t.bg.blur} min={0} max={30} step={1} onChange={(v) => themeStore.setPath('bg.blur', v)} format={(v) => v + 'px'} />
            <SliderRow label="التعتيم" value={t.bg.dim} min={0} max={0.9} step={0.05} onChange={(v) => themeStore.setPath('bg.dim', v)} format={(v) => Math.round(v * 100) + '%'} />
          </>
        )}
        <ToggleRow label="تدرّج لوني خفيف حسب وقت اليوم" on={t.bg.timeTint} onChange={(v) => themeStore.setPath('bg.timeTint', v)} />
      </Section>
      <Section title="النجوم">
        <ToggleRow label="إظهار النجوم" on={t.stars.on} onChange={(v) => themeStore.setPath('stars.on', v)} />
        <SliderRow label="الكثافة" value={t.stars.density} min={0} max={1} onChange={(v) => themeStore.setPath('stars.density', v)} format={(v) => Math.round(v * 100) + '%'} />
        <SliderRow label="سرعة التلألؤ (٠ = ثابتة)" value={t.stars.speed} min={0} max={1} onChange={(v) => themeStore.setPath('stars.speed', v)} format={(v) => Math.round(v * 100) + '%'} />
        <SliderRow label="الحجم" value={t.stars.size} min={0.5} max={2.5} onChange={(v) => themeStore.setPath('stars.size', v)} />
        <ColorField label="لون النجوم" value={t.colors.stars} onChange={(v) => themeStore.setPath('colors.stars', v)} />
      </Section>
      <Section title="الهلال">
        <ToggleRow label="إظهار الهلال" on={t.crescent.on} onChange={(v) => themeStore.setPath('crescent.on', v)} />
        <Row label="مكان الهلال" col>
          <Segmented value={t.crescent.pos} onChange={(v) => themeStore.setPath('crescent.pos', v)} options={[{ id: 'right', label: 'يمين' }, { id: 'center', label: 'وسط' }, { id: 'left', label: 'يسار' }]} />
        </Row>
        <ColorField label="لون الهلال" value={t.colors.crescent} onChange={(v) => themeStore.setPath('colors.crescent', v)} />
      </Section>
    </>
  );
}

function ShapePanel() {
  const t = themeStore.use();
  return (
    <>
      <Section title="شكل البطاقات">
        <Row label="النمط" col>
          <Segmented value={t.card.style} onChange={(v) => themeStore.setPath('card.style', v)} options={[{ id: 'glass', label: 'زجاجي (Blur)' }, { id: 'solid', label: 'مصمت' }, { id: 'transparent', label: 'شفاف' }]} />
        </Row>
        <ColorField label="لون البطاقات وشفافيتها" value={t.colors.card} onChange={(v) => themeStore.setPath('colors.card', v)} />
        <SliderRow label="استدارة الزوايا" value={t.card.radius} min={0} max={40} step={1} onChange={(v) => themeStore.setPath('card.radius', v)} format={(v) => v + 'px'} />
        <SliderRow label="سُمك الحدود" value={t.card.border} min={0} max={4} step={0.5} onChange={(v) => themeStore.setPath('card.border', v)} format={(v) => v + 'px'} />
        {t.card.style === 'glass' && <SliderRow label="قوة التغبيش" value={t.card.blur} min={0} max={30} step={1} onChange={(v) => themeStore.setPath('card.blur', v)} format={(v) => v + 'px'} />}
      </Section>
      <Section title="شكل العدّاد التنازلي">
        <div className="p-3">
          <Segmented value={t.counter} onChange={(v) => themeStore.setPath('counter', v)} options={[{ id: 'ring', label: 'حلقة' }, { id: 'bar', label: 'شريط' }, { id: 'digits', label: 'أرقام كبيرة فقط' }]} />
        </div>
      </Section>
    </>
  );
}

function DisplayPanel() {
  const t = themeStore.use();
  return (
    <>
      <Section title="الأرقام والوقت">
        <Row label="الأرقام" col>
          <Segmented value={t.digits} onChange={(v) => themeStore.setPath('digits', v)} options={[{ id: 'arabic', label: 'عربية (٠١٢)' }, { id: 'latin', label: 'إنجليزية (012)' }]} />
        </Row>
        <Row label="نظام الساعة" col>
          <Segmented value={t.hour12 ? '12' : '24'} onChange={(v) => themeStore.setPath('hour12', v === '12')} options={[{ id: '12', label: '١٢ ساعة' }, { id: '24', label: '٢٤ ساعة' }]} />
        </Row>
      </Section>
      <Section title="إظهار / إخفاء في الرئيسية">
        {ALL_KEYS.map((k) => (
          <ToggleRow key={k} label={PRAYER_NAMES[k]} on={!t.hidden[k]} onChange={(v) => themeStore.setPath('hidden.' + k, !v)} />
        ))}
      </Section>
      <Section title="ترتيب عناصر الشاشة الرئيسية" hint="اسحب المقبض لإعادة الترتيب.">
        <Sortable items={t.homeOrder} onChange={(o) => themeStore.setPath('homeOrder', o)} render={(id) => <span className="t1 text-sm">{HOME_SECTIONS[id]}</span>} />
      </Section>
    </>
  );
}

function FontsPanel() {
  const t = themeStore.use();
  const custom = fontsStore.use().items;
  fontsRev.use();
  const [slot, setSlot] = useState<FontSlot>('body');
  const [prev, setPrev] = useState(t.fonts.body);
  const [busy, setBusy] = useState(false);
  const file = useRef<HTMLInputElement>(null);
  const all = [...BUILTIN_FONTS.map((f) => ({ id: f.id, name: f.name })), ...custom.map((f) => ({ id: 'custom:' + f.id, name: f.name + ' (مستورد)' }))];

  /** Apply a font to slots; if it can't be used, roll back to the previous font with a clear message. */
  const apply = async (id: string, slots: FontSlot[]) => {
    const before = themeStore.get().fonts;
    if (!(await ensureFontReady(id))) {
      themeStore.set((x) => ({ ...x, fonts: before }));
      toast('تعذّر استخدام هذا الخط — تم الرجوع للخط السابق', 'error');
      return;
    }
    themeStore.set((x) => ({ ...x, fonts: { ...x.fonts, ...Object.fromEntries(slots.map((s) => [s, id])) } }));
    toast('تم تطبيق الخط', 'ok');
  };

  const onImport = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try {
      const it = await importFont(f);
      setPrev('custom:' + it.id);
      await apply('custom:' + it.id, [...FONT_SLOTS]);
    } catch (e: any) {
      toast(`${e.message ?? 'تعذّر استيراد الخط'} — بقي الخط السابق كما هو.`, 'error');
    }
    setBusy(false);
  };

  return (
    <>
      <Section title="معاينة الخط قبل التطبيق">
        <div className="space-y-3 p-4">
          <div className="gcard rounded-2xl p-4 text-center" style={{ fontFamily: fontStack(prev) }}>
            <div className="t1 text-2xl leading-relaxed">بسم الله الرحمن الرحيم</div>
            <div className="t1 mt-1 text-lg">{PREVIEW_TEXT}</div>
          </div>
          <div className="flex gap-2">
            <select value={slot} onChange={(e) => setSlot(e.target.value as FontSlot)}>
              {FONT_SLOTS.map((s) => <option key={s} value={s}>{FONT_SLOT_LABELS[s]}</option>)}
            </select>
            <button className="btn shrink-0" onClick={() => void apply(prev, [slot])}>تطبيق</button>
            <button className="btn btn-ghost shrink-0" onClick={() => void apply(prev, [...FONT_SLOTS])}>على الكل</button>
          </div>
        </div>
        <div className="max-h-72 overflow-y-auto">
          {all.map((f) => (
            <button key={f.id} className="flex w-full items-center justify-between px-4 py-2.5 text-start" style={{ background: prev === f.id ? 'var(--card-bc)' : undefined }} onClick={() => setPrev(f.id)}>
              <span className="t1 text-lg" style={{ fontFamily: fontStack(f.id) }}>أذاني ٠١٢ 345</span>
              <span className="t2 text-xs">{f.name}</span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="الخط الحالي لكل عنصر">
        {FONT_SLOTS.map((s) => (
          <Row key={s} label={FONT_SLOT_LABELS[s]} col>
            <select value={t.fonts[s]} onChange={(e) => void apply(e.target.value, [s])}>
              {all.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
          </Row>
        ))}
      </Section>

      <Section title="الحجم والوزن">
        <SliderRow label="حجم الخط" value={t.fontScale} min={0.8} max={1.4} step={0.05} onChange={(v) => themeStore.setPath('fontScale', v)} format={(v) => Math.round(v * 100) + '%'} />
        <Row label="الوزن" col>
          <Segmented value={t.fontWeight} onChange={(v) => themeStore.setPath('fontWeight', v)} options={[{ id: 'light', label: 'رفيع' }, { id: 'normal', label: 'عادي' }, { id: 'bold', label: 'عريض' }]} />
        </Row>
      </Section>

      <Section title="استيراد خط من الموبايل" hint="ملف ‎.ttf أو ‎.otf. يُفحص أولًا، فإن كان تالفًا أو غير مدعوم يبقى الخط السابق مع رسالة واضحة. يُحفظ داخل مخزن التطبيق.">
        <div className="p-4">
          <button className="btn w-full" disabled={busy} onClick={() => file.current?.click()}>
            <Type size={18} /> {busy ? 'جارٍ الفحص…' : 'اختيار ملف خط'}
          </button>
          <input ref={file} type="file" accept=".ttf,.otf,font/ttf,font/otf" className="hidden" onChange={(e) => { void onImport(e.target.files?.[0]); e.target.value = ''; }} />
        </div>
        {custom.map((f) => (
          <div key={f.id} className="flex items-center gap-3 px-4 py-2.5">
            <span className="t1 flex-1 text-lg" style={{ fontFamily: fontStack('custom:' + f.id) }}>{f.name}</span>
            <button className="p-1.5 text-red-400" aria-label="حذف الخط" onClick={async () => { await deleteFont(f.id); setPrev('cairo'); toast('تم حذف الخط'); }}>
              <Trash2 size={17} />
            </button>
          </div>
        ))}
        {!custom.length && <p className="t2 p-4 text-center text-xs">لا توجد خطوط مستوردة</p>}
      </Section>

      <button className="btn btn-ghost w-full" onClick={() => themeStore.set((x) => ({ ...x, fonts: DEFAULT_THEME.fonts, fontScale: 1, fontWeight: 'normal' }))}>
        إعادة ضبط الخطوط
      </button>
    </>
  );
}

export default function Appearance() {
  const [tab, setTab] = useState<Tab>('themes');
  return (
    <div className="screen-enter">
      <PageHeader title="المظهر والتخصيص" />
      <MiniPreview />
      <div className="no-scrollbar -mx-4 mb-4 flex gap-1.5 overflow-x-auto px-4">
        {TABS.map((x) => (
          <button key={x.id} className="chip" data-on={tab === x.id} onClick={() => setTab(x.id)}>{x.label}</button>
        ))}
      </div>
      {tab === 'themes' && <ThemesPanel />}
      {tab === 'colors' && <ColorsPanel />}
      {tab === 'bg' && <BackgroundPanel />}
      {tab === 'shape' && <ShapePanel />}
      {tab === 'display' && <DisplayPanel />}
      {tab === 'fonts' && <FontsPanel />}
    </div>
  );
}
