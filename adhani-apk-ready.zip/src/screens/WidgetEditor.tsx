// Widget editor: live canvas preview, templates, background/image crop, stickers, colors, fonts, shape, elements.
import { Copy, Download, FileUp, Home, Image as ImageIcon, Plus, Save, Share2, Trash2, Wand2 } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { BUILTIN_FONTS } from '../config/fonts';
import { getImage, paletteFromImage } from '../lib/assets';
import { fade } from '../lib/color';
import { downloadJson, readJsonFile, shareOrDownload } from '../lib/files';
import { setIn, uid } from '../lib/store';
import { useNow } from '../lib/ticker';
import { buildWidgetData, coverLimits, renderWidget, type WidgetEnv } from '../lib/widgetRender';
import {
  FRAMES, SHAPES, SIZE_DIMS, TEMPLATES, WIDGET_PALETTES, WIDGET_SECTIONS, applyTemplate, makeWidget, newSticker, sanitizeWidget,
  type WidgetDesign, type WSize,
} from '../lib/widgetTypes';
import { fontsStore, settingsStore, themeStore, toast, widgetsStore } from '../state/stores';
import { ColorField, Row, Section, Segmented, SelectRow, Sheet, SliderRow, ToggleRow } from '../ui/controls';
import { ImageLibrary } from '../ui/ImageLibrary';
import { Sortable } from '../ui/Sortable';

type Tab = 'templates' | 'bg' | 'image' | 'stickers' | 'colors' | 'font' | 'shape' | 'items';
const TABS: { id: Tab; label: string }[] = [
  { id: 'templates', label: 'القوالب' },
  { id: 'bg', label: 'الخلفية' },
  { id: 'image', label: 'ضبط الصورة' },
  { id: 'stickers', label: 'ملصقات وصور' },
  { id: 'colors', label: 'الألوان' },
  { id: 'font', label: 'الخط' },
  { id: 'shape', label: 'الشكل' },
  { id: 'items', label: 'العناصر' },
];

function useEnv(): WidgetEnv {
  const t = themeStore.use();
  return { themeColors: t.colors, widgetFontId: t.fonts.widget };
}

function TemplateThumb({ id, active, onPick, name }: { id: string; active: boolean; onPick: () => void; name: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const s = settingsStore.use();
  const env = useEnv();
  const minute = Math.floor(useNow().getTime() / 60000);
  useEffect(() => {
    if (ref.current) void renderWidget(ref.current, makeWidget(id, 'medium'), buildWidgetData(s, new Date()), env, 0.3);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, minute, s]);
  return (
    <button onClick={onPick} className="overflow-hidden rounded-2xl p-1.5 text-center" style={{ outline: active ? '2px solid var(--c-accent)' : '1px solid var(--card-bc)' }}>
      <canvas ref={ref} className="w-full rounded-xl" style={{ aspectRatio: '2/1' }} />
      <div className="t1 mt-1 text-[0.7rem]">{name}</div>
    </button>
  );
}

export default function WidgetEditor() {
  const store = widgetsStore.use();
  const s = settingsStore.use();
  const env = useEnv();
  const customFonts = fontsStore.use().items;
  const nowDate = useNow();
  const minute = Math.floor(nowDate.getTime() / 60000);
  const design = store.items.find((i) => i.id === store.activeId) ?? store.items[0];
  const [tab, setTab] = useState<Tab>('templates');
  const [mode, setMode] = useState<'off' | 'image' | 'sticker'>('off');
  const [selSticker, setSelSticker] = useState<string>('');
  const [saveName, setSaveName] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const cv = useRef<HTMLCanvasElement>(null);
  const dRef = useRef(design);
  dRef.current = design;
  const modeRef = useRef(mode);
  modeRef.current = mode;
  const selRef = useRef(selSticker);
  selRef.current = selSticker;
  const bgImg = useRef<HTMLImageElement | null>(null);
  const importRef = useRef<HTMLInputElement>(null);

  const edit = (fn: (d: WidgetDesign) => WidgetDesign) =>
    widgetsStore.set((w) => ({ ...w, items: w.items.map((i) => (i.id === design.id ? fn(i) : i)) }));
  const upd = (path: string, v: unknown) => edit((d) => setIn(d, path.split('.'), v) as WidgetDesign);

  // Live preview (re-render on any change, and every minute)
  const designKey = useMemo(() => JSON.stringify(design), [design]);
  useEffect(() => {
    if (cv.current) void renderWidget(cv.current, design, buildWidgetData(s, new Date()), env, 2);
    void getImage(design.bg.imageId).then((i) => (bgImg.current = i));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [designKey, minute, s, env.themeColors, env.widgetFontId]);

  // Pointer gestures on preview: drag to pan image / move sticker, pinch to zoom / resize
  const ptrs = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef(0);
  const toDesign = (e: React.PointerEvent) => {
    const r = cv.current!.getBoundingClientRect();
    const { W, H } = SIZE_DIMS[dRef.current.size] ? { W: SIZE_DIMS[dRef.current.size].w, H: SIZE_DIMS[dRef.current.size].h } : { W: 640, H: 320 };
    return { x: ((e.clientX - r.left) / r.width) * W, y: ((e.clientY - r.top) / r.height) * H, W, H };
  };
  const onDown = (e: React.PointerEvent) => {
    if (modeRef.current === 'off') return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.current.size === 2) {
      const [a, b] = [...ptrs.current.values()];
      pinch.current = Math.hypot(a.x - b.x, a.y - b.y);
    }
    if (modeRef.current === 'sticker' && ptrs.current.size === 1) {
      const p = toDesign(e), rect = (cv.current as any).__rect as { X: number; Y: number; RW: number; RH: number } | undefined;
      if (rect) {
        const px = (p.x - rect.X) / rect.RW, py = (p.y - rect.Y) / rect.RH;
        let best = '', bd = Infinity;
        for (const st of dRef.current.stickers) {
          const dist = Math.hypot((st.x - px) * rect.RW, (st.y - py) * rect.RH);
          if (dist < bd && dist < st.size * rect.RW * 0.75) { bd = dist; best = st.id; }
        }
        if (best) setSelSticker(best);
      }
    }
  };
  const onMove = (e: React.PointerEvent) => {
    const prev = ptrs.current.get(e.pointerId);
    if (!prev || modeRef.current === 'off') return;
    const r = cv.current!.getBoundingClientRect();
    const d = dRef.current;
    const { w: W, h: H } = SIZE_DIMS[d.size];
    const rect = (cv.current as any).__rect as { RW: number; RH: number } | undefined;
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.current.size >= 2) {
      const [a, b] = [...ptrs.current.values()];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinch.current > 0) {
        const k = dist / pinch.current;
        if (modeRef.current === 'image') upd('bg.zoom', Math.min(4, Math.max(1, d.bg.zoom * k)));
        else if (selRef.current) edit((x) => ({ ...x, stickers: x.stickers.map((st) => (st.id === selRef.current ? { ...st, size: Math.min(1, Math.max(0.05, st.size * k)) } : st)) }));
      }
      pinch.current = dist;
      return;
    }
    const dx = ((e.clientX - prev.x) / r.width) * W, dy = ((e.clientY - prev.y) / r.height) * H;
    if (modeRef.current === 'image' && bgImg.current && rect) {
      const lim = coverLimits(bgImg.current, rect.RW, rect.RH, d.bg.zoom);
      edit((x) => ({ ...x, bg: { ...x.bg, panX: Math.max(-1, Math.min(1, x.bg.panX + dx / lim.mx)), panY: Math.max(-1, Math.min(1, x.bg.panY + dy / lim.my)) } }));
    } else if (modeRef.current === 'sticker' && selRef.current && rect) {
      edit((x) => ({ ...x, stickers: x.stickers.map((st) => (st.id === selRef.current ? { ...st, x: Math.max(0, Math.min(1, st.x + dx / rect.RW)), y: Math.max(0, Math.min(1, st.y + dy / rect.RH)) } : st)) }));
    }
  };
  const onUp = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    pinch.current = 0;
  };

  const sticker = design.stickers.find((x) => x.id === selSticker);
  const editSticker = (patch: Partial<typeof design.stickers[number]>) =>
    edit((d) => ({ ...d, stickers: d.stickers.map((st) => (st.id === selSticker ? { ...st, ...patch } : st)) }));

  const fontOpts = [
    { id: 'theme', name: 'خط الويدجت في إعدادات التطبيق' },
    ...BUILTIN_FONTS.map((f) => ({ id: f.id, name: f.name })),
    ...customFonts.map((f) => ({ id: 'custom:' + f.id, name: f.name + ' (مستورد)' })),
  ];

  const takeColorsFromImage = async () => {
    const img = await getImage(design.bg.imageId);
    if (!img) return toast('اختر صورة خلفية أولًا', 'error');
    const p = paletteFromImage(img);
    edit((d) => ({
      ...d,
      linkTheme: false,
      bg: { ...d.bg, stops: [{ c: p.bg1, p: 0 }, { c: p.bg2, p: 1 }], overlay: fade(p.bg1, 0.45) },
      colors: { ...d.colors, text: p.text, text2: fade(p.text, 0.72), accent: p.accent, next: p.accent, icons: p.accent, border: fade(p.accent, 0.5) },
    }));
    toast('تم أخذ الألوان من الصورة', 'ok');
  };

  const exportPng = async () => {
    const c = cv.current;
    if (!c) return;
    await renderWidget(c, design, buildWidgetData(s, new Date()), env, 3);
    c.toBlob((b) => b && void shareOrDownload(`adhani-widget-${design.name}.png`, b), 'image/png');
    setTimeout(() => void renderWidget(c, design, buildWidgetData(s, new Date()), env, 2), 800);
  };

  const dims = SIZE_DIMS[design.size];
  const colorList: [string, string][] = [
    ['text', 'النص الأساسي'], ['text2', 'النص الثانوي'], ['accent', 'لون التمييز'], ['next', 'الصلاة الجاية'],
    ['icons', 'الأيقونات'], ['border', 'الحدود'], ['shadow', 'الظل'],
  ];

  return (
    <div className="screen-enter">
      <div className="mb-3 flex items-center justify-between">
        <h2 data-edit="textPrimary" className="f-heading t1 text-xl">محرر الويدجت</h2>
        <button className="btn !px-3 !py-2 !text-xs" onClick={() => setPinOpen(true)}>
          <Home size={15} /> أضف للشاشة الرئيسية
        </button>
      </div>

      {/* Widgets list */}
      <div className="no-scrollbar -mx-4 mb-3 flex items-center gap-1.5 overflow-x-auto px-4">
        {store.items.map((w) => (
          <button key={w.id} className="chip" data-on={w.id === design.id} onClick={() => { widgetsStore.set({ activeId: w.id }); setSelSticker(''); }}>
            {w.name}
          </button>
        ))}
        <button className="chip" onClick={() => { const w = makeWidget('night', 'medium', `ويدجت ${store.items.length + 1}`); widgetsStore.set((x) => ({ ...x, items: [...x.items, w], activeId: w.id })); }}>
          <Plus size={13} className="inline" /> جديد
        </button>
      </div>

      {/* Live preview */}
      <div className="gcard mb-3 p-3" data-edit="card">
        <div className="mx-auto" style={{ maxWidth: design.size === 'small' ? 260 : 440 }}>
          <div className="checker overflow-hidden rounded-2xl p-0">
            <canvas
              ref={cv}
              className="block w-full touch-none"
              style={{ aspectRatio: `${dims.w}/${dims.h}`, cursor: mode === 'off' ? 'default' : 'grab', outline: mode !== 'off' ? '2px dashed var(--c-accent)' : undefined }}
              onPointerDown={onDown}
              onPointerMove={onMove}
              onPointerUp={onUp}
              onPointerCancel={onUp}
            />
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5">
          <Segmented<WSize> value={design.size} onChange={(v) => upd('size', v)} options={(Object.keys(SIZE_DIMS) as WSize[]).map((k) => ({ id: k, label: SIZE_DIMS[k].label }))} />
        </div>
        <div className="mt-2 flex flex-wrap justify-center gap-1.5">
          <button className="chip" data-on={mode === 'image'} onClick={() => { setMode(mode === 'image' ? 'off' : 'image'); }}>تحريك/تكبير الصورة بالإصبع</button>
          <button className="chip" data-on={mode === 'sticker'} onClick={() => setMode(mode === 'sticker' ? 'off' : 'sticker')}>تحريك/تكبير الملصق</button>
        </div>
        <p className="t2 mt-2 text-center text-[0.68rem] leading-relaxed">
          الويدجت الحقيقية صورة ثابتة تتحدّث كل دقيقة (لا حركة ولا blur حي) — لذلك كل التأثيرات تُحسب مسبقًا داخل الصورة.
        </p>
      </div>

      <div className="no-scrollbar -mx-4 mb-4 flex gap-1.5 overflow-x-auto px-4">
        {TABS.map((x) => (
          <button key={x.id} className="chip" data-on={tab === x.id} onClick={() => setTab(x.id)}>{x.label}</button>
        ))}
      </div>

      {tab === 'templates' && (
        <>
          <Section title="القوالب (تُطبّق بضغطة وتبقى قابلة للتعديل)">
            <div className="grid grid-cols-2 gap-2 p-3">
              {TEMPLATES.map((t) => (
                <TemplateThumb key={t.id} id={t.id} name={t.name} active={design.template === t.id} onPick={() => edit((d) => applyTemplate(d, t.id))} />
              ))}
            </div>
          </Section>
          <Section title="اسم الويدجت وإدارتها">
            <div className="space-y-2 p-3">
              <input type="text" value={design.name} onChange={(e) => upd('name', e.target.value)} />
              <div className="flex flex-wrap gap-2">
                <button className="btn btn-ghost" onClick={() => { const c = { ...design, id: uid(), name: design.name + ' (نسخة)' }; widgetsStore.set((x) => ({ ...x, items: [...x.items, c], activeId: c.id })); }}>
                  <Copy size={15} /> تكرار
                </button>
                <button className="btn btn-ghost" onClick={() => edit((d) => ({ ...makeWidget(d.template, d.size, d.name), id: d.id }))}>
                  إعادة الضبط
                </button>
                <button
                  className="btn btn-danger"
                  disabled={store.items.length < 2}
                  onClick={() => widgetsStore.set((x) => { const items = x.items.filter((i) => i.id !== design.id); return { ...x, items, activeId: items[0].id }; })}
                >
                  <Trash2 size={15} /> حذف
                </button>
              </div>
            </div>
          </Section>
          <Section title="حفظ التصاميم وتصديرها">
            <div className="space-y-2 p-3">
              <div className="flex gap-2">
                <input type="text" placeholder="اسم للحفظ" value={saveName} onChange={(e) => setSaveName(e.target.value)} />
                <button className="btn shrink-0" onClick={() => {
                  if (!saveName.trim()) return toast('اكتب اسمًا للتصميم', 'error');
                  widgetsStore.set((x) => ({ ...x, saved: [...x.saved, { id: uid(), name: saveName.trim(), design }] }));
                  setSaveName('');
                  toast('تم حفظ التصميم', 'ok');
                }}><Save size={15} /> حفظ</button>
              </div>
              <div className="flex flex-wrap gap-2">
                <button className="btn btn-ghost" onClick={() => downloadJson('adhani-widget-' + design.name, { format: 'adhani-widget', version: 1, widget: design })}><Download size={15} /> تصدير ملف</button>
                <button className="btn btn-ghost" onClick={() => importRef.current?.click()}><FileUp size={15} /> استيراد ملف</button>
                <input ref={importRef} type="file" accept="application/json,.json" className="hidden" onChange={async (e) => {
                  const f = e.target.files?.[0];
                  e.target.value = '';
                  if (!f) return;
                  try {
                    const w = sanitizeWidget(await readJsonFile(f));
                    widgetsStore.set((x) => ({ ...x, items: [...x.items, w], activeId: w.id }));
                    toast('تم استيراد التصميم', 'ok');
                  } catch (err: any) {
                    toast(`ملف غير صالح: ${err.message}`, 'error');
                  }
                }} />
              </div>
            </div>
            {store.saved.map((sv) => (
              <div key={sv.id} className="flex items-center gap-2 px-4 py-2.5">
                <span className="t1 flex-1 truncate text-sm">{sv.name}</span>
                <button className="btn btn-ghost !px-3 !py-1.5 !text-xs" onClick={() => { const c = { ...sv.design, id: uid(), name: sv.name }; widgetsStore.set((x) => ({ ...x, items: [...x.items, c], activeId: c.id })); }}>فتح كويدجت</button>
                <button className="p-1.5 text-red-400" aria-label="حذف" onClick={() => widgetsStore.set((x) => ({ ...x, saved: x.saved.filter((i) => i.id !== sv.id) }))}><Trash2 size={16} /></button>
              </div>
            ))}
          </Section>
        </>
      )}

      {tab === 'bg' && (
        <>
          <Section title="نوع الخلفية">
            <div className="p-3">
              <Segmented value={design.bg.type} onChange={(v) => upd('bg.type', v)} options={[{ id: 'gradient', label: 'تدرّج' }, { id: 'solid', label: 'لون ثابت' }, { id: 'image', label: 'صورة' }]} />
            </div>
            {design.bg.type === 'solid' && <ColorField label="لون الخلفية" value={design.bg.solid} onChange={(v) => upd('bg.solid', v)} />}
            {design.bg.type === 'gradient' && (
              <>
                {design.bg.stops.map((st, i) => (
                  <div key={i} className="px-0">
                    <ColorField label={`نقطة اللون ${i + 1}`} value={st.c} onChange={(v) => upd(`bg.stops.${i}.c`, v)} />
                    <div className="flex items-center gap-3 px-4 pb-3">
                      <input type="range" min={0} max={1} step={0.01} value={st.p} onChange={(e) => upd(`bg.stops.${i}.p`, +e.target.value)} />
                      {design.bg.stops.length > 2 && <button className="p-1 text-red-400" onClick={() => upd('bg.stops', design.bg.stops.filter((_, j) => j !== i))}><Trash2 size={16} /></button>}
                    </div>
                  </div>
                ))}
                <div className="p-3">
                  <button className="btn btn-ghost w-full" disabled={design.bg.stops.length >= 5} onClick={() => upd('bg.stops', [...design.bg.stops, { c: '#8fb8ffff', p: 0.5 }])}><Plus size={15} /> إضافة نقطة لون</button>
                </div>
                <SliderRow label="زاوية التدرّج" value={design.bg.angle} min={0} max={360} step={5} onChange={(v) => upd('bg.angle', v)} format={(v) => v + '°'} />
              </>
            )}
            {design.bg.type === 'image' && (
              <div className="space-y-3 p-3">
                <ImageLibrary selected={design.bg.imageId} onPick={(id) => edit((d) => ({ ...d, bg: { ...d.bg, imageId: id, type: 'image', zoom: 1, panX: 0, panY: 0 } }))} />
                <button className="btn w-full" onClick={() => void takeColorsFromImage()}><Wand2 size={16} /> خد الألوان تلقائيًا من الصورة</button>
              </div>
            )}
          </Section>
        </>
      )}

      {tab === 'image' && (
        design.bg.type !== 'image' || !design.bg.imageId ? (
          <p className="t2 gcard p-5 text-center text-sm">اختر «صورة» كنوع للخلفية من تبويب الخلفية أولًا.</p>
        ) : (
          <Section title="ضبط صورة الخلفية" hint="يمكنك أيضًا تحريك الصورة بإصبع واحد وتكبيرها بإصبعين على المعاينة بعد تفعيل «تحريك الصورة».">
            <SliderRow label="التكبير" value={design.bg.zoom} min={1} max={4} step={0.02} onChange={(v) => upd('bg.zoom', v)} format={(v) => v.toFixed(2) + '×'} />
            <SliderRow label="الإزاحة الأفقية" value={design.bg.panX} min={-1} max={1} onChange={(v) => upd('bg.panX', v)} />
            <SliderRow label="الإزاحة الرأسية" value={design.bg.panY} min={-1} max={1} onChange={(v) => upd('bg.panY', v)} />
            <SliderRow label="التغبيش (يُحسب مسبقًا)" value={design.bg.blur} min={0} max={20} step={1} onChange={(v) => upd('bg.blur', v)} format={(v) => v + 'px'} />
            <SliderRow label="السطوع" value={design.bg.brightness} min={0.4} max={1.8} onChange={(v) => upd('bg.brightness', v)} />
            <SliderRow label="التباين" value={design.bg.contrast} min={0.5} max={1.8} onChange={(v) => upd('bg.contrast', v)} />
            <ColorField label="لون وتعتيم الطبقة فوق الصورة" value={design.bg.overlay} onChange={(v) => upd('bg.overlay', v)} />
            <Row label="إعادة ضبط وضع الصورة">
              <button className="btn btn-ghost" onClick={() => edit((d) => ({ ...d, bg: { ...d.bg, zoom: 1, panX: 0, panY: 0, blur: 0, brightness: 1, contrast: 1 } }))}>إعادة</button>
            </Row>
          </Section>
        )
      )}

      {tab === 'stickers' && (
        <>
          <Section title="إضافة زخرفة جاهزة">
            <div className="grid grid-cols-4 gap-2 p-3">
              {SHAPES.map((sh) => (
                <button key={sh.id} className="gcard p-2 text-center" onClick={() => { const st = newSticker({ shape: sh.id, color: design.colors.accent }); edit((d) => ({ ...d, stickers: [...d.stickers, st] })); setSelSticker(st.id); setMode('sticker'); }}>
                  <StickerPreview shape={sh.id} color={design.colors.accent} />
                  <div className="t1 mt-1 text-[0.65rem]">{sh.name}</div>
                </button>
              ))}
            </div>
          </Section>
          <Section title="إضافة صورة من مكتبتي كملصق">
            <div className="p-3">
              <ImageLibrary onPick={(id) => { const st = newSticker({ kind: 'image', imageId: id, frame: 'circle', size: 0.28, x: 0.2, y: 0.3, opacity: 1 }); edit((d) => ({ ...d, stickers: [...d.stickers, st] })); setSelSticker(st.id); setMode('sticker'); }} pickLabel="إضافة كملصق" />
            </div>
          </Section>
          <Section title={`العناصر المضافة (${design.stickers.length})`}>
            {design.stickers.map((st, i) => (
              <button key={st.id} className="flex w-full items-center justify-between px-4 py-2.5 text-start" style={{ background: st.id === selSticker ? 'var(--card-bc)' : undefined }} onClick={() => { setSelSticker(st.id); setMode('sticker'); }}>
                <span className="t1 text-sm">{st.kind === 'shape' ? SHAPES.find((x) => x.id === st.shape)?.name : 'صورة'} {i + 1}</span>
                <span className="t2 text-xs">{Math.round(st.size * 100)}%</span>
              </button>
            ))}
            {!design.stickers.length && <p className="t2 p-4 text-center text-xs">لا توجد ملصقات بعد</p>}
          </Section>
          {sticker && (
            <Section title="تعديل الملصق المحدد">
              <SliderRow label="الحجم" value={sticker.size} min={0.05} max={1} onChange={(v) => editSticker({ size: v })} format={(v) => Math.round(v * 100) + '%'} />
              <SliderRow label="الدوران" value={sticker.rot} min={-180} max={180} step={1} onChange={(v) => editSticker({ rot: v })} format={(v) => v + '°'} />
              <SliderRow label="الشفافية" value={sticker.opacity} min={0.05} max={1} onChange={(v) => editSticker({ opacity: v })} format={(v) => Math.round(v * 100) + '%'} />
              <SliderRow label="الموضع الأفقي" value={sticker.x} min={0} max={1} onChange={(v) => editSticker({ x: v })} />
              <SliderRow label="الموضع الرأسي" value={sticker.y} min={0} max={1} onChange={(v) => editSticker({ y: v })} />
              {sticker.kind === 'shape' ? (
                <ColorField label="لون الزخرفة" value={sticker.color} onChange={(v) => editSticker({ color: v })} />
              ) : (
                <Row label="إطار الصورة" col>
                  <Segmented value={sticker.frame} onChange={(v) => editSticker({ frame: v })} options={FRAMES.map((f) => ({ id: f.id, label: f.name }))} />
                </Row>
              )}
              <Row label="إجراءات">
                <div className="flex gap-2">
                  <button className="btn btn-ghost" onClick={() => { const c = { ...sticker, id: uid(), x: Math.min(1, sticker.x + 0.06), y: Math.min(1, sticker.y + 0.06) }; edit((d) => ({ ...d, stickers: [...d.stickers, c] })); setSelSticker(c.id); }}><Copy size={15} /></button>
                  <button className="btn btn-danger" onClick={() => { edit((d) => ({ ...d, stickers: d.stickers.filter((x) => x.id !== sticker.id) })); setSelSticker(''); }}><Trash2 size={15} /></button>
                </div>
              </Row>
            </Section>
          )}
        </>
      )}

      {tab === 'colors' && (
        <>
          <Section title="الربط بالتطبيق">
            <ToggleRow label="ربط الألوان بثيم التطبيق" sub="الويدجت تتبع ألوان وخط التطبيق تلقائيًا" on={design.linkTheme} onChange={(v) => upd('linkTheme', v)} />
          </Section>
          <Section title="ألوان جاهزة">
            <div className="no-scrollbar flex gap-2 overflow-x-auto p-3">
              {WIDGET_PALETTES.map((p) => (
                <button key={p.name} className="shrink-0 overflow-hidden rounded-2xl text-center" style={{ border: '1px solid var(--card-bc)', width: 84 }}
                  onClick={() => edit((d) => ({ ...d, linkTheme: false, colors: { ...p.colors }, bg: { ...d.bg, stops: [{ c: p.stops[0], p: 0 }, { c: p.stops[1], p: 1 }], solid: p.stops[0] } }))}>
                  <div className="h-12" style={{ background: `linear-gradient(160deg, ${p.stops[0]}, ${p.stops[1]})` }} />
                  <div className="t1 py-1 text-[0.7rem]">{p.name}</div>
                </button>
              ))}
            </div>
          </Section>
          <Section title="ألوان الويدجت" hint={design.linkTheme ? 'الألوان مربوطة بالتطبيق حاليًا — أوقف الربط لتعديلها.' : undefined}>
            {colorList.map(([k, label]) => (
              <ColorField key={k} label={label} value={(design.colors as any)[k]} onChange={(v) => upd('colors.' + k, v)} />
            ))}
            {design.bg.type === 'image' && <ColorField label="طبقة فوق الصورة" value={design.bg.overlay} onChange={(v) => upd('bg.overlay', v)} />}
            {design.bg.type === 'image' && (
              <Row label="الألوان من الصورة"><button className="btn" onClick={() => void takeColorsFromImage()}><ImageIcon size={15} /> تلقائي</button></Row>
            )}
          </Section>
        </>
      )}

      {tab === 'font' && (
        <>
          {(['title', 'time', 'counter'] as const).map((k) => (
            <Section key={k} title={k === 'title' ? 'العناوين (أسماء الصلوات)' : k === 'time' ? 'الأوقات' : 'العدّاد'}>
              <SelectRow label="الخط" value={design.fonts[k]} options={fontOpts} onChange={(v) => upd('fonts.' + k, v)} />
              <Row label="الوزن" col>
                <Segmented value={design.weights[k]} onChange={(v) => upd('weights.' + k, v)} options={[{ id: 'light', label: 'رفيع' }, { id: 'normal', label: 'عادي' }, { id: 'bold', label: 'عريض' }]} />
              </Row>
              <SliderRow label="الحجم" value={design.scales[k]} min={0.6} max={1.5} onChange={(v) => upd('scales.' + k, v)} format={(v) => Math.round(v * 100) + '%'} />
            </Section>
          ))}
          <Section title="الأرقام والوقت">
            <Row label="الأرقام" col><Segmented value={design.digits} onChange={(v) => upd('digits', v)} options={[{ id: 'arabic', label: 'عربية (٠١٢)' }, { id: 'latin', label: 'إنجليزية (012)' }]} /></Row>
            <Row label="نظام الساعة" col><Segmented value={design.hour12 ? '12' : '24'} onChange={(v) => upd('hour12', v === '12')} options={[{ id: '12', label: '١٢ ساعة' }, { id: '24', label: '٢٤ ساعة' }]} /></Row>
          </Section>
        </>
      )}

      {tab === 'shape' && (
        <>
          <Section title="شكل الويدجت">
            <SliderRow label="استدارة الزوايا" value={design.shape.radius} min={0} max={70} step={1} onChange={(v) => upd('shape.radius', v)} format={(v) => v + ''} />
            <SliderRow label="سُمك الحدود" value={design.shape.borderW} min={0} max={8} step={0.5} onChange={(v) => upd('shape.borderW', v)} format={(v) => v + ''} />
            <SliderRow label="الظل" value={design.shape.shadow} min={0} max={36} step={1} onChange={(v) => upd('shape.shadow', v)} format={(v) => v + ''} />
            <SliderRow label="التوهّج (Glow)" value={design.shape.glow} min={0} max={36} step={1} onChange={(v) => upd('shape.glow', v)} format={(v) => v + ''} />
            <SliderRow label="المسافات الداخلية" value={design.shape.padding} min={6} max={44} step={1} onChange={(v) => upd('shape.padding', v)} format={(v) => v + ''} />
          </Section>
          <Section title="تصميم العناصر">
            <Row label="العدّاد (الصلاة الجاية)" col>
              <Segmented value={design.layout.main} onChange={(v) => upd('layout.main', v)} options={[{ id: 'text', label: 'نص' }, { id: 'ring', label: 'حلقة' }, { id: 'bar', label: 'شريط' }]} />
            </Row>
            <Row label="قائمة المواقيت" col>
              <Segmented value={design.layout.list} onChange={(v) => upd('layout.list', v)} options={[{ id: 'rows', label: 'صفوف' }, { id: 'cards', label: 'بطاقات ملوّنة' }, { id: 'inline', label: 'مضغوطة' }]} />
            </Row>
            <Row label="الزخرفة الخلفية" col>
              <Segmented value={design.layout.deco} onChange={(v) => upd('layout.deco', v)} options={[{ id: 'none', label: 'بدون' }, { id: 'stars', label: 'نجوم' }, { id: 'gold', label: 'إطار ذهبي' }, { id: 'geo', label: 'هندسية' }]} />
            </Row>
          </Section>
        </>
      )}

      {tab === 'items' && (
        <>
          <Section title="إظهار / إخفاء">
            <ToggleRow label="التاريخ الهجري" on={design.show.hijri} onChange={(v) => upd('show.hijri', v)} />
            <ToggleRow label="اسم المدينة" on={design.show.city} onChange={(v) => upd('show.city', v)} />
            <ToggleRow label="الشروق" on={design.show.sunrise} onChange={(v) => upd('show.sunrise', v)} />
            <ToggleRow label="التاريخ الميلادي" on={design.show.gregorian} onChange={(v) => upd('show.gregorian', v)} />
            <ToggleRow label="أيقونات الصلوات" on={design.show.icons} onChange={(v) => upd('show.icons', v)} />
            <ToggleRow label="الوقت المتبقي" on={design.show.remaining} onChange={(v) => upd('show.remaining', v)} />
          </Section>
          <Section title="ترتيب العناصر" hint="اسحب المقبض لتغيير الترتيب.">
            <Sortable items={design.order} onChange={(o) => upd('order', o)} render={(id) => <span className="t1 text-sm">{WIDGET_SECTIONS[id]}</span>} />
          </Section>
        </>
      )}

      <Sheet open={pinOpen} onClose={() => setPinOpen(false)} title="إضافة الويدجت للشاشة الرئيسية">
        <div className="t2 space-y-3 text-sm leading-relaxed">
          <p>
            الويدجت الأصلية (<code dir="ltr">requestPinAppWidget</code>) تحتاج تطبيق أندرويد مثبّتًا، ولا يمكن لصفحة ويب إنشاءها. الخيارات المتاحة من هنا:
          </p>
          <ol className="list-decimal space-y-1.5 ps-5">
            <li>احفظ الويدجت كصورة PNG عالية الجودة (يمكن مشاركتها أو استخدامها كخلفية/ويدجت صورة بتطبيقات تدعم ذلك).</li>
            <li>ثبّت التطبيق نفسه على الشاشة الرئيسية من قائمة المتصفح («تثبيت التطبيق»).</li>
          </ol>
          <div className="flex flex-wrap gap-2 pt-1">
            <button className="btn" onClick={() => void exportPng()}><Share2 size={16} /> حفظ / مشاركة كصورة</button>
          </div>
          <p className="text-xs">في النسخة الأصلية (Kotlin/Capacitor) يُستخدم نفس محرك الرسم هذا ليولّد Bitmap كل دقيقة ويضعه في RemoteViews.</p>
        </div>
      </Sheet>
    </div>
  );
}

function StickerPreview({ shape, color }: { shape: string; color: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const d = makeWidget('night', 'small');
    d.bg.type = 'solid';
    d.bg.solid = '#00000000';
    d.layout.deco = 'none';
    d.shape = { radius: 0, borderW: 0, shadow: 0, glow: 0, padding: 0 };
    d.show = { hijri: false, city: false, sunrise: false, gregorian: false, icons: false, remaining: false };
    d.order = [];
    d.stickers = [newSticker({ shape: shape as any, color, x: 0.5, y: 0.5, size: 0.7, opacity: 1 })];
    void renderWidget(c, d, buildWidgetData(settingsStore.get(), new Date()), { themeColors: themeStore.get().colors, widgetFontId: 'cairo' }, 0.25);
  }, [shape, color]);
  return <canvas ref={ref} className="mx-auto block h-12 w-12" />;
}
