// Settings: calculation, manual adjustments, iqama, reminders, quiet mode, extras.
import { ChevronLeft, MapPin } from 'lucide-react';
import { useEffect, useState } from 'react';
import { CITIES } from '../config/cities';
import { deviceTz } from '../lib/format';
import { refreshGps, setCity, setManualCoords } from '../lib/location';
import { METHODS } from '../config/settings';
import { setWakeLock, wakeLockSupported } from '../lib/notify';
import { fireAdhan } from '../lib/scheduler';
import { useDisplay, useSchedule } from '../lib/hooks';
import { ALL_KEYS, PRAYERS, PRAYER_NAMES } from '../lib/types';
import { back, go } from '../state/nav';
import { settingsStore, toast } from '../state/stores';
import { PageHeader, Row, Section, SelectRow, Segmented, Stepper, ToggleRow } from '../ui/controls';

function LinkRow({ label, sub, onClick }: { label: string; sub?: string; onClick: () => void }) {
  return (
    <button className="flex w-full items-center justify-between gap-3 px-4 py-3 text-start" onClick={onClick}>
      <span>
        <span className="t1 block text-sm">{label}</span>
        {sub && <span className="t2 block text-xs">{sub}</span>}
      </span>
      <ChevronLeft size={18} className="t2" />
    </button>
  );
}

export default function Settings() {
  const { settings: s } = useDisplay();
  const { sch } = useSchedule();
  const d = useDisplay();
  const set = settingsStore.set;

  useEffect(() => {
    void setWakeLock(s.keepAwake);
  }, [s.keepAwake]);

  return (
    <div className="screen-enter">
      <PageHeader title="الإعدادات" onBack={back} />

      <Section title="الموقع">
        <LinkRow label={s.location.name} sub={s.location.mode === 'gps' ? 'تحديد تلقائي بالـ GPS' : 'مدينة محددة يدويًا'} onClick={() => go('location')} />
      </Section>

      <Section title="حساب المواقيت" hint="الحساب كله يتم على الجهاز بدون إنترنت باستخدام مكتبة Adhan. تتحدّث المواقيت تلقائيًا عند تغيير الموقع أو المنطقة الزمنية أو التوقيت الصيفي.">
        <SelectRow label="طريقة الحساب" value={s.method} options={METHODS.map((m) => ({ id: m.id, name: m.name }))} onChange={(v) => set({ method: v as typeof s.method })} />
        <Row label="المذهب (وقت العصر)" col>
          <Segmented value={s.madhab} onChange={(v) => set({ madhab: v })} options={[{ id: 'shafi', label: 'الجمهور (الشافعي/المالكي/الحنبلي)' }, { id: 'hanafi', label: 'الحنفي' }]} />
        </Row>
        <Row label="فرق التاريخ الهجري" sub="لمطابقة رؤية الهلال في بلدك">
          <Stepper value={s.hijriOffset} min={-2} max={2} unit="يوم" onChange={(v) => set({ hijriOffset: v })} />
        </Row>
      </Section>

      <Section title="تعديل المواقيت يدويًا" hint="أضف أو أنقص دقائق ليطابق توقيت مسجدك. القيمة تُضاف فوق الحساب مباشرة.">
        {ALL_KEYS.map((k) => (
          <Row key={k} label={PRAYER_NAMES[k]} sub={d.time(sch.today[k])}>
            <Stepper value={s.adjust[k]} min={-30} max={30} onChange={(v) => settingsStore.setPath('adjust.' + k, v)} />
          </Row>
        ))}
      </Section>

      <Section title="الإقامة" hint="وقت الإقامة = وقت الأذان + المدة. تذكير الإقامة = الإقامة − عدد الدقائق المحدد.">
        {PRAYERS.map((p) => (
          <Row key={p} label={`مدة الإقامة بعد ${PRAYER_NAMES[p]}`}>
            <Stepper value={s.iqamaMin[p]} min={1} max={60} onChange={(v) => settingsStore.setPath('iqamaMin.' + p, v)} />
          </Row>
        ))}
        <ToggleRow label="تذكير قبل الإقامة" on={s.iqamaReminder} onChange={(v) => set({ iqamaReminder: v })} />
        <Row label="التذكير قبل الإقامة بـ">
          <Stepper value={s.iqamaBefore} min={1} max={20} onChange={(v) => set({ iqamaBefore: v })} />
        </Row>
      </Section>

      <Section title="تذكيرات أخرى" hint="هذه هي الإشعارات الوحيدة في التطبيق: الأذان، تذكير الإقامة، وتذكيرات اختيارية. لا إشعارات ترويجية إطلاقًا.">
        <ToggleRow label="تذكير قبل خروج وقت الصلاة" on={s.endReminder} onChange={(v) => set({ endReminder: v })} />
        <Row label="قبل خروج الوقت بـ">
          <Stepper value={s.endReminderMin} min={5} max={90} step={5} onChange={(v) => set({ endReminderMin: v })} />
        </Row>
        <ToggleRow label="تذكير الجمعة" sub="قبل الظهر بساعة" on={s.fridayReminder} onChange={(v) => set({ fridayReminder: v })} />
        <ToggleRow label="تذكير سورة الكهف" on={s.kahfReminder} onChange={(v) => set({ kahfReminder: v })} />
        <ToggleRow label="أذكار بعد الأذان" sub="تظهر بعد انتهاء الأذان" on={s.showAdhkar} onChange={(v) => set({ showAdhkar: v })} />
      </Section>

      <Section title="وضع رمضان">
        <ToggleRow label="تفعيل وضع رمضان" sub="عدّ تنازلي للإمساك والإفطار في شهر رمضان" on={s.ramadanMode} onChange={(v) => set({ ramadanMode: v })} />
        <Row label="تنبيه السحور قبل الفجر بـ">
          <Stepper value={s.preFajrMin} min={10} max={120} step={5} onChange={(v) => set({ preFajrMin: v })} />
        </Row>
      </Section>

      <Section title="الهدوء بعد الأذان" hint="يوقف التذكيرات الصوتية داخل التطبيق للمدة المحددة. المتصفح لا يستطيع تفعيل وضع الصامت في النظام نفسه.">
        <ToggleRow label="تفعيل الهدوء بعد الأذان" on={s.quietAfter} onChange={(v) => set({ quietAfter: v })} />
        <Row label="المدة">
          <Stepper value={s.quietMinutes} min={1} max={90} onChange={(v) => set({ quietMinutes: v })} />
        </Row>
      </Section>

      <Section title="الاعتمادية">
        <ToggleRow
          label="إبقاء الشاشة مضاءة"
          sub={wakeLockSupported() ? 'يمنع انطفاء الشاشة ليبقى الأذان مضمونًا أثناء فتح التطبيق' : 'غير مدعوم في هذا المتصفح'}
          on={s.keepAwake}
          onChange={(v) => {
            set({ keepAwake: v });
            if (v && !wakeLockSupported()) toast('الميزة غير مدعومة في متصفحك', 'error');
          }}
        />
        <LinkRow label="الصلاحيات" sub="الإشعارات، الموقع، الصوت" onClick={() => go('permissions')} />
        <LinkRow label="توفير الطاقة لكل ماركة" sub="سامسونج، شاومي، أوبو، هواوي" onClick={() => go('battery')} />
        <LinkRow label="حدود الويب (مهم)" sub="ما يعمل وما لا يعمل والتطبيق مغلق" onClick={() => go('limits')} />
        <Row label="اختبار الأذان" sub="يشغّل شاشة الأذان والإشعار الآن">
          <button className="btn" onClick={() => void fireAdhan('asr', 'full')}>جرّب الآن</button>
        </Row>
      </Section>
    </div>
  );
}

export function LocationScreen() {
  const { settings: s } = useDisplay();
  return <LocationInner mode={s.location.mode} />;
}


function LocationInner({ mode }: { mode: 'gps' | 'city' }) {
  const s = settingsStore.use();
  const [q, setQ] = useState('');
  const [lat, setLat] = useState(String(s.location.lat));
  const [lon, setLon] = useState(String(s.location.lon));
  const [name, setName] = useState('');
  const [tz, setTz] = useState(s.location.tz);
  const [busy, setBusy] = useState(false);
  const zones: string[] = (Intl as any).supportedValuesOf?.('timeZone') ?? [deviceTz(), 'Africa/Cairo', 'Asia/Riyadh', 'UTC'];
  const list = CITIES.filter((c) => c.name.includes(q.trim()));

  return (
    <div className="screen-enter">
      <PageHeader title="الموقع" onBack={back} />
      <Section title="تلقائي">
        <div className="p-4">
          <button
            className="btn w-full"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              await refreshGps(true);
              setBusy(false);
            }}
          >
            <MapPin size={18} /> {busy ? 'جارٍ التحديد…' : 'تحديد موقعي بالـ GPS'}
          </button>
          <p className="t2 mt-2 text-xs">
            الحالي: {s.location.name} {mode === 'gps' ? '(GPS)' : '(يدوي)'} · {s.location.lat.toFixed(3)}, {s.location.lon.toFixed(3)} · {s.location.tz}
          </p>
        </div>
      </Section>

      <Section title="اختيار مدينة يدويًا">
        <div className="p-3">
          <input type="search" placeholder="ابحث عن مدينة…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="max-h-72 overflow-y-auto">
          {list.map((c) => (
            <button
              key={c.id}
              className="flex w-full items-center justify-between px-4 py-2.5 text-start"
              style={{ background: s.location.cityId === c.id && s.location.mode === 'city' ? 'var(--card-bc)' : undefined }}
              onClick={() => {
                setCity(c);
                toast(`تم اختيار ${c.name}`, 'ok');
              }}
            >
              <span className="t1 text-sm">{c.name}</span>
              <span className="t2 text-xs">{c.tz.split('/')[1]?.replace('_', ' ')}</span>
            </button>
          ))}
          {!list.length && <p className="t2 p-4 text-center text-sm">لا توجد نتائج — استخدم الإحداثيات بالأسفل</p>}
        </div>
      </Section>

      <Section title="إحداثيات مخصصة">
        <div className="space-y-2 p-4">
          <div className="grid grid-cols-2 gap-2" dir="ltr">
            <input type="text" inputMode="decimal" placeholder="Latitude" value={lat} onChange={(e) => setLat(e.target.value)} />
            <input type="text" inputMode="decimal" placeholder="Longitude" value={lon} onChange={(e) => setLon(e.target.value)} />
          </div>
          <input type="text" placeholder="اسم المكان (اختياري)" value={name} onChange={(e) => setName(e.target.value)} />
          <select value={tz} onChange={(e) => setTz(e.target.value)}>
            {zones.map((z) => (
              <option key={z} value={z}>{z}</option>
            ))}
          </select>
          <button
            className="btn w-full"
            onClick={() => {
              const la = parseFloat(lat), lo = parseFloat(lon);
              if (!isFinite(la) || !isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) return toast('إحداثيات غير صحيحة', 'error');
              setManualCoords(la, lo, name, tz);
              toast('تم حفظ الموقع', 'ok');
            }}
          >
            حفظ
          </button>
        </div>
      </Section>
    </div>
  );
}
