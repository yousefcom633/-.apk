// Battery-saver guides per brand + the honest "web limits" explanation.
import { useState } from 'react';
import { back } from '../state/nav';
import { PageHeader, Section } from '../ui/controls';

const BRANDS: { name: string; steps: string[] }[] = [
  {
    name: 'سامسونج (One UI)',
    steps: [
      'الإعدادات ← العناية بالجهاز ← البطارية ← حدود استخدام الخلفية.',
      'عطّل «وضع السكون للتطبيقات غير المستخدمة» وأزل المتصفح/التطبيق من «التطبيقات النائمة» و«التطبيقات النائمة العميقة».',
      'الإعدادات ← التطبيقات ← اختر المتصفح (Chrome) ← البطارية ← «غير مقيّد».',
      'اترك وضع توفير الطاقة معطّلًا وقت الصلاة قدر الإمكان.',
    ],
  },
  {
    name: 'شاومي / ريدمي / بوكو (MIUI / HyperOS)',
    steps: [
      'الإعدادات ← التطبيقات ← إدارة التطبيقات ← اختر المتصفح ← «التشغيل التلقائي» فعّله.',
      'من نفس الصفحة: «توفير البطارية» ← «بدون قيود».',
      'افتح التطبيقات الأخيرة ← اضغط مطوّلًا على بطاقة المتصفح ← «قفل» (أيقونة القفل) حتى لا يُغلق.',
      'الأمان ← الأذونات ← «بدء التشغيل التلقائي» فعّل المتصفح.',
    ],
  },
  {
    name: 'أوبو / ريلمي / ون بلس (ColorOS / OxygenOS)',
    steps: [
      'الإعدادات ← البطارية ← المزيد ← تحسين البطارية ← اختر المتصفح ← «عدم التحسين».',
      'الإعدادات ← إدارة التطبيقات ← المتصفح ← استخدام البطارية ← فعّل «السماح بالنشاط في الخلفية» و«السماح بالتشغيل التلقائي».',
      'في شاشة التطبيقات الأخيرة اسحب بطاقة التطبيق لأسفل أو اضغط الثلاث نقاط ← «قفل».',
    ],
  },
  {
    name: 'هواوي / أونر (EMUI / MagicOS)',
    steps: [
      'الإعدادات ← البطارية ← إطلاق التطبيقات (Launch) ← اختر المتصفح ← عطّل «الإدارة التلقائية».',
      'فعّل الخيارات الثلاثة: «التشغيل التلقائي» و«التشغيل الثانوي» و«التشغيل في الخلفية».',
      'الإعدادات ← التطبيقات ← المتصفح ← البطارية ← «السماح بالنشاط في الخلفية».',
      'اقفل التطبيق في قائمة التطبيقات الأخيرة بالضغط على أيقونة القفل.',
    ],
  },
  {
    name: 'أندرويد الأصلي / بكسل',
    steps: [
      'الإعدادات ← التطبيقات ← المتصفح ← البطارية ← «غير مقيّد».',
      'تجنّب «توفير البطارية» وقت الأذان؛ فهو يقيّد المهام الخلفية.',
    ],
  },
];

export function BatteryScreen() {
  const [open, setOpen] = useState<string | null>(BRANDS[0].name);
  return (
    <div className="screen-enter">
      <PageHeader title="توفير الطاقة لكل ماركة" onBack={back} />
      <p className="t2 mb-4 text-sm leading-relaxed">
        كل شركة تضيف نظام توفير طاقة خاص يغلق التطبيقات في الخلفية. لكي يصلك الأذان في وقته، استثنِ التطبيق (أو المتصفح الذي يعمل فيه) من هذه القيود.
      </p>
      {BRANDS.map((b) => (
        <div key={b.name} className="gcard mb-2.5 overflow-hidden" data-edit="card">
          <button className="flex w-full items-center justify-between px-4 py-3.5 text-start" onClick={() => setOpen(open === b.name ? null : b.name)}>
            <span className="f-heading t1 text-sm">{b.name}</span>
            <span className="t2">{open === b.name ? '−' : '+'}</span>
          </button>
          {open === b.name && (
            <ol className="t2 list-decimal space-y-2 px-8 pb-4 text-xs leading-relaxed">
              {b.steps.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          )}
        </div>
      ))}
    </div>
  );
}

export function LimitsScreen() {
  return (
    <div className="screen-enter">
      <PageHeader title="حدود تطبيق الويب (مهم)" onBack={back} />
      <Section title="ما يعمل بشكل ممتاز">
        <ul className="t1 list-disc space-y-1.5 px-9 py-4 text-sm leading-relaxed">
          <li>حساب المواقيت كاملًا بدون إنترنت (مكتبة Adhan) وكل طرق الحساب والتعديل اليدوي.</li>
          <li>التطبيق كله، التخصيص، الخطوط، الألوان، الويدجت ومحررها، القبلة، المتتبع، السبحة، التقويم.</li>
          <li>الأذان والتنبيهات <b>أثناء بقاء التطبيق مفتوحًا</b> (حتى لو الشاشة مقفولة ما دام المتصفح حيًّا وبالتعليمات في شاشة توفير الطاقة).</li>
          <li>إيقاف الأذان من الإشعار ومن أزرار التحكم في شاشة القفل (Media Session).</li>
        </ul>
      </Section>
      <Section title="ما لا يستطيع المتصفح فعله">
        <ul className="t1 list-disc space-y-1.5 px-9 py-4 text-sm leading-relaxed">
          <li><b>تشغيل الأذان والتطبيق مغلق تمامًا</b>: لا توجد AlarmManager ولا Foreground Service ولا BootReceiver في الويب، والمتصفح يجمّد الصفحات الخلفية.</li>
          <li>جدولة 14 يومًا مسبقًا عبر WorkManager: غير متاحة؛ تُحسب المواقيت لحظيًا بدل ذلك.</li>
          <li>قنوات الإشعارات (Notification Channels) المنفصلة، وتفعيل وضع الصامت بالنظام، واستثناء البطارية برمجيًا.</li>
          <li>ويدجت الشاشة الرئيسية (AppWidget) و requestPinAppWidget: غير ممكنة من الويب. محرر الويدجت هنا يرسم الويدجت بـ Canvas ويصدّرها كصورة PNG.</li>
          <li>الويدجت الحقيقية لا تدعم الحركة أو الـ blur الحي — لذلك التغبيش يُحسب مسبقًا داخل الصورة، وهذا ما يفعله المحرر.</li>
        </ul>
      </Section>
      <Section title="للحصول على أذان موثوق 100% والتطبيق مغلق">
        <div className="t2 space-y-2 px-5 py-4 text-sm leading-relaxed">
          <p>
            الحل هو تغليف هذا التطبيق كتطبيق أندرويد: إما <b>Capacitor</b> (مع @capacitor/local-notifications وجدولة الإشعارات المحلية بصوت الأذان) أو إعادة بناء النواة بـ
            <b> Kotlin + Jetpack Compose</b> مع AlarmManager.setExactAndAllowWhileIdle وForeground Service وBootReceiver وWorkManager.
          </p>
          <p>
            كل منطق الحساب والتخصيص والويدجت المكتوب هنا قابل للنقل: ملف الأصوات config/adhanSounds.ts، ونموذج الثيم config/themes.ts، ومحرك رسم الويدجت lib/widgetRender.ts.
          </p>
        </div>
      </Section>
    </div>
  );
}
