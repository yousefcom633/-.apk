// Extra features: Qibla compass, prayer tracker (streaks, no nagging notifications), tasbih + adhkar.
import { Compass, RotateCcw } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { ADHKAR, TASBIH_PRESETS } from '../config/adhkar';
import { dayKey } from '../lib/format';
import { useDisplay } from '../lib/hooks';
import { qiblaBearing } from '../lib/prayer';
import { PRAYERS, PRAYER_NAMES } from '../lib/types';
import { back } from '../state/nav';
import { tasbihStore, trackerStore } from '../state/stores';
import { PageHeader, Row, Section } from '../ui/controls';

export function QiblaScreen() {
  const d = useDisplay();
  const bearing = qiblaBearing(d.settings.location.lat, d.settings.location.lon);
  const [heading, setHeading] = useState<number | null>(null);
  const [perm, setPerm] = useState<'ok' | 'need' | 'none'>('need');
  const smooth = useRef<number | null>(null);
  const wasAligned = useRef(false);

  const start = async () => {
    const DOE = (window as any).DeviceOrientationEvent;
    if (DOE?.requestPermission) {
      try {
        if ((await DOE.requestPermission()) !== 'granted') return setPerm('none');
      } catch {
        return setPerm('none');
      }
    }
    setPerm('ok');
  };

  useEffect(() => {
    if (perm !== 'ok') return;
    const onOri = (e: any) => {
      let h: number | null = null;
      if (typeof e.webkitCompassHeading === 'number') h = e.webkitCompassHeading;
      else if (e.absolute && typeof e.alpha === 'number') h = (360 - e.alpha) % 360;
      else if (typeof e.alpha === 'number' && e.type === 'deviceorientationabsolute') h = (360 - e.alpha) % 360;
      if (h === null) return;
      // low-pass filter on the circle
      const prev = smooth.current ?? h;
      let diff = ((h - prev + 540) % 360) - 180;
      diff *= 0.25;
      smooth.current = (prev + diff + 360) % 360;
      setHeading(smooth.current);
    };
    window.addEventListener('deviceorientationabsolute', onOri as EventListener, true);
    window.addEventListener('deviceorientation', onOri as EventListener, true);
    return () => {
      window.removeEventListener('deviceorientationabsolute', onOri as EventListener, true);
      window.removeEventListener('deviceorientation', onOri as EventListener, true);
    };
  }, [perm]);

  const diff = heading === null ? 180 : ((bearing - heading + 540) % 360) - 180;
  const aligned = heading !== null && Math.abs(diff) < 3;
  useEffect(() => {
    if (aligned && !wasAligned.current) navigator.vibrate?.([60, 40, 120]);
    wasAligned.current = aligned;
  }, [aligned]);

  const rot = heading ?? 0;
  return (
    <div className="screen-enter">
      <PageHeader title="بوصلة القبلة" onBack={back} />
      <div className="flex flex-col items-center gap-4">
        <div className="relative" style={{ width: 290, height: 290 }}>
          <div className="absolute left-1/2 top-[-10px] z-10 -translate-x-1/2" style={{ width: 0, height: 0, borderLeft: '10px solid transparent', borderRight: '10px solid transparent', borderTop: `18px solid ${aligned ? 'var(--c-nextGlow)' : 'var(--c-accent)'}` }} />
          <div
            className="gcard absolute inset-0 rounded-full transition-shadow"
            style={{ borderRadius: '50%', transform: `rotate(${-rot}deg)`, transition: 'transform .12s linear', boxShadow: aligned ? '0 0 40px 4px var(--c-nextGlow)' : undefined, borderColor: aligned ? 'var(--c-nextGlow)' : undefined }}
          >
            {Array.from({ length: 72 }).map((_, i) => (
              <div key={i} className="absolute left-1/2 top-0 h-full" style={{ transform: `translateX(-50%) rotate(${i * 5}deg)` }}>
                <div style={{ width: i % 6 === 0 ? 3 : 1.5, height: i % 6 === 0 ? 14 : 7, background: 'var(--c-textSecondary)', opacity: i % 6 === 0 ? 0.9 : 0.4, margin: '6px auto 0' }} />
              </div>
            ))}
            {[['ش', 0], ['ق', 90], ['ج', 180], ['غ', 270]].map(([l, a]) => (
              <div key={String(l)} className="absolute left-1/2 top-0 h-full" style={{ transform: `translateX(-50%) rotate(${a}deg)` }}>
                <div className="f-heading t1 text-sm" style={{ marginTop: 26, transform: `rotate(${-(a as number)}deg)`, color: l === 'ش' ? 'var(--c-nextGlow)' : undefined }}>{l}</div>
              </div>
            ))}
            <div className="absolute left-1/2 top-0 h-full" style={{ transform: `translateX(-50%) rotate(${bearing}deg)` }}>
              <div className="mx-auto mt-14 text-3xl" style={{ filter: 'drop-shadow(0 0 8px var(--c-nextGlow))' }}>🕋</div>
              <div className="mx-auto mt-1 h-20 w-[3px] rounded-full" style={{ background: 'var(--c-nextGlow)' }} />
            </div>
          </div>
          <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full" style={{ background: 'var(--c-accent)' }} />
        </div>
        <div className="text-center">
          <div className="f-num f-heading text-3xl" style={{ color: aligned ? 'var(--c-nextGlow)' : 'var(--c-textPrimary)' }}>{d.num(Math.round(bearing))}°</div>
          <div className="t2 mt-1 text-sm">
            {heading === null ? 'اتجاه القبلة من شمال الحقيقي لموقعك' : aligned ? '✓ أنت في اتجاه القبلة' : diff > 0 ? 'لف يمينًا' : 'لف يسارًا'}
          </div>
        </div>
        {perm !== 'ok' && (
          <button className="btn" onClick={() => void start()}>
            <Compass size={18} /> {perm === 'none' ? 'تم رفض الحساس — حاول مجددًا' : 'تشغيل حساس البوصلة'}
          </button>
        )}
        <p className="t2 max-w-xs text-center text-xs leading-relaxed">
          الزاوية محسوبة على الجهاز بدون إنترنت. للدقة ابتعد عن المعادن والمغناطيس وحرّك الهاتف على شكل ٨ لمعايرة الحساس.
        </p>
      </div>
    </div>
  );
}

export function TrackerScreen() {
  const d = useDisplay();
  const days = trackerStore.use().days;
  const now = new Date();
  const keyOf = (off: number) => dayKey(new Date(now.getTime() - off * 86400000), d.tz);
  const today = keyOf(0);
  const count = (k: string) => PRAYERS.filter((p) => days[k]?.[p]).length;
  const week = Array.from({ length: 7 }, (_, i) => ({ k: keyOf(6 - i), n: count(keyOf(6 - i)) }));
  const total = week.reduce((a, x) => a + x.n, 0);
  let streak = 0;
  for (let i = count(today) === 5 ? 0 : 1; i < 400; i++) {
    if (count(keyOf(i)) === 5) streak++;
    else break;
  }
  const weekdayName = (k: string) => new Intl.DateTimeFormat('ar', { weekday: 'short', timeZone: 'UTC' }).format(new Date(k + 'T12:00:00Z'));

  return (
    <div className="screen-enter">
      <PageHeader title="متتبع الصلوات" onBack={back} />
      <div className="mb-4 grid grid-cols-3 gap-2 text-center">
        {[['متتالية', d.num(streak) + ' يوم'], ['هذا الأسبوع', `${d.num(total)}/${d.num(35)}`], ['اليوم', `${d.num(count(today))}/${d.num(5)}`]].map(([l, v]) => (
          <div key={l} className="gcard p-3" data-edit="card">
            <div className="f-num f-heading tacc text-xl" style={{ color: 'var(--c-nextGlow)' }}>{v}</div>
            <div className="t2 text-xs">{l}</div>
          </div>
        ))}
      </div>
      <Section title="اليوم" hint="بدون تذكيرات ضاغطة — علامة هادئة لنفسك فقط.">
        {PRAYERS.map((p) => (
          <Row key={p} label={PRAYER_NAMES[p]}>
            <button className="chip" data-on={!!days[today]?.[p]} onClick={() => trackerStore.set((s) => ({ days: { ...s.days, [today]: { ...s.days[today], [p]: !s.days[today]?.[p] } } }))}>
              {days[today]?.[p] ? '✓ صليت' : 'لم أصلِّ بعد'}
            </button>
          </Row>
        ))}
      </Section>
      <Section title="آخر ٧ أيام">
        <div className="flex items-end justify-between gap-2 px-4 py-5" style={{ height: 150 }}>
          {week.map((x) => (
            <div key={x.k} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
              <div className="f-num t2 text-[0.65rem]">{d.num(x.n)}</div>
              <div className="w-full rounded-lg transition-all" style={{ height: `${Math.max(6, (x.n / 5) * 78)}%`, background: x.n === 5 ? 'var(--c-nextGlow)' : 'var(--c-accent)', opacity: x.n ? 1 : 0.25 }} />
              <div className="t2 text-[0.65rem]">{weekdayName(x.k)}</div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

export function TasbihScreen() {
  const d = useDisplay();
  const t = tasbihStore.use();
  const progress = Math.min(1, t.count / t.target);
  const R = 120, C = 2 * Math.PI * R;
  const tap = () => {
    const next = t.count + 1;
    tasbihStore.set({ count: next >= t.target ? 0 : next, total: t.total + 1 });
    navigator.vibrate?.(next >= t.target ? [80, 60, 160] : 15);
  };
  return (
    <div className="screen-enter">
      <PageHeader title="السبحة والأذكار" onBack={back} />
      <div className="no-scrollbar -mx-4 mb-4 flex gap-1.5 overflow-x-auto px-4">
        {TASBIH_PRESETS.map((p) => (
          <button key={p.text} className="chip" data-on={t.preset === p.text} onClick={() => tasbihStore.set({ preset: p.text, target: p.target, count: 0 })}>{p.text}</button>
        ))}
      </div>
      <div className="flex flex-col items-center">
        <button className="relative grid place-items-center" style={{ width: 280, height: 280 }} onClick={tap} aria-label="سبّح">
          <svg viewBox="0 0 280 280" className="absolute inset-0" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="140" cy="140" r={R} fill="none" stroke="var(--card-bc)" strokeWidth="12" />
            <circle cx="140" cy="140" r={R} fill="none" stroke="var(--c-ring)" strokeWidth="12" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - progress)} style={{ transition: 'stroke-dashoffset .2s', filter: 'drop-shadow(0 0 8px var(--c-ring))' }} />
          </svg>
          <div className="gcard grid h-[220px] w-[220px] place-items-center text-center" style={{ borderRadius: '50%' }}>
            <div>
              <div className="f-heading t2 text-base">{t.preset}</div>
              <div className="f-num t1 text-6xl">{d.num(t.count)}</div>
              <div className="t2 text-xs">من {d.num(t.target)}</div>
            </div>
          </div>
        </button>
        <div className="mt-3 flex items-center gap-3">
          <span className="t2 text-xs">الإجمالي: <b className="f-num t1">{d.num(t.total)}</b></span>
          <button className="btn btn-ghost !py-1.5 !text-xs" onClick={() => tasbihStore.set({ count: 0 })}><RotateCcw size={14} /> تصفير</button>
        </div>
      </div>
      <Section title="أذكار بعد الصلاة">
        {ADHKAR.map((z, i) => (
          <div key={i} className="flex items-start justify-between gap-3 px-4 py-3">
            <span className="t1 text-sm leading-relaxed">{z.text}</span>
            {z.count > 1 && <span className="f-num tacc shrink-0 text-sm">×{d.num(z.count)}</span>}
          </div>
        ))}
      </Section>
    </div>
  );
}
