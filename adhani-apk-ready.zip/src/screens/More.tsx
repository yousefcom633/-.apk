// "More" menu + backup / restore of all settings and themes.
import {
  Battery, BookOpen, CalendarDays, Compass, Database, Download, Info, MapPin, MoonStar, Settings as Cog, ShieldCheck, Upload, ListChecks, CircleDot, type LucideIcon,
} from 'lucide-react';
import { useRef, useState } from 'react';
import { dumpBlobs, restoreBlobs } from '../lib/assets';
import { downloadJson, readJsonFile } from '../lib/files';
import { storageKeyPrefix } from '../lib/store';
import { back, go, type Screen } from '../state/nav';
import { toast } from '../state/stores';
import { PageHeader, Row, Section, ToggleRow } from '../ui/controls';

const ITEMS: { id: Screen; label: string; sub: string; icon: LucideIcon }[] = [
  { id: 'settings', label: 'الإعدادات', sub: 'الحساب، الإقامة، التذكيرات', icon: Cog },
  { id: 'qibla', label: 'بوصلة القبلة', sub: 'بالحساس مع تنبيه عند الاتجاه الصحيح', icon: Compass },
  { id: 'tracker', label: 'متتبع الصلوات', sub: 'إحصائيات أسبوعية وسلسلة أيام', icon: ListChecks },
  { id: 'tasbih', label: 'السبحة والأذكار', sub: 'عدّاد وأذكار بعد الصلاة', icon: CircleDot },
  { id: 'calendar', label: 'التقويم الهجري', sub: 'مع المناسبات الإسلامية', icon: CalendarDays },
  { id: 'ramadan', label: 'وضع رمضان', sub: 'الإمساك والإفطار والسحور', icon: MoonStar },
  { id: 'location', label: 'الموقع', sub: 'GPS أو اختيار مدينة', icon: MapPin },
  { id: 'permissions', label: 'الصلاحيات', sub: 'لماذا نحتاج كل صلاحية', icon: ShieldCheck },
  { id: 'battery', label: 'توفير الطاقة', sub: 'سامسونج · شاومي · أوبو · هواوي', icon: Battery },
  { id: 'limits', label: 'حدود تطبيق الويب', sub: 'ما يعمل وما لا يعمل والتطبيق مغلق', icon: Info },
  { id: 'backup', label: 'نسخ احتياطي واستعادة', sub: 'كل الإعدادات والثيمات والويدجت', icon: Database },
];

export default function More() {
  return (
    <div className="screen-enter">
      <PageHeader title="المزيد" />
      <div className="space-y-2.5">
        {ITEMS.map((it) => (
          <button key={it.id} className="gcard flex w-full items-center gap-3 px-4 py-3.5 text-start" data-edit="card" onClick={() => go(it.id)}>
            <span className="grid h-10 w-10 place-items-center rounded-full" style={{ background: 'var(--card-bc)' }}>
              <it.icon size={20} className="ticon" data-edit="icons" />
            </span>
            <span className="flex-1">
              <span className="f-heading t1 block text-sm" data-edit="textPrimary">{it.label}</span>
              <span className="t2 block text-xs" data-edit="textSecondary">{it.sub}</span>
            </span>
          </button>
        ))}
      </div>
      <div className="gcard mt-4 flex items-start gap-3 p-4" data-edit="card">
        <BookOpen size={20} className="ticon mt-0.5 shrink-0" />
        <p className="t2 text-xs leading-relaxed">
          «أذاني» يعمل بدون إنترنت، بلا إعلانات ولا أدوات تتبّع ولا حساب مستخدم. كل بياناتك تبقى على جهازك فقط.
        </p>
      </div>
    </div>
  );
}

export function BackupScreen() {
  const [withFiles, setWithFiles] = useState(true);
  const [busy, setBusy] = useState(false);
  const file = useRef<HTMLInputElement>(null);

  const doExport = async () => {
    setBusy(true);
    try {
      const keys: Record<string, string> = {};
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i)!;
        if (k.startsWith(storageKeyPrefix) && k !== storageKeyPrefix + 'fired') keys[k] = localStorage.getItem(k)!;
      }
      const blobs = withFiles ? await dumpBlobs() : undefined;
      downloadJson('adhani-backup', { format: 'adhani-backup', version: 1, date: new Date().toISOString(), keys, blobs });
      toast('تم إنشاء النسخة الاحتياطية', 'ok');
    } catch {
      toast('تعذّر إنشاء النسخة الاحتياطية', 'error');
    }
    setBusy(false);
  };

  const doImport = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try {
      const data = await readJsonFile(f);
      if (!data || data.format !== 'adhani-backup' || typeof data.keys !== 'object') throw new Error('الملف ليس نسخة احتياطية من أذاني');
      // validate every value is JSON before touching anything
      for (const [k, v] of Object.entries<string>(data.keys)) {
        if (!k.startsWith(storageKeyPrefix)) throw new Error('الملف يحتوي على مفاتيح غير معروفة');
        JSON.parse(v);
      }
      for (const [k, v] of Object.entries<string>(data.keys)) localStorage.setItem(k, v);
      if (data.blobs) await restoreBlobs(data.blobs);
      toast('تمت الاستعادة — جارٍ إعادة التشغيل…', 'ok');
      setTimeout(() => location.reload(), 900);
    } catch (e: any) {
      toast(`تعذّرت الاستعادة: ${e.message ?? 'ملف غير صالح'}. لم يتغيّر شيء.`, 'error');
    }
    setBusy(false);
  };

  return (
    <div className="screen-enter">
      <PageHeader title="نسخ احتياطي واستعادة" onBack={back} />
      <Section title="يشمل الإعدادات، الثيمات، الويدجت، المتتبع والسبحة" hint="الملفات المستوردة (الخطوط، الصور، الأصوات) تُضمَّن داخل النسخة عند تفعيل الخيار، وقد يكبر حجم الملف.">
        <ToggleRow label="تضمين الخطوط والصور والأصوات المستوردة" on={withFiles} onChange={setWithFiles} />
        <Row label="تصدير">
          <button className="btn" disabled={busy} onClick={() => void doExport()}><Download size={16} /> إنشاء نسخة</button>
        </Row>
        <Row label="استعادة" sub="تستبدل الإعدادات الحالية">
          <button className="btn btn-ghost" disabled={busy} onClick={() => file.current?.click()}><Upload size={16} /> اختيار ملف</button>
          <input ref={file} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { void doImport(e.target.files?.[0]); e.target.value = ''; }} />
        </Row>
      </Section>
    </div>
  );
}
