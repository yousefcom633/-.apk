// Permissions explainer (also used as first-run onboarding): why each permission is needed.
import { Bell, BatteryCharging, Database, Download, MapPin, Volume2, type LucideIcon } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { playChime, unlockAudio } from '../lib/audio';
import { refreshGps } from '../lib/location';
import { notifPermission, requestNotifPermission, setWakeLock, wakeLockSupported } from '../lib/notify';
import { back, go } from '../state/nav';
import { onboardStore, settingsStore, toast } from '../state/stores';
import { PageHeader } from '../ui/controls';

function Item({ icon: Icon, title, why, status, action }: { icon: LucideIcon; title: string; why: string; status?: ReactNode; action?: ReactNode }) {
  return (
    <div className="gcard mb-3 p-4" data-edit="card">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-full" style={{ background: 'var(--card-bc)' }}>
          <Icon size={20} className="ticon" />
        </span>
        <div className="flex-1">
          <div className="f-heading t1 text-sm">{title}</div>
          {status && <div className="text-xs" style={{ color: 'var(--c-accent)' }}>{status}</div>}
        </div>
      </div>
      <p className="t2 mt-2 text-xs leading-relaxed">{why}</p>
      {action && <div className="mt-3 flex flex-wrap gap-2">{action}</div>}
    </div>
  );
}

export default function Permissions({ onboarding }: { onboarding?: boolean }) {
  const [notif, setNotif] = useState(notifPermission());
  const [geo, setGeo] = useState<string>('unknown');
  const [persisted, setPersisted] = useState<boolean | null>(null);
  const [installEvt, setInstallEvt] = useState<any>((window as any).__installEvt ?? null);

  useEffect(() => {
    navigator.permissions?.query({ name: 'geolocation' as PermissionName }).then((r) => setGeo(r.state)).catch(() => undefined);
    navigator.storage?.persisted?.().then(setPersisted).catch(() => undefined);
    const h = (e: Event) => {
      e.preventDefault();
      (window as any).__installEvt = e;
      setInstallEvt(e);
    };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  return (
    <div className="screen-enter">
      {onboarding ? (
        <div className="mb-5 pt-6 text-center">
          <h1 className="f-heading t1 text-3xl">أذاني</h1>
          <p className="t2 mt-2 text-sm leading-relaxed">مواقيت الصلاة والأذان — بدون إعلانات، بدون تتبع، بدون حساب، وتعمل بدون إنترنت.</p>
        </div>
      ) : (
        <PageHeader title="الصلاحيات" onBack={back} />
      )}

      <Item
        icon={Bell}
        title="الإشعارات"
        status={notif === 'granted' ? '✓ مفعّلة' : notif === 'denied' ? 'مرفوضة — فعّلها من إعدادات المتصفح' : notif === 'unsupported' ? 'غير مدعومة' : 'غير مفعّلة'}
        why="لإظهار إشعار الأذان وتذكير الإقامة وتذكيرات الجمعة. لن نرسل أي إشعار آخر أو ترويجي."
        action={<button className="btn" onClick={async () => setNotif(await requestNotifPermission())}>السماح بالإشعارات</button>}
      />
      <Item
        icon={MapPin}
        title="الموقع (GPS)"
        status={geo === 'granted' ? '✓ مسموح' : geo === 'denied' ? 'مرفوض — يمكنك اختيار مدينة يدويًا' : undefined}
        why="لحساب المواقيت بدقة لمكانك. الإحداثيات تبقى على جهازك فقط ولا تُرسل لأي خادم. بدونه اختر مدينتك يدويًا."
        action={
          <>
            <button className="btn" onClick={async () => { if (await refreshGps(true)) setGeo('granted'); }}>تحديد موقعي</button>
            <button className="btn btn-ghost" onClick={() => go('location')}>اختيار مدينة</button>
          </>
        }
      />
      <Item
        icon={Volume2}
        title="تشغيل الصوت"
        why="المتصفحات تمنع الصوت التلقائي حتى يتفاعل المستخدم مع الصفحة. اضغط الزر مرة لتجربة الصوت وتفعيله، وأبقِ التطبيق مفتوحًا وقت الصلاة."
        action={<button className="btn" onClick={() => { unlockAudio(); playChime(settingsStore.get().volume); }}>اختبار الصوت</button>}
      />
      <Item
        icon={BatteryCharging}
        title="إبقاء الشاشة مضاءة / استثناء البطارية"
        why="الأذان يعمل فقط والتطبيق حيّ. أبقِ الشاشة مضاءة وأخرج المتصفح من تحسين البطارية حتى لا يُجمَّد في الخلفية. الشرح لكل ماركة في شاشة 'توفير الطاقة'."
        action={
          <>
            {wakeLockSupported() && (
              <button className="btn" onClick={async () => { settingsStore.set({ keepAwake: true }); await setWakeLock(true); toast('الشاشة ستبقى مضاءة أثناء فتح التطبيق', 'ok'); }}>
                إبقاء الشاشة مضاءة
              </button>
            )}
            <button className="btn btn-ghost" onClick={() => go('battery')}>إرشادات الماركات</button>
          </>
        }
      />
      <Item
        icon={Database}
        title="تخزين دائم"
        status={persisted ? '✓ مفعّل' : undefined}
        why="يمنع المتصفح من مسح إعداداتك وخطوطك وصورك المستوردة عند امتلاء مساحة الجهاز."
        action={<button className="btn" onClick={async () => setPersisted((await navigator.storage?.persist?.()) ?? false)}>طلب التخزين الدائم</button>}
      />
      <Item
        icon={Download}
        title="تثبيت التطبيق على الشاشة الرئيسية"
        why="التثبيت كتطبيق (PWA) يجعله يعمل بدون إنترنت وبنافذة مستقلة. من قائمة المتصفح: «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»."
        action={installEvt ? <button className="btn" onClick={async () => { installEvt.prompt(); await installEvt.userChoice; }}>تثبيت الآن</button> : undefined}
      />
      <button className="btn btn-ghost mb-3 w-full" onClick={() => go('limits')}>اقرأ: ما الذي لا يستطيع الويب فعله؟</button>
      {onboarding && (
        <button className="btn w-full !py-3.5" onClick={() => onboardStore.set({ done: true })}>
          ابدأ الاستخدام
        </button>
      )}
    </div>
  );
}
