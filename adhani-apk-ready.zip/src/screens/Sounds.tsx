// "أصوات الأذان": muezzin list with preview, import custom audio, per-prayer selection.
import { Check, Pause, Play, Trash2, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { ADHAN_SOUNDS } from '../config/adhanSounds';
import { VIBRATIONS } from '../config/settings';
import { deleteSound, importSound, listSounds, resolveSoundUrl } from '../lib/assets';
import { playerStore, playUrl, stopPlayback } from '../lib/audio';
import { fireAdhan } from '../lib/scheduler';
import { MODE_LABELS, MODE_ORDER, PRAYERS, PRAYER_NAMES, type AlertMode } from '../lib/types';
import { settingsStore, soundsStore, toast } from '../state/stores';
import { PageHeader, Row, Section, SelectRow, SliderRow, ToggleRow } from '../ui/controls';

export default function Sounds() {
  const s = settingsStore.use();
  const player = playerStore.use();
  soundsStore.use();
  const [busy, setBusy] = useState(false);
  const [asFajr, setAsFajr] = useState(false);
  const file = useRef<HTMLInputElement>(null);
  const sounds = listSounds();

  const preview = async (id: string, name: string) => {
    if (player.playing && player.id === id) return stopPlayback();
    const url = await resolveSoundUrl(id);
    const r = url ? await playUrl({ id, label: name, url, volume: s.volume, gradual: false }) : 'missing';
    if (r === 'missing') {
      const def = ADHAN_SOUNDS.find((x) => x.id === id);
      toast(def ? `ملف الصوت غير موجود: ${def.src} — ضعه في public/sounds أو عدّل config/adhanSounds.ts` : 'تعذّر تشغيل الملف', 'error');
    } else if (r === 'blocked') toast('المتصفح منع التشغيل — جرّب مرة أخرى', 'error');
  };

  const onImport = async (f?: File) => {
    if (!f) return;
    setBusy(true);
    try {
      await importSound(f, asFajr);
      toast('تمت إضافة المؤذن الجديد', 'ok');
    } catch (e: any) {
      toast(e.message ?? 'تعذّر استيراد الملف', 'error');
    }
    setBusy(false);
  };

  const soundOpts = sounds.map((x) => ({ id: x.id, name: x.name }));

  return (
    <div className="screen-enter">
      <PageHeader title="أصوات الأذان" />

      <Section title="المؤذنون" hint="الأصوات معرّفة في ملف config/adhanSounds.ts — ضع ملفات mp3 في public/sounds/ وغيّر الأسماء من هناك بدون تعديل الكود.">
        {sounds.map((x) => {
          const playing = player.playing && player.id === x.id;
          const isDefault = s.defaultSoundId === x.id, isFajr = s.fajrSoundId === x.id;
          return (
            <div key={x.id} className="flex items-center gap-3 px-4 py-3">
              <button className="btn !h-11 !w-11 shrink-0 !p-0" onClick={() => void preview(x.id, x.name)} aria-label={playing ? 'إيقاف' : 'معاينة'}>
                {playing ? <Pause size={18} /> : <Play size={18} />}
              </button>
              <div className="min-w-0 flex-1">
                <div className="t1 truncate text-sm">{x.name}</div>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  <button className="chip !py-0.5 !text-[0.7rem]" data-on={isDefault} onClick={() => settingsStore.set({ defaultSoundId: x.id })}>
                    {isDefault && <Check size={11} className="inline" />} الافتراضي
                  </button>
                  <button className="chip !py-0.5 !text-[0.7rem]" data-on={isFajr} onClick={() => settingsStore.set({ fajrSoundId: x.id })}>
                    {isFajr && <Check size={11} className="inline" />} للفجر
                  </button>
                  {x.fajr && <span className="t2 self-center text-[0.7rem]">صيغة فجر</span>}
                </div>
              </div>
              {x.custom && (
                <button
                  className="p-2 text-red-400"
                  aria-label="حذف"
                  onClick={async () => {
                    await deleteSound(x.id);
                    const st = settingsStore.get();
                    settingsStore.set({
                      defaultSoundId: st.defaultSoundId === x.id ? 'afasy' : st.defaultSoundId,
                      fajrSoundId: st.fajrSoundId === x.id ? 'fajr-salah' : st.fajrSoundId,
                      sounds: Object.fromEntries(PRAYERS.map((p) => [p, st.sounds[p] === x.id ? 'auto' : st.sounds[p]])) as typeof st.sounds,
                    });
                    toast('تم حذف المؤذن');
                  }}
                >
                  <Trash2 size={18} />
                </button>
              )}
            </div>
          );
        })}
      </Section>

      <Section title="استيراد مؤذن من الموبايل">
        <ToggleRow label="هذا الصوت أذان فجر" sub="يحتوي على «الصلاة خير من النوم»" on={asFajr} onChange={setAsFajr} />
        <div className="p-4">
          <button className="btn w-full" disabled={busy} onClick={() => file.current?.click()}>
            <Upload size={18} /> {busy ? 'جارٍ الفحص…' : 'اختيار ملف صوت (mp3 / ogg)'}
          </button>
          <input ref={file} type="file" accept="audio/*,.mp3,.ogg,.m4a,.wav" className="hidden" onChange={(e) => { void onImport(e.target.files?.[0]); e.target.value = ''; }} />
        </div>
      </Section>

      <Section title="صوت وتنبيه كل صلاة">
        {PRAYERS.map((p) => (
          <div key={p} className="space-y-2 px-4 py-3">
            <div className="f-heading t1 text-sm">{PRAYER_NAMES[p]}</div>
            <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
              {MODE_ORDER.map((m: AlertMode) => (
                <button key={m} className="chip" data-on={s.modes[p] === m} onClick={() => settingsStore.setPath('modes.' + p, m)}>
                  {MODE_LABELS[m]}
                </button>
              ))}
            </div>
            <select value={s.sounds[p]} onChange={(e) => settingsStore.setPath('sounds.' + p, e.target.value)} disabled={s.modes[p] !== 'full'} style={{ opacity: s.modes[p] === 'full' ? 1 : 0.5 }}>
              <option value="auto">{p === 'fajr' ? 'تلقائي (صوت الفجر)' : 'تلقائي (الصوت الافتراضي)'}</option>
              {soundOpts.map((o) => (
                <option key={o.id} value={o.id}>{o.name}</option>
              ))}
            </select>
          </div>
        ))}
      </Section>

      <Section title="مستوى الصوت والاهتزاز">
        <SliderRow label="مستوى الصوت" value={s.volume} min={0.05} max={1} step={0.05} onChange={(v) => settingsStore.set({ volume: v })} format={(v) => Math.round(v * 100) + '%'} />
        <ToggleRow label="زيادة تدريجية للصوت" sub="يبدأ هادئًا ثم يرتفع خلال ١٥ ثانية" on={s.gradual} onChange={(v) => settingsStore.set({ gradual: v })} />
        <SelectRow label="نمط الاهتزاز" value={s.vibration} options={Object.entries(VIBRATIONS).map(([id, v]) => ({ id, name: v.name }))}
          onChange={(v) => { settingsStore.set({ vibration: v }); navigator.vibrate?.(VIBRATIONS[v].pattern); }} />
        <Row label="تجربة كاملة" sub="تشغّل شاشة الأذان والإشعار كما تظهر وقت الصلاة">
          <div className="flex gap-2">
            <button className="btn" onClick={() => void fireAdhan('dhuhr', 'full')}>جرّب الأذان</button>
          </div>
        </Row>
      </Section>
    </div>
  );
}
