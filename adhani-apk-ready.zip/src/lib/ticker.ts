// One shared 1-second clock. It runs inside a Web Worker when possible because worker timers are
// throttled far less than main-thread timers when the tab is in the background.
import { createStore } from './store';

export const tickStore = createStore<{ now: number }>(null, { now: Date.now() });
let started = false;

export function startTicker() {
  if (started) return;
  started = true;
  const beat = () => tickStore.set({ now: Date.now() });
  try {
    const url = URL.createObjectURL(new Blob(['setInterval(function(){postMessage(1)},1000)'], { type: 'text/javascript' }));
    const w = new Worker(url);
    w.onmessage = beat;
    w.onerror = () => setInterval(beat, 1000);
  } catch {
    setInterval(beat, 1000);
  }
  document.addEventListener('visibilitychange', beat);
  window.addEventListener('focus', beat);
}

export function useNow(): Date {
  return new Date(tickStore.use().now);
}
