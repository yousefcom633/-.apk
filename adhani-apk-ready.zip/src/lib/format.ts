// Formatting helpers: digits, time, durations, Gregorian + Hijri dates.
import type { DigitMode } from './types';

const AR = '٠١٢٣٤٥٦٧٨٩';

/** Convert every digit in a string to Arabic-Indic or Latin digits. */
export function toDigits(s: string | number, mode: DigitMode): string {
  const latin = String(s).replace(/[٠-٩]/g, (d) => String(AR.indexOf(d)));
  return mode === 'arabic' ? latin.replace(/\d/g, (d) => AR[+d]) : latin;
}

export function deviceTz(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

const safeTz = (tz: string) => {
  try {
    new Intl.DateTimeFormat('en', { timeZone: tz });
    return tz;
  } catch {
    return deviceTz();
  }
};

export function fmtTime(d: Date, tz: string, hour12: boolean, digits: DigitMode, seconds = false): string {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: safeTz(tz),
    hour: 'numeric',
    minute: '2-digit',
    second: seconds ? '2-digit' : undefined,
    hourCycle: hour12 ? 'h12' : 'h23',
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  let h = get('hour');
  if (!hour12) h = h.padStart(2, '0');
  if (h === '24') h = '00';
  let out = `${h}:${get('minute')}${seconds ? ':' + get('second') : ''}`;
  if (hour12) out += ' ' + (get('dayPeriod').toUpperCase().startsWith('A') ? 'ص' : 'م');
  return toDigits(out, digits);
}

export function fmtDuration(ms: number, digits: DigitMode, hours = true): string {
  const t = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return toDigits(hours ? `${p(h)}:${p(m)}:${p(s)}` : `${p(h * 60 + m)}:${p(s)}`, digits);
}

/** Human readable remaining time, e.g. "ساعتان و ٥ دقائق". */
export function fmtRemainingWords(ms: number, digits: DigitMode): string {
  const m = Math.max(0, Math.round(ms / 60000));
  const h = Math.floor(m / 60), mm = m % 60;
  const parts: string[] = [];
  if (h) parts.push(`${toDigits(h, digits)} س`);
  parts.push(`${toDigits(mm, digits)} د`);
  return parts.join(' ');
}

export function ymdInTz(d: Date, tz: string) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: safeTz(tz),
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(d);
  const g = (t: string) => +(parts.find((p) => p.type === t)?.value ?? 0);
  return { y: g('year'), m: g('month'), d: g('day') };
}

export function dayKey(d: Date, tz: string): string {
  const { y, m, d: dd } = ymdInTz(d, tz);
  return `${y}-${String(m).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
}

/** 0 = Sunday ... 6 = Saturday, evaluated in the given timezone. */
export function weekdayInTz(d: Date, tz: string): number {
  const w = new Intl.DateTimeFormat('en-US', { timeZone: safeTz(tz), weekday: 'short' }).format(d);
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(w);
}

export const HIJRI_MONTHS = [
  'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة',
];

export function hijriOf(date: Date, tz: string, offsetDays = 0) {
  const d = new Date(date.getTime() + offsetDays * 86400000);
  let fmt: Intl.DateTimeFormat;
  try {
    fmt = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', {
      day: 'numeric', month: 'numeric', year: 'numeric', timeZone: safeTz(tz),
    });
  } catch {
    fmt = new Intl.DateTimeFormat('en-u-ca-islamic-civil-nu-latn', {
      day: 'numeric', month: 'numeric', year: 'numeric', timeZone: safeTz(tz),
    });
  }
  const parts = fmt.formatToParts(d);
  const g = (t: string) => parseInt(parts.find((p) => p.type === t)?.value ?? '1', 10);
  return { y: g('year') || g('relatedYear'), m: g('month'), d: g('day') };
}

export function fmtHijri(h: { y: number; m: number; d: number }, digits: DigitMode): string {
  return toDigits(`${h.d} ${HIJRI_MONTHS[(h.m - 1 + 12) % 12]} ${h.y} هـ`, digits);
}

export function fmtGregorian(d: Date, tz: string, digits: DigitMode, withWeekday = true): string {
  const s = new Intl.DateTimeFormat('ar-EG-u-nu-latn-ca-gregory', {
    timeZone: safeTz(tz),
    weekday: withWeekday ? 'long' : undefined,
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(d);
  return toDigits(s, digits);
}
