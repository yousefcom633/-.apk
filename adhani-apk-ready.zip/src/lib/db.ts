// IndexedDB blob storage for imported fonts, audio files and images (Data layer).

export type BlobStore = 'fonts' | 'sounds' | 'images';
const STORES: BlobStore[] = ['fonts', 'sounds', 'images'];
let dbp: Promise<IDBDatabase> | null = null;

function open(): Promise<IDBDatabase> {
  if (!dbp) {
    dbp = new Promise((res, rej) => {
      const r = indexedDB.open('adhani', 1);
      r.onupgradeneeded = () => {
        for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s);
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  return dbp;
}

function tx<T>(store: BlobStore, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return open().then(
    (db) =>
      new Promise<T>((res, rej) => {
        const req = fn(db.transaction(store, mode).objectStore(store));
        req.onsuccess = () => res(req.result);
        req.onerror = () => rej(req.error);
      })
  );
}

export const dbPut = (s: BlobStore, key: string, blob: Blob) => tx(s, 'readwrite', (o) => o.put(blob, key));
export const dbGet = (s: BlobStore, key: string) => tx<Blob | undefined>(s, 'readonly', (o) => o.get(key));
export const dbDel = (s: BlobStore, key: string) => tx(s, 'readwrite', (o) => o.delete(key));

export async function dbAll(s: BlobStore): Promise<{ key: string; blob: Blob }[]> {
  const keys = (await tx(s, 'readonly', (o) => o.getAllKeys())) as string[];
  const out: { key: string; blob: Blob }[] = [];
  for (const key of keys) {
    const blob = await dbGet(s, key);
    if (blob) out.push({ key, blob });
  }
  return out;
}

export function blobToDataUrl(b: Blob): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = () => rej(r.error);
    r.readAsDataURL(b);
  });
}

export async function dataUrlToBlob(u: string): Promise<Blob> {
  return (await fetch(u)).blob();
}
