// Shared React hooks that combine settings, theme (display prefs) and the clock.
import { fmtTime, fmtDuration, toDigits } from './format';
import { getSchedule } from './prayer';
import { useNow } from './ticker';
import { settingsStore, themeStore } from '../state/stores';

export function useDisplay() {
  const t = themeStore.use();
  const s = settingsStore.use();
  const tz = s.location.tz;
  return {
    theme: t,
    settings: s,
    tz,
    digits: t.digits,
    hour12: t.hour12,
    time: (d: Date, seconds = false) => fmtTime(d, tz, t.hour12, t.digits, seconds),
    num: (n: number | string) => toDigits(n, t.digits),
    dur: (ms: number, hours = true) => fmtDuration(ms, t.digits, hours),
  };
}

export function useSchedule() {
  const s = settingsStore.use();
  const now = useNow();
  return { now, s, sch: getSchedule(s, now) };
}
