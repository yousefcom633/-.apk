// Widget design model, templates and palettes (Domain layer). The renderer lives in widgetRender.ts.
import { uid } from './store';
import type { DigitMode, Weight } from './types';

export type WSize = 'small' | 'medium' | 'large';
export const SIZE_DIMS: Record<WSize, { w: number; h: number; label: string }> = {
  small: { w: 320, h: 320, label: 'صغير (٢×٢)' },
  medium: { w: 640, h: 320, label: 'متوسط (٤×٢)' },
  large: { w: 640, h: 640, label: 'كبير (٤×٤)' },
};

export type ShapeId = 'crescent' | 'lantern' | 'stars' | 'minaret' | 'geo' | 'star8' | 'dome';
export type FrameId = 'none' | 'circle' | 'rounded' | 'crescent' | 'star';

export const SHAPES: { id: ShapeId; name: string }[] = [
  { id: 'crescent', name: 'هلال' },
  { id: 'lantern', name: 'فانوس' },
  { id: 'stars', name: 'نجوم' },
  { id: 'minaret', name: 'مئذنة' },
  { id: 'geo', name: 'زخرفة هندسية' },
  { id: 'star8', name: 'نجمة ثمانية' },
  { id: 'dome', name: 'قبة' },
];
export const FRAMES: { id: FrameId; name: string }[] = [
  { id: 'none', name: 'بدون' },
  { id: 'circle', name: 'دائري' },
  { id: 'rounded', name: 'مستطيل مدوّر' },
  { id: 'crescent', name: 'هلال' },
  { id: 'star', name: 'نجمة' },
];

export interface WSticker {
  id: string;
  kind: 'shape' | 'image';
  shape: ShapeId;
  imageId: string;
  /** center position relative to widget (0..1) */
  x: number;
  y: number;
  /** size relative to widget width (0..1) */
  size: number;
  rot: number;
  opacity: number;
  frame: FrameId;
  color: string;
}

export interface WStop {
  c: string;
  p: number;
}

export interface WidgetDesign {
  id: string;
  name: string;
  size: WSize;
  template: string;
  /** When true, colors/fonts are taken live from the app ThemeState. */
  linkTheme: boolean;
  bg: {
    type: 'gradient' | 'solid' | 'image';
    stops: WStop[];
    angle: number;
    solid: string;
    imageId: string;
    zoom: number;
    panX: number;
    panY: number;
    blur: number;
    brightness: number;
    contrast: number;
    overlay: string;
  };
  colors: { text: string; text2: string; accent: string; next: string; icons: string; border: string; shadow: string };
  /** font id, or 'theme' = use app widget font */
  fonts: { title: string; time: string; counter: string };
  weights: { title: Weight; time: Weight; counter: Weight };
  scales: { title: number; time: number; counter: number };
  shape: { radius: number; borderW: number; shadow: number; glow: number; padding: number };
  show: { hijri: boolean; city: boolean; sunrise: boolean; gregorian: boolean; icons: boolean; remaining: boolean };
  digits: DigitMode;
  hour12: boolean;
  layout: { main: 'ring' | 'text' | 'bar'; list: 'rows' | 'cards' | 'inline'; deco: 'none' | 'stars' | 'gold' | 'geo' };
  order: string[];
  stickers: WSticker[];
}

export const WIDGET_SECTIONS: Record<string, string> = {
  header: 'الرأس (المدينة والتاريخ)',
  main: 'الصلاة الجاية والعدّاد',
  list: 'قائمة المواقيت',
};

export const BASE_WIDGET: WidgetDesign = {
  id: '',
  name: 'ويدجت',
  size: 'medium',
  template: 'night',
  linkTheme: false,
  bg: {
    type: 'gradient',
    stops: [{ c: '#0b1026ff', p: 0 }, { c: '#1b2a5cff', p: 1 }],
    angle: 160,
    solid: '#0b1026ff',
    imageId: '',
    zoom: 1,
    panX: 0,
    panY: 0,
    blur: 0,
    brightness: 1,
    contrast: 1,
    overlay: '#0b102666',
  },
  colors: {
    text: '#f4f7ffff', text2: '#a9b8e0ff', accent: '#8fb8ffff', next: '#e8c877ff',
    icons: '#8fb8ffff', border: '#ffffff30', shadow: '#00000099',
  },
  fonts: { title: 'theme', time: 'theme', counter: 'theme' },
  weights: { title: 'bold', time: 'normal', counter: 'bold' },
  scales: { title: 1, time: 1, counter: 1 },
  shape: { radius: 36, borderW: 1.5, shadow: 16, glow: 0, padding: 22 },
  show: { hijri: true, city: true, sunrise: true, gregorian: true, icons: true, remaining: true },
  digits: 'arabic',
  hour12: true,
  layout: { main: 'text', list: 'rows', deco: 'stars' },
  order: ['header', 'main', 'list'],
  stickers: [],
};

export interface WidgetTemplate {
  id: string;
  name: string;
  patch: (d: WidgetDesign) => Partial<WidgetDesign>;
}

const mergeW = (d: WidgetDesign, p: any): WidgetDesign => {
  const out: any = { ...d };
  for (const k of Object.keys(p)) {
    const v = p[k];
    out[k] = v && typeof v === 'object' && !Array.isArray(v) ? { ...(d as any)[k], ...v } : v;
  }
  return out;
};

export const TEMPLATES: WidgetTemplate[] = [
  {
    id: 'night',
    name: 'ليل بنجوم',
    patch: () => ({ layout: { main: 'text', list: 'rows', deco: 'stars' } }),
  },
  {
    id: 'glass',
    name: 'زجاجي شفاف',
    patch: () => ({
      bg: { type: 'gradient', stops: [{ c: '#ffffff38', p: 0 }, { c: '#ffffff12', p: 1 }], angle: 145 },
      colors: { text: '#ffffffff', text2: '#ffffffc0', accent: '#ffffffff', next: '#ffffffff', icons: '#ffffffff', border: '#ffffff66', shadow: '#00000055' },
      shape: { radius: 40, borderW: 2, shadow: 10, glow: 0, padding: 22 },
      layout: { main: 'text', list: 'rows', deco: 'none' },
    }),
  },
  {
    id: 'amoled',
    name: 'AMOLED بحواف مضيئة',
    patch: () => ({
      bg: { type: 'solid', solid: '#000000ff', stops: [{ c: '#000000ff', p: 0 }, { c: '#0a0a12ff', p: 1 }] },
      colors: { text: '#ffffffff', text2: '#9aa3bfff', accent: '#5ee1ffff', next: '#5ee1ffff', icons: '#5ee1ffff', border: '#5ee1ffff', shadow: '#5ee1ffaa' },
      shape: { radius: 34, borderW: 2.5, shadow: 0, glow: 18, padding: 22 },
      layout: { main: 'text', list: 'rows', deco: 'none' },
    }),
  },
  {
    id: 'gold',
    name: 'ذهبي فخم',
    patch: () => ({
      bg: { type: 'gradient', stops: [{ c: '#1a1206ff', p: 0 }, { c: '#4a3410ff', p: 1 }], angle: 150 },
      colors: { text: '#fff3d1ff', text2: '#cdb98aff', accent: '#e8c877ff', next: '#ffd98aff', icons: '#e8c877ff', border: '#e8c877ff', shadow: '#000000aa' },
      shape: { radius: 30, borderW: 2.5, shadow: 18, glow: 6, padding: 24 },
      layout: { main: 'text', list: 'rows', deco: 'gold' },
    }),
  },
  {
    id: 'mosque',
    name: 'مسجد بصورة خلفية',
    patch: () => ({
      bg: { type: 'image', imageId: 'builtin:mosque', overlay: '#0b102688', zoom: 1.1, blur: 0, brightness: 1, contrast: 1.05 },
      colors: { text: '#ffffffff', text2: '#e3e9ffff', accent: '#e8c877ff', next: '#e8c877ff', icons: '#e8c877ff', border: '#ffffff40', shadow: '#000000aa' },
      layout: { main: 'text', list: 'rows', deco: 'none' },
    }),
  },
  {
    id: 'minimal',
    name: 'مينيمال نظيف',
    patch: () => ({
      bg: { type: 'solid', solid: '#ffffffff', stops: [{ c: '#ffffffff', p: 0 }, { c: '#f1f4fbff', p: 1 }] },
      colors: { text: '#111936ff', text2: '#6b7494ff', accent: '#2f5fd0ff', next: '#2f5fd0ff', icons: '#2f5fd0ff', border: '#00000000', shadow: '#00000040' },
      shape: { radius: 30, borderW: 0, shadow: 14, glow: 0, padding: 24 },
      show: { icons: false },
      layout: { main: 'text', list: 'inline', deco: 'none' },
    } as any),
  },
  {
    id: 'ring',
    name: 'حلقة عدّ تنازلي',
    patch: () => ({
      bg: { type: 'gradient', stops: [{ c: '#062a2fff', p: 0 }, { c: '#0e5b63ff', p: 1 }], angle: 160 },
      colors: { text: '#f0fffeff', text2: '#9fd6d3ff', accent: '#5eead4ff', next: '#fde68aff', icons: '#5eead4ff', border: '#5eead433', shadow: '#00000099' },
      layout: { main: 'ring', list: 'inline', deco: 'none' },
    }),
  },
  {
    id: 'cards',
    name: 'بطاقات ملوّنة',
    patch: () => ({
      bg: { type: 'solid', solid: '#10142aff', stops: [{ c: '#10142aff', p: 0 }, { c: '#1a2040ff', p: 1 }] },
      colors: { text: '#ffffffff', text2: '#c7cdeaff', accent: '#ffffffff', next: '#ffffffff', icons: '#ffffffff', border: '#ffffff22', shadow: '#00000099' },
      shape: { radius: 32, borderW: 1, shadow: 14, glow: 0, padding: 16 },
      layout: { main: 'bar', list: 'cards', deco: 'none' },
    }),
  },
  {
    id: 'green',
    name: 'أخضر هادئ بزخرفة',
    patch: () => ({
      bg: { type: 'gradient', stops: [{ c: '#06201aff', p: 0 }, { c: '#14634cff', p: 1 }], angle: 155 },
      colors: { text: '#effff8ff', text2: '#a6cdbfff', accent: '#7fe0b0ff', next: '#e8c877ff', icons: '#7fe0b0ff', border: '#7fe0b055', shadow: '#00000099' },
      layout: { main: 'text', list: 'rows', deco: 'geo' },
    }),
  },
];

export function makeWidget(templateId: string, size: WSize = 'medium', name?: string): WidgetDesign {
  const t = TEMPLATES.find((x) => x.id === templateId) ?? TEMPLATES[0];
  const base = mergeW(BASE_WIDGET, { id: uid(), size, template: t.id, name: name ?? `ويدجت ${t.name}` });
  return mergeW(base, t.patch(base));
}

/** Apply a template on top of an existing design while keeping its stickers, size, id, name. */
export function applyTemplate(d: WidgetDesign, templateId: string): WidgetDesign {
  const fresh = makeWidget(templateId, d.size, d.name);
  return { ...fresh, id: d.id, stickers: d.stickers, digits: d.digits, hour12: d.hour12, fonts: d.fonts, linkTheme: d.linkTheme };
}

export const WIDGET_PALETTES: { name: string; colors: WidgetDesign['colors']; stops: [string, string] }[] = [
  { name: 'نيلي', stops: ['#0b1026ff', '#1b2a5cff'], colors: BASE_WIDGET.colors },
  { name: 'ذهبي', stops: ['#1a1206ff', '#4a3410ff'], colors: { text: '#fff3d1ff', text2: '#cdb98aff', accent: '#e8c877ff', next: '#ffd98aff', icons: '#e8c877ff', border: '#e8c877ff', shadow: '#000000aa' } },
  { name: 'أخضر', stops: ['#06201aff', '#14634cff'], colors: { text: '#effff8ff', text2: '#a6cdbfff', accent: '#7fe0b0ff', next: '#e8c877ff', icons: '#7fe0b0ff', border: '#7fe0b055', shadow: '#000000aa' } },
  { name: 'وردي', stops: ['#2a0b1cff', '#7a1f4fff'], colors: { text: '#fff0f7ff', text2: '#e3a9c6ff', accent: '#ff8fc0ff', next: '#ffd98aff', icons: '#ff8fc0ff', border: '#ff8fc055', shadow: '#000000aa' } },
  { name: 'أبيض', stops: ['#ffffffff', '#eef2fbff'], colors: { text: '#111936ff', text2: '#6b7494ff', accent: '#2f5fd0ff', next: '#2f5fd0ff', icons: '#2f5fd0ff', border: '#0000001a', shadow: '#00000040' } },
  { name: 'رمادي', stops: ['#1c1c1fff', '#3a3a40ff'], colors: { text: '#ffffffff', text2: '#b4b4bcff', accent: '#ffb86bff', next: '#ffb86bff', icons: '#ffb86bff', border: '#ffffff30', shadow: '#000000aa' } },
];

export function newSticker(partial: Partial<WSticker> = {}): WSticker {
  return {
    id: uid(), kind: 'shape', shape: 'crescent', imageId: '', x: 0.85, y: 0.2, size: 0.22, rot: 0,
    opacity: 0.9, frame: 'none', color: '#e8c877ff', ...partial,
  };
}

/** Sanitize an imported widget design (JSON file). Throws on garbage. */
export function sanitizeWidget(raw: any): WidgetDesign {
  const r = raw && typeof raw === 'object' && raw.widget ? raw.widget : raw;
  if (!r || typeof r !== 'object' || !r.bg || !r.colors) throw new Error('الملف ليس تصميم ويدجت صالح');
  const base = mergeW(BASE_WIDGET, {});
  const out: any = { ...base };
  const mergeSafe = (b: any, o: any): any => {
    if (Array.isArray(b)) return Array.isArray(o) ? o : b;
    if (b && typeof b === 'object') {
      const res: any = { ...b };
      if (o && typeof o === 'object') for (const k of Object.keys(b)) if (k in o) res[k] = mergeSafe(b[k], o[k]);
      return res;
    }
    return typeof o === typeof b ? o : b;
  };
  for (const k of Object.keys(base)) out[k] = mergeSafe((base as any)[k], r[k]);
  out.id = uid();
  out.stickers = Array.isArray(r.stickers)
    ? r.stickers.filter((s: any) => s && typeof s === 'object').slice(0, 40).map((s: any) => newSticker(mergeSafe(newSticker(), s)))
    : [];
  if (!['small', 'medium', 'large'].includes(out.size)) out.size = 'medium';
  const ord: string[] = (out.order as string[]).filter((x) => x in WIDGET_SECTIONS);
  for (const k of Object.keys(WIDGET_SECTIONS)) if (!ord.includes(k)) ord.push(k);
  out.order = Array.from(new Set(ord));
  if (!Array.isArray(out.bg.stops) || out.bg.stops.length < 2) out.bg.stops = base.bg.stops;
  return out as WidgetDesign;
}
