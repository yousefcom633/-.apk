// Event scheduler: adhan, iqama reminders, end-of-prayer reminders, suhoor and Friday reminders.
// The browser cannot wake a closed app (see "limits" screen), so everything here runs while the app is alive.
import { CHIME_ID } from '../config/adhanSounds';
import type { Settings } from '../config/settings';
import { adhanStore, firedStore, quietStore, settingsStore } from '../state/stores';
import { listSounds, resolveSoundUrl } from './assets';
import { playChime, playUrl, vibrate } from './audio';
import { dayKey, hijriOf, weekdayInTz } from './format';
import { isNative, silenceDelivered } from './native';
import { showNotification } from './notify';
import { calcTimes, prayerEnd } from './prayer';
import { tickStore } from './ticker';
import { PRAYERS, PRAYER_NAMES, type Prayer5 } from './types';

export interface AppEvent {
  id: string;
  at: number;
  kind: 'adhan' | 'iqama' | 'end' | 'suhoor' | 'friday' | 'kahf';
  prayer?: Prayer5;
  title: string;
  body: string;
}

const MIN = 60000;

export function buildEvents(s: Settings, now: Date): AppEvent[] {
  const out: AppEvent[] = [];
  for (const off of [-1, 0, 1]) {
    const t = calcTimes(s, now, off);
    const push = (kind: AppEvent['kind'], at: number, title: string, body: string, prayer?: Prayer5) =>
      out.push({ id: `${kind}:${prayer ?? ''}:${at}`, at, kind, prayer, title, body });

    for (const p of PRAYERS) {
      if (s.modes[p] === 'silent') continue;
      const name = PRAYER_NAMES[p];
      const at = t[p].getTime();
      push('adhan', at, `حان الآن موعد أذان ${name}`, `حسب توقيت ${s.location.name}`, p);
      if (s.iqamaReminder && s.iqamaMin[p] > s.iqamaBefore) {
        push('iqama', at + (s.iqamaMin[p] - s.iqamaBefore) * MIN, `اقتربت إقامة صلاة ${name}`, `بعد ${s.iqamaBefore} دقائق`, p);
      }
      if (s.endReminder) {
        const end = prayerEnd(p, t).getTime();
        push('end', end - s.endReminderMin * MIN, `قارب خروج وقت صلاة ${name}`, `متبقٍ ${s.endReminderMin} دقيقة على خروج الوقت`, p);
      }
    }
    if (s.ramadanMode && hijriOf(t.fajr, s.location.tz, s.hijriOffset).m === 9) {
      push('suhoor', t.fajr.getTime() - s.preFajrMin * MIN, 'وقت السحور', `باقٍ ${s.preFajrMin} دقيقة على أذان الفجر`);
    }
    if (weekdayInTz(t.dhuhr, s.location.tz) === 5) {
      if (s.fridayReminder) push('friday', t.dhuhr.getTime() - 60 * MIN, 'اليوم الجمعة', 'التبكير للجمعة، والاغتسال، والإكثار من الصلاة على النبي ﷺ');
      if (s.kahfReminder) push('kahf', t.sunrise.getTime() + 30 * MIN, 'سورة الكهف', 'لا تنسَ قراءة سورة الكهف يوم الجمعة');
    }
  }
  return out;
}

export function isQuiet(): boolean {
  return quietStore.get().until > Date.now();
}

export function resolveSoundId(s: Settings, p: Prayer5): string {
  const v = s.sounds[p];
  if (v && v !== 'auto' && listSounds().some((x) => x.id === v)) return v;
  return p === 'fajr' ? s.fajrSoundId : s.defaultSoundId;
}

function onAdhanEnd(p: Prayer5, reason: 'ended' | 'stopped') {
  const s = settingsStore.get();
  if (s.quietAfter) quietStore.set({ until: Date.now() + s.quietMinutes * MIN });
  if (reason === 'ended' && s.showAdhkar && adhanStore.get().active) adhanStore.set({ phase: 'adhkar', prayer: p });
  else adhanStore.set({ active: false });
}

export async function startAdhanAudio(p: Prayer5) {
  const s = settingsStore.get();
  const id = resolveSoundId(s, p);
  const def = listSounds().find((x) => x.id === id);
  const url = await resolveSoundUrl(id);
  let r: 'ok' | 'missing' | 'blocked' = 'missing';
  if (url) {
    r = await playUrl({
      id, label: `أذان ${PRAYER_NAMES[p]} — ${def?.name ?? ''}`, url, volume: s.volume, gradual: s.gradual,
      onEnd: (reason) => onAdhanEnd(p, reason),
    });
  }
  if (r === 'ok') {
    adhanStore.set({ note: '', blocked: false });
  } else if (r === 'blocked') {
    adhanStore.set({ blocked: true, note: 'منع المتصفح التشغيل التلقائي للصوت. اضغط "تشغيل الأذان".' });
  } else {
    adhanStore.set({ blocked: false, note: 'ملف الأذان غير موجود — تم تشغيل نغمة بديلة.' });
    playChime(s.volume, () => onAdhanEnd(p, 'ended'));
  }
}

/** Fire the adhan for a prayer (used by the scheduler and by the "test" buttons). */
export async function fireAdhan(p: Prayer5, forceMode?: Settings['modes'][Prayer5]) {
  const s = settingsStore.get();
  const mode = forceMode ?? s.modes[p];
  if (mode === 'silent') return;
  void showNotification(`حان الآن موعد أذان ${PRAYER_NAMES[p]}`, `حسب توقيت ${s.location.name}`, 'adhan', { stopAction: mode === 'full' });
  if (isNative()) void silenceDelivered(); // the app plays it now; avoid a double sound from the native alarm
  if (mode === 'notify') return;
  vibrate(s.vibration);
  if (mode === 'short') {
    playChime(s.volume);
    return;
  }
  adhanStore.set({ active: true, prayer: p, phase: 'playing', note: '', blocked: false, startedAt: Date.now() });
  await startAdhanAudio(p);
}

function fire(ev: AppEvent) {
  const s = settingsStore.get();
  if (ev.kind === 'adhan' && ev.prayer) {
    void fireAdhan(ev.prayer);
    return;
  }
  if (isNative()) return; // reminders are delivered by the native alarms
  const quiet = isQuiet();
  void showNotification(ev.title, ev.body, ev.kind, { silent: true });
  const mode = ev.prayer ? s.modes[ev.prayer] : 'short';
  if (!quiet && mode !== 'notify') {
    playChime(Math.min(1, s.volume * 0.7));
    vibrate('short');
  }
}

let cache: { s: Settings; day: string; events: AppEvent[] } | null = null;
let running = false;

function run() {
  const nowMs = Date.now();
  const s = settingsStore.get();
  const day = dayKey(new Date(nowMs), s.location.tz);
  if (!cache || cache.s !== s || cache.day !== day) cache = { s, day, events: buildEvents(s, new Date(nowMs)) };
  const fired = firedStore.get().ids;
  let dirty = false;
  const next = { ...fired };
  for (const ev of cache.events) {
    if (ev.at > nowMs || next[ev.id]) continue;
    const age = nowMs - ev.at;
    const window = ev.kind === 'adhan' ? 2 * MIN : 5 * MIN;
    next[ev.id] = nowMs;
    dirty = true;
    if (age <= window) fire(ev);
  }
  for (const k of Object.keys(next)) if (nowMs - next[k] > 3 * 86400000) {
    delete next[k];
    dirty = true;
  }
  if (dirty) firedStore.set({ ids: next });
}

export function startScheduler() {
  if (running) return;
  running = true;
  tickStore.subscribe(run);
  run();
}
export { CHIME_ID };
