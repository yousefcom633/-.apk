// Native (Capacitor / Android) bridge: permission state + notification channels.
// On the web build everything here is a harmless no-op.
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { ADHAN_SOUNDS } from '../config/adhanSounds';

export const isNative = () => Capacitor.isNativePlatform();

export type NativePerm = 'granted' | 'denied' | 'default';
let perm: NativePerm = 'default';
export const nativePerm = () => perm;

const mapPerm = (v: string): NativePerm => (v === 'granted' ? 'granted' : v === 'denied' ? 'denied' : 'default');

export async function refreshNativePerm(): Promise<NativePerm> {
  try {
    perm = mapPerm((await LocalNotifications.checkPermissions()).display);
  } catch {
    /* ignore */
  }
  return perm;
}

export async function requestNativePerm(): Promise<NativePerm> {
  try {
    perm = mapPerm((await LocalNotifications.requestPermissions()).display);
  } catch {
    /* ignore */
  }
  return perm;
}

// Channel ids. A channel's sound can't change after creation, so there is one channel per muezzin.
export const CH = { alert: 'alert_v1', notify: 'notify_v1', reminder: 'reminder_v1' } as const;
export const adhanChannel = (soundId: string) => `adhan_v1_${soundId}`;

export async function ensureChannels() {
  if (!isNative()) return;
  try {
    await LocalNotifications.createChannel({ id: CH.alert, name: 'تنبيه قصير', description: 'تنبيه بصوت الإشعار الافتراضي', importance: 4, visibility: 1, vibration: true });
    await LocalNotifications.createChannel({ id: CH.reminder, name: 'التذكيرات', description: 'الإقامة والسحور والجمعة وخروج الوقت', importance: 4, visibility: 1, vibration: true });
    await LocalNotifications.createChannel({ id: CH.notify, name: 'إشعار صامت', description: 'إشعار بدون صوت', importance: 3, visibility: 1, vibration: false });
    for (const d of ADHAN_SOUNDS) {
      await LocalNotifications.createChannel({
        id: adhanChannel(d.id),
        name: `أذان — ${d.name}`,
        description: 'صوت الأذان الكامل',
        importance: 5,
        visibility: 1,
        sound: d.src.split('/').pop() ?? undefined, // file lives in android res/raw (copied by the build script)
        vibration: true,
        lights: true,
      });
    }
  } catch (e) {
    console.warn('createChannel failed', e);
  }
}

/** Stops the notification sound when the app itself is already playing the adhan in the foreground. */
export async function silenceDelivered() {
  if (!isNative()) return;
  try {
    await LocalNotifications.removeAllDeliveredNotifications();
  } catch {
    /* ignore */
  }
}
