// Prayer time calculation (fully offline, powered by the Adhan library).
import { CalculationMethod, Coordinates, Madhab, PrayerTimes, Qibla, SunnahTimes } from 'adhan';
import type { Settings } from '../config/settings';
import { ymdInTz } from './format';
import { PRAYERS, type Prayer5, type PrayerKey } from './types';

export type DayTimes = Record<PrayerKey, Date> & { midnight: Date };

function buildParams(s: Settings) {
  const factories = {
    egyptian: CalculationMethod.Egyptian,
    ummalqura: CalculationMethod.UmmAlQura,
    mwl: CalculationMethod.MuslimWorldLeague,
    karachi: CalculationMethod.Karachi,
    dubai: CalculationMethod.Dubai,
    kuwait: CalculationMethod.Kuwait,
    qatar: CalculationMethod.Qatar,
    singapore: CalculationMethod.Singapore,
    turkey: CalculationMethod.Turkey,
    northamerica: CalculationMethod.NorthAmerica,
    moonsighting: CalculationMethod.MoonsightingCommittee,
    tehran: CalculationMethod.Tehran,
  } as const;
  const p = (factories[s.method] ?? CalculationMethod.Egyptian)();
  p.madhab = s.madhab === 'hanafi' ? Madhab.Hanafi : Madhab.Shafi;
  p.adjustments = { ...p.adjustments, ...s.adjust };
  return p;
}

const cache = new Map<string, DayTimes>();

/** Times for the civil day (in the selected location's timezone) that is `dayOffset` days from `now`. */
export function calcTimes(s: Settings, now: Date, dayOffset = 0): DayTimes {
  const { y, m, d } = ymdInTz(now, s.location.tz);
  const key = JSON.stringify([s.location.lat, s.location.lon, s.method, s.madhab, s.adjust, y, m, d, dayOffset]);
  const hit = cache.get(key);
  if (hit) return hit;
  const date = new Date(y, m - 1, d + dayOffset, 12);
  const pt = new PrayerTimes(new Coordinates(s.location.lat, s.location.lon), date, buildParams(s));
  const sn = new SunnahTimes(pt);
  const res: DayTimes = {
    fajr: pt.fajr, sunrise: pt.sunrise, dhuhr: pt.dhuhr, asr: pt.asr, maghrib: pt.maghrib, isha: pt.isha,
    midnight: sn.middleOfTheNight,
  };
  if (cache.size > 60) cache.clear();
  cache.set(key, res);
  return res;
}

export interface Schedule {
  today: DayTimes;
  tomorrow: DayTimes;
  yesterday: DayTimes;
  next: { key: Prayer5; at: Date };
  prev: { key: Prayer5; at: Date };
}

export function getSchedule(s: Settings, now: Date): Schedule {
  const yesterday = calcTimes(s, now, -1);
  const today = calcTimes(s, now, 0);
  const tomorrow = calcTimes(s, now, 1);
  const line: { key: Prayer5; at: Date }[] = [];
  for (const t of [yesterday, today, tomorrow]) for (const k of PRAYERS) line.push({ key: k, at: t[k] });
  const n = now.getTime();
  let idx = line.findIndex((e) => e.at.getTime() > n);
  if (idx < 1) idx = Math.max(1, idx);
  return { today, tomorrow, yesterday, next: line[idx], prev: line[idx - 1] };
}

/** End of a prayer's valid time. */
export function prayerEnd(k: Prayer5, t: DayTimes): Date {
  switch (k) {
    case 'fajr': return t.sunrise;
    case 'dhuhr': return t.asr;
    case 'asr': return t.maghrib;
    case 'maghrib': return t.isha;
    default: return t.midnight;
  }
}

export function qiblaBearing(lat: number, lon: number): number {
  return Qibla(new Coordinates(lat, lon));
}
