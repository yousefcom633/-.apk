// Audio engine: single-player adhan playback (with gradual volume), synthesized chime, vibration.
import { createStore } from './store';
import { VIBRATIONS } from '../config/settings';

export interface PlayerState {
  playing: boolean;
  id: string;
  label: string;
  progress: number;
  duration: number;
}
export const playerStore = createStore<PlayerState>(null, { playing: false, id: '', label: '', progress: 0, duration: 0 });

let audio: HTMLAudioElement | null = null;
let ramp: ReturnType<typeof setInterval> | undefined;
let endCb: ((r: 'ended' | 'stopped') => void) | null = null;
let ac: AudioContext | null = null;
let chimeTimer: ReturnType<typeof setTimeout> | undefined;

function ctx(): AudioContext {
  const C = window.AudioContext || (window as any).webkitAudioContext;
  ac ||= new C();
  return ac;
}

/** Must be called from a user gesture once; lets later automatic playback work. */
export function unlockAudio() {
  try {
    const c = ctx();
    if (c.state === 'suspended') void c.resume();
  } catch {
    /* ignore */
  }
}

function cleanup() {
  if (ramp) clearInterval(ramp);
  ramp = undefined;
  if (chimeTimer) clearTimeout(chimeTimer);
  chimeTimer = undefined;
  if (audio) {
    audio.onended = audio.onerror = audio.ontimeupdate = audio.oncanplay = null;
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    audio = null;
  }
  playerStore.set({ playing: false, id: '', label: '', progress: 0, duration: 0 });
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = null;
      navigator.mediaSession.playbackState = 'none';
    } catch {
      /* ignore */
    }
  }
}

function finish(reason: 'ended' | 'stopped') {
  const cb = endCb;
  endCb = null;
  cleanup();
  cb?.(reason);
}

export function stopPlayback() {
  finish('stopped');
}

export interface PlayOpts {
  id: string;
  label: string;
  url: string;
  volume: number;
  gradual: boolean;
  onEnd?: (r: 'ended' | 'stopped') => void;
}

export async function playUrl(o: PlayOpts): Promise<'ok' | 'missing' | 'blocked'> {
  stopPlayback();
  const a = new Audio();
  a.preload = 'auto';
  a.src = o.url;
  a.volume = o.gradual ? Math.min(0.05, o.volume) : o.volume;
  audio = a;
  endCb = o.onEnd ?? null;
  // Start playback directly: play() rejects with NotSupportedError for missing/broken files and
  // NotAllowedError when the browser blocks autoplay (no waiting on 'canplay', which some mobile browsers never fire).
  try {
    await a.play();
  } catch (e: any) {
    if (audio !== a) return 'ok'; // stopped while loading
    endCb = null;
    cleanup();
    return e?.name === 'NotAllowedError' ? 'blocked' : 'missing';
  }
  if (audio !== a) return 'ok';
  a.onended = () => finish('ended');
  a.onerror = () => finish('stopped');
  a.ontimeupdate = () => playerStore.set({ progress: a.currentTime, duration: isFinite(a.duration) ? a.duration : 0 });
  if (o.gradual) {
    const t0 = Date.now();
    ramp = setInterval(() => {
      const k = Math.min(1, (Date.now() - t0) / 15000);
      a.volume = Math.min(1, o.volume * Math.max(0.05, k));
      if (k >= 1 && ramp) clearInterval(ramp);
    }, 300);
  }
  playerStore.set({ playing: true, id: o.id, label: o.label, progress: 0, duration: 0 });
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({ title: o.label, artist: 'أذاني' });
      navigator.mediaSession.playbackState = 'playing';
      navigator.mediaSession.setActionHandler('stop', stopPlayback);
      navigator.mediaSession.setActionHandler('pause', stopPlayback);
    } catch {
      /* ignore */
    }
  }
  return 'ok';
}

/** Short synthesized three-note chime — used for "short alert" mode, reminders and as a fallback. */
export function playChime(volume: number, onEnd?: () => void) {
  try {
    const c = ctx();
    if (c.state === 'suspended') void c.resume();
    const notes = [659.25, 880, 783.99];
    const t0 = c.currentTime + 0.02;
    notes.forEach((f, i) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      const t = t0 + i * 0.55;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.01, volume * 0.5), t + 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
      o.connect(g).connect(c.destination);
      o.start(t);
      o.stop(t + 1.2);
    });
    playerStore.set({ playing: true, id: '__chime__', label: 'تنبيه', progress: 0, duration: 0 });
    chimeTimer = setTimeout(() => {
      if (playerStore.get().id === '__chime__') playerStore.set({ playing: false, id: '', label: '' });
      onEnd?.();
    }, 2300);
  } catch {
    onEnd?.();
  }
}

export function vibrate(patternId: string) {
  const p = VIBRATIONS[patternId]?.pattern ?? [];
  if (p.length && 'vibrate' in navigator) {
    try {
      navigator.vibrate(p);
    } catch {
      /* ignore */
    }
  }
}
