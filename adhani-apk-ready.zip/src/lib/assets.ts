// Imported assets: fonts, adhan audio files and images. Blobs are kept in IndexedDB, metadata in stores.
import mosqueUrl from '../assets/mosque.jpg';
import { ADHAN_SOUNDS } from '../config/adhanSounds';
import { BUILTIN_FONTS, customFamilies } from '../config/fonts';
import { fontsRev, fontsStore, imagesStore, soundsStore, themeStore, widgetsStore } from '../state/stores';
import { dbAll, dbDel, dbGet, dbPut } from './db';
import { uid } from './store';

// ───────────────────────── Fonts ─────────────────────────
export async function loadCustomFonts() {
  const items = fontsStore.get().items;
  const keep: typeof items = [];
  for (const it of items) {
    try {
      const blob = await dbGet('fonts', it.id);
      if (!blob) throw new Error('missing');
      const family = `adhani-custom-${it.id}`;
      const face = new FontFace(family, await blob.arrayBuffer());
      await face.load();
      document.fonts.add(face);
      customFamilies.set(it.id, family);
      keep.push(it);
    } catch {
      /* corrupted stored font: dropped silently, theme falls back to default */
    }
  }
  if (keep.length !== items.length) fontsStore.set({ items: keep });
  fontsRev.set((s) => ({ rev: s.rev + 1 }));
}

/** Validates + registers a user font. Throws Error(Arabic message) when invalid; never breaks the app. */
export async function importFont(file: File): Promise<{ id: string; name: string }> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  if (!['ttf', 'otf'].includes(ext)) throw new Error('الصيغة غير مدعومة — اختر ملف ‎.ttf أو ‎.otf');
  if (file.size > 8 * 1024 * 1024) throw new Error('حجم الخط كبير جدًا (الحد الأقصى ٨ ميجابايت)');
  const buf = await file.arrayBuffer();
  let tag = 0;
  try {
    tag = new DataView(buf).getUint32(0);
  } catch {
    throw new Error('الملف فارغ أو تالف');
  }
  if (![0x00010000, 0x4f54544f, 0x74727565].includes(tag)) throw new Error('الملف تالف أو ليس خطًا صالحًا');
  const id = uid();
  const family = `adhani-custom-${id}`;
  const face = new FontFace(family, buf.slice(0));
  try {
    await face.load();
  } catch {
    throw new Error('تعذّر تحميل الخط: الملف تالف أو غير مدعوم');
  }
  document.fonts.add(face);
  customFamilies.set(id, family);
  await dbPut('fonts', id, new Blob([buf]));
  const name = file.name.replace(/\.(ttf|otf)$/i, '');
  fontsStore.set((s) => ({ items: [...s.items, { id, name }] }));
  fontsRev.set((s) => ({ rev: s.rev + 1 }));
  return { id, name };
}

export async function deleteFont(id: string) {
  await dbDel('fonts', id).catch(() => undefined);
  customFamilies.delete(id);
  fontsStore.set((s) => ({ items: s.items.filter((f) => f.id !== id) }));
  // Anything using the deleted font falls back to the default
  const key = 'custom:' + id;
  themeStore.set((t) => {
    const f = { ...t.fonts };
    (Object.keys(f) as (keyof typeof f)[]).forEach((k) => {
      if (f[k] === key) f[k] = 'cairo';
    });
    return { ...t, fonts: f };
  });
  widgetsStore.set((w) => ({
    ...w,
    items: w.items.map((d) => {
      const f = { ...d.fonts };
      (Object.keys(f) as (keyof typeof f)[]).forEach((k) => {
        if (f[k] === key) f[k] = 'theme';
      });
      return { ...d, fonts: f };
    }),
  }));
  fontsRev.set((s) => ({ rev: s.rev + 1 }));
}

/** True when the font can really be used right now. */
export async function ensureFontReady(id: string): Promise<boolean> {
  const b = BUILTIN_FONTS.find((f) => f.id === id);
  try {
    if (b) {
      await document.fonts.load(`16px "${b.family}"`, 'ا');
      return true;
    }
    const fam = customFamilies.get(id.replace('custom:', ''));
    if (!fam) return false;
    await document.fonts.load(`16px "${fam}"`);
    return true;
  } catch {
    return false;
  }
}

// ───────────────────────── Sounds ─────────────────────────
export interface SoundItem {
  id: string;
  name: string;
  fajr: boolean;
  custom: boolean;
}

export function listSounds(): SoundItem[] {
  return [
    ...ADHAN_SOUNDS.map((s) => ({ id: s.id, name: s.name, fajr: s.fajr, custom: false })),
    ...soundsStore.get().items.map((s) => ({ id: 'custom:' + s.id, name: s.name, fajr: s.fajr, custom: true })),
  ];
}

const urlCache = new Map<string, string>();

export async function resolveSoundUrl(id: string): Promise<string | null> {
  if (id.startsWith('custom:')) {
    const cached = urlCache.get(id);
    if (cached) return cached;
    const blob = await dbGet('sounds', id.slice(7)).catch(() => undefined);
    if (!blob) return null;
    const u = URL.createObjectURL(blob);
    urlCache.set(id, u);
    return u;
  }
  return ADHAN_SOUNDS.find((s) => s.id === id)?.src ?? null;
}

export async function importSound(file: File, fajr: boolean): Promise<void> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const okType = file.type.startsWith('audio/') || ['mp3', 'ogg', 'm4a', 'wav', 'aac'].includes(ext);
  if (!okType) throw new Error('اختر ملف صوت بصيغة mp3 أو ogg');
  if (file.size > 20 * 1024 * 1024) throw new Error('الملف كبير جدًا (الحد الأقصى ٢٠ ميجابايت)');
  const url = URL.createObjectURL(file);
  try {
    await new Promise<void>((res, rej) => {
      const a = new Audio();
      a.preload = 'metadata';
      a.onloadedmetadata = () => res();
      a.onerror = () => rej(new Error('bad'));
      setTimeout(() => rej(new Error('bad')), 8000);
      a.src = url;
    });
  } catch {
    throw new Error('ملف الصوت تالف أو غير مدعوم');
  } finally {
    URL.revokeObjectURL(url);
  }
  const id = uid();
  await dbPut('sounds', id, file);
  soundsStore.set((s) => ({ items: [...s.items, { id, name: file.name.replace(/\.[^.]+$/, ''), fajr }] }));
}

export async function deleteSound(id: string) {
  const raw = id.replace('custom:', '');
  await dbDel('sounds', raw).catch(() => undefined);
  const u = urlCache.get(id);
  if (u) URL.revokeObjectURL(u);
  urlCache.delete(id);
  soundsStore.set((s) => ({ items: s.items.filter((x) => x.id !== raw) }));
}

// ───────────────────────── Images ─────────────────────────
export const BUILTIN_IMAGES = [{ id: 'builtin:mosque', name: 'مسجد (افتراضي)', url: mosqueUrl }];
const MAX_SIDE = 1600;
const imgUrlCache = new Map<string, string>();
const imgElCache = new Map<string, HTMLImageElement>();

export async function imageUrl(id: string): Promise<string | null> {
  const b = BUILTIN_IMAGES.find((x) => x.id === id);
  if (b) return b.url;
  const c = imgUrlCache.get(id);
  if (c) return c;
  const blob = await dbGet('images', id).catch(() => undefined);
  if (!blob) return null;
  const u = URL.createObjectURL(blob);
  imgUrlCache.set(id, u);
  return u;
}

/** Decoded image element (cached). Returns null if the image is missing or broken. */
export async function getImage(id: string): Promise<HTMLImageElement | null> {
  if (!id) return null;
  const hit = imgElCache.get(id);
  if (hit) return hit;
  const url = await imageUrl(id);
  if (!url) return null;
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => {
      imgElCache.set(id, im);
      res(im);
    };
    im.onerror = () => res(null);
    im.src = url;
  });
}

/** Validates, down-scales (memory safe) and stores an image in the library. */
export async function importImage(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('الملف ليس صورة');
  if (file.size > 30 * 1024 * 1024) throw new Error('الصورة كبيرة جدًا (الحد الأقصى ٣٠ ميجابايت)');
  let bmp: ImageBitmap;
  try {
    bmp = await createImageBitmap(file);
  } catch {
    throw new Error('الصورة تالفة أو بصيغة غير مدعومة');
  }
  const k = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
  const w = Math.max(1, Math.round(bmp.width * k)), h = Math.max(1, Math.round(bmp.height * k));
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  cv.getContext('2d')!.drawImage(bmp, 0, 0, w, h);
  bmp.close?.();
  const png = file.type === 'image/png' || file.type === 'image/webp' || file.type === 'image/gif';
  const blob: Blob | null = await new Promise((r) => cv.toBlob(r, png ? 'image/png' : 'image/jpeg', 0.88));
  if (!blob) throw new Error('تعذّر معالجة الصورة');
  const id = uid();
  await dbPut('images', id, blob);
  imagesStore.set((s) => ({ items: [...s.items, { id, name: file.name.replace(/\.[^.]+$/, ''), w, h }] }));
  return id;
}

export async function deleteImage(id: string) {
  await dbDel('images', id).catch(() => undefined);
  const u = imgUrlCache.get(id);
  if (u) URL.revokeObjectURL(u);
  imgUrlCache.delete(id);
  imgElCache.delete(id);
  imagesStore.set((s) => ({ items: s.items.filter((x) => x.id !== id) }));
  themeStore.set((t) => (t.bg.imageId === id ? { ...t, bg: { ...t.bg, imageId: '', type: 'gradient' } } : t));
  widgetsStore.set((w) => ({
    ...w,
    items: w.items.map((d) => ({
      ...d,
      bg: d.bg.imageId === id ? { ...d.bg, imageId: '', type: 'gradient' } : d.bg,
      stickers: d.stickers.filter((s) => s.imageId !== id),
    })),
  }));
}

/** Dominant-color palette from an image → used for the "take colors from my image" feature. */
export function paletteFromImage(img: HTMLImageElement): { bg1: string; bg2: string; accent: string; text: string } {
  const cv = document.createElement('canvas');
  cv.width = cv.height = 40;
  const g = cv.getContext('2d', { willReadFrequently: true })!;
  g.drawImage(img, 0, 0, 40, 40);
  const px = g.getImageData(0, 0, 40, 40).data;
  const buckets = new Map<number, { n: number; r: number; g: number; b: number }>();
  for (let i = 0; i < px.length; i += 4) {
    if (px[i + 3] < 128) continue;
    const key = ((px[i] >> 5) << 6) | ((px[i + 1] >> 5) << 3) | (px[i + 2] >> 5);
    const e = buckets.get(key) ?? { n: 0, r: 0, g: 0, b: 0 };
    e.n++; e.r += px[i]; e.g += px[i + 1]; e.b += px[i + 2];
    buckets.set(key, e);
  }
  const list = [...buckets.values()].map((e) => ({ n: e.n, r: e.r / e.n, g: e.g / e.n, b: e.b / e.n }));
  list.sort((a, b) => b.n - a.n);
  const sat = (c: { r: number; g: number; b: number }) => Math.max(c.r, c.g, c.b) - Math.min(c.r, c.g, c.b);
  const hex = (c: { r: number; g: number; b: number }, k = 1) =>
    '#' + [c.r, c.g, c.b].map((v) => Math.round(Math.max(0, Math.min(255, v * k))).toString(16).padStart(2, '0')).join('') + 'ff';
  const dom = list[0] ?? { r: 11, g: 16, b: 38 };
  const second = list.find((c) => Math.abs(c.r - dom.r) + Math.abs(c.g - dom.g) + Math.abs(c.b - dom.b) > 90) ?? dom;
  const vivid = [...list].sort((a, b) => sat(b) * Math.sqrt(b.n) - sat(a) * Math.sqrt(a.n))[0] ?? dom;
  const lum = (c: { r: number; g: number; b: number }) => (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
  const bg1 = hex(dom, 0.45), bg2 = hex(second, 0.6);
  const avgLum = (lum(dom) * 0.45 + lum(second) * 0.6) / 2;
  const accentBright = lum(vivid) < 0.45 ? 1.6 : 1;
  return { bg1, bg2, accent: hex(vivid, accentBright), text: avgLum > 0.55 ? '#111936ff' : '#ffffffff' };
}

// ───────────────────────── Backup helpers ─────────────────────────
export async function dumpBlobs() {
  const out: Record<string, { key: string; data: string }[]> = {};
  const { blobToDataUrl } = await import('./db');
  for (const s of ['fonts', 'sounds', 'images'] as const) {
    out[s] = [];
    for (const { key, blob } of await dbAll(s)) out[s].push({ key, data: await blobToDataUrl(blob) });
  }
  return out;
}

export async function restoreBlobs(data: Record<string, { key: string; data: string }[]>) {
  const { dataUrlToBlob } = await import('./db');
  for (const s of ['fonts', 'sounds', 'images'] as const) {
    for (const it of data?.[s] ?? []) {
      try {
        await dbPut(s, it.key, await dataUrlToBlob(it.data));
      } catch {
        /* skip broken entry */
      }
    }
  }
}
