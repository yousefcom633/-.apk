// Schedules the next days of adhan / reminders as real Android alarms (AlarmManager via LocalNotifications),
// so they ring even when the app is closed or the phone is asleep. Fully offline.
import { LocalNotifications } from '@capacitor/local-notifications';
import { ADHAN_SOUNDS } from '../config/adhanSounds';
import type { Settings } from '../config/settings';
import { settingsStore } from '../state/stores';
import { adhanChannel, CH, ensureChannels, isNative, nativePerm, refreshNativePerm, silenceDelivered } from './native';
import { buildEvents, resolveSoundId, type AppEvent } from './scheduler';

const DAY = 86400000;
const DAYS_AHEAD = 14; // re-planned every time the app opens / settings change

function channelFor(ev: AppEvent, s: Settings): string {
  if (ev.kind === 'adhan' && ev.prayer) {
    const mode = s.modes[ev.prayer];
    if (mode === 'notify') return CH.notify;
    if (mode === 'short') return CH.alert;
    const id = resolveSoundId(s, ev.prayer);
    const def =
      ADHAN_SOUNDS.find((x) => x.id === id) ??
      ADHAN_SOUNDS.find((x) => x.id === (ev.prayer === 'fajr' ? s.fajrSoundId : s.defaultSoundId));
    return def ? adhanChannel(def.id) : CH.alert; // imported (custom) sounds can't be used by notification channels
  }
  const mode = ev.prayer ? s.modes[ev.prayer] : 'short';
  return mode === 'notify' ? CH.notify : CH.reminder;
}

let chain: Promise<void> = Promise.resolve();

export function syncNativeAlarms(): Promise<void> {
  chain = chain.then(doSync).catch((e) => console.warn('syncNativeAlarms failed', e));
  return chain;
}

async function doSync() {
  if (!isNative()) return;
  if (nativePerm() !== 'granted' && (await refreshNativePerm()) !== 'granted') return;
  await ensureChannels();
  const s = settingsStore.get();
  const now = Date.now();
  const byId = new Map<string, AppEvent>();
  for (let d = 0; d < DAYS_AHEAD; d++) {
    for (const ev of buildEvents(s, new Date(now + d * DAY))) if (ev.at > now + 5000) byId.set(ev.id, ev);
  }
  const events = [...byId.values()].sort((a, b) => a.at - b.at).slice(0, 400);

  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) await LocalNotifications.cancel({ notifications: pending.notifications.map((n) => ({ id: n.id })) });
  if (!events.length) return;

  await LocalNotifications.schedule({
    notifications: events.map((ev, i) => ({
      id: i + 1,
      title: ev.title,
      body: ev.body,
      channelId: channelFor(ev, s),
      schedule: { at: new Date(ev.at), allowWhileIdle: true },
      extra: { kind: ev.kind, prayer: ev.prayer ?? '' },
    })),
  });
}

let started = false;
export async function startNativeAlarms() {
  if (!isNative() || started) return;
  started = true;
  await refreshNativePerm();
  void syncNativeAlarms();

  let t: ReturnType<typeof setTimeout> | undefined;
  const later = () => {
    if (t) clearTimeout(t);
    t = setTimeout(() => void syncNativeAlarms(), 1500);
  };
  settingsStore.subscribe(later);
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && later());

  // App is open: the app plays the adhan itself, so silence the duplicate notification sound.
  void LocalNotifications.addListener('localNotificationReceived', (n) => {
    if (document.visibilityState === 'visible' && (n.extra as any)?.kind === 'adhan') void silenceDelivered();
  });
}
