// Notifications (via the service worker when available) and Wake Lock helpers.
import { VIBRATIONS } from '../config/settings';
import { settingsStore } from '../state/stores';
import { isNative, nativePerm, requestNativePerm } from './native';

const ICON =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'><rect width='96' height='96' rx='22' fill='#0b1026'/><path d='M60 20a30 30 0 1 0 0 56 24 24 0 1 1 0-56z' fill='#e8c877'/><circle cx='66' cy='34' r='3' fill='#8fb8ff'/></svg>"
  );

export type NotifPerm = 'granted' | 'denied' | 'default' | 'unsupported';

export function notifPermission(): NotifPerm {
  if (isNative()) return nativePerm();
  return 'Notification' in window ? (Notification.permission as NotifPerm) : 'unsupported';
}

export async function requestNotifPermission(): Promise<NotifPerm> {
  if (isNative()) {
    const r = await requestNativePerm();
    if (r === 'granted') void import('./nativeAlarms').then((m) => m.syncNativeAlarms());
    return r;
  }
  if (!('Notification' in window)) return 'unsupported';
  try {
    return (await Notification.requestPermission()) as NotifPerm;
  } catch {
    return notifPermission();
  }
}

export async function showNotification(title: string, body: string, tag: string, opts: { stopAction?: boolean; silent?: boolean } = {}) {
  if (isNative()) return; // native alarms are scheduled ahead of time by nativeAlarms.ts
  if (notifPermission() !== 'granted') return;
  const options: any = {
    body,
    tag,
    icon: ICON,
    badge: ICON,
    dir: 'rtl',
    lang: 'ar',
    renotify: true,
    silent: opts.silent ?? true, // sound is produced by the app itself
    vibrate: VIBRATIONS[settingsStore.get().vibration]?.pattern ?? [],
    actions: opts.stopAction ? [{ action: 'stop', title: 'إيقاف الأذان' }] : [],
  };
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    if (reg) {
      await reg.showNotification(title, options);
      return;
    }
  } catch {
    /* fall through */
  }
  try {
    new Notification(title, options);
  } catch {
    /* some mobile browsers only allow SW notifications */
  }
}

export async function clearNotifications() {
  try {
    const reg = await navigator.serviceWorker?.getRegistration();
    const list = (await reg?.getNotifications()) ?? [];
    list.forEach((n) => n.close());
  } catch {
    /* ignore */
  }
}

// ── Wake lock (keeps the screen on while the app is open, so alarms run in a foreground tab) ──
let lock: any = null;
let wantLock = false;

async function acquire() {
  try {
    if (wantLock && !lock && 'wakeLock' in navigator && document.visibilityState === 'visible') {
      lock = await (navigator as any).wakeLock.request('screen');
      lock.addEventListener('release', () => (lock = null));
    }
  } catch {
    lock = null;
  }
}
document.addEventListener('visibilitychange', () => void acquire());

export async function setWakeLock(on: boolean): Promise<boolean> {
  wantLock = on;
  if (on) await acquire();
  else if (lock) {
    try {
      await lock.release();
    } catch {
      /* ignore */
    }
    lock = null;
  }
  return on ? !!lock : true;
}

export const wakeLockSupported = () => 'wakeLock' in navigator;
