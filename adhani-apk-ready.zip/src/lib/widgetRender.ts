// Widget renderer: draws the whole widget as a high-quality bitmap with Canvas 2D.
// Real Android widgets cannot animate or blur live, so blur/brightness are baked into the bitmap here
// and the bitmap is capped in size to stay under the widget memory limit.
import { fontStack, WEIGHT_VALUES } from '../config/fonts';
import type { Settings } from '../config/settings';
import type { Colors } from '../config/themes';
import { getImage } from './assets';
import { fade, parseColor } from './color';
import { fmtHijri, fmtTime, hijriOf, toDigits } from './format';
import { getSchedule, type Schedule } from './prayer';
import { PRAYER_NAMES, type DigitMode, type Prayer5, type PrayerKey } from './types';
import { SIZE_DIMS, type FrameId, type ShapeId, type WidgetDesign, type WSticker } from './widgetTypes';

type Ctx = CanvasRenderingContext2D;

export interface WidgetData {
  now: Date;
  tz: string;
  city: string;
  hijri: { y: number; m: number; d: number };
  sch: Schedule;
}

export interface WidgetEnv {
  themeColors: Colors;
  widgetFontId: string;
}

export function buildWidgetData(s: Settings, now: Date): WidgetData {
  const sch = getSchedule(s, now);
  const after = now.getTime() >= sch.today.maghrib.getTime();
  return { now, tz: s.location.tz, city: s.location.name, hijri: hijriOf(now, s.location.tz, s.hijriOffset + (after ? 1 : 0)), sch };
}

const CARD_COLORS: Record<PrayerKey, string> = {
  fajr: '#4f7df3', sunrise: '#f5a524', dhuhr: '#ef7b45', asr: '#e5578b', maghrib: '#7b61ff', isha: '#2bb5a0',
};

/** Safe color: invalid values (from imported files) fall back instead of crashing the renderer. */
const col = (c: string, fb = '#ffffff') => (parseColor(c) ? c : fb);

interface Eff {
  c: WidgetDesign['colors'];
  stops: { c: string; p: number }[];
  bgType: WidgetDesign['bg']['type'];
  solid: string;
  fam: { title: string; time: string; counter: string };
}

function resolve(d: WidgetDesign, env: WidgetEnv): Eff {
  const t = env.themeColors;
  const f = (id: string) => fontStack(id === 'theme' ? env.widgetFontId : id);
  const base: Eff = {
    c: d.colors, stops: d.bg.stops, bgType: d.bg.type, solid: d.bg.solid,
    fam: { title: f(d.fonts.title), time: f(d.fonts.time), counter: f(d.fonts.counter) },
  };
  if (!d.linkTheme) return base;
  return {
    ...base,
    c: { text: t.textPrimary, text2: t.textSecondary, accent: t.accent, next: t.nextGlow, icons: t.icons, border: fade(t.textPrimary, 0.2), shadow: '#000000aa' },
    stops: [{ c: t.bgStart, p: 0 }, { c: t.bgEnd, p: 1 }],
    solid: t.bgStart,
    bgType: d.bg.type === 'image' ? 'image' : 'gradient',
  };
}

async function ensureFonts(e: Eff, d: WidgetDesign) {
  const jobs: Promise<unknown>[] = [];
  const add = (fam: string, w: keyof typeof WEIGHT_VALUES) => jobs.push(document.fonts.load(`${WEIGHT_VALUES[w]} 16px ${fam}`, 'اأ٠0').catch(() => undefined));
  add(e.fam.title, d.weights.title);
  add(e.fam.time, d.weights.time);
  add(e.fam.counter, d.weights.counter);
  await Promise.all(jobs);
}

// ───────────── drawing helpers ─────────────
function rr(ctx: Ctx, x: number, y: number, w: number, h: number, r: number) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

interface TxtOpt {
  size: number;
  weight: keyof typeof WEIGHT_VALUES;
  fam: string;
  color: string;
  align?: CanvasTextAlign;
  base?: CanvasTextBaseline;
  maxW?: number;
  ltr?: boolean;
  alpha?: number;
}
function txt(ctx: Ctx, s: string, x: number, y: number, o: TxtOpt) {
  let size = o.size;
  ctx.save();
  ctx.direction = o.ltr ? 'ltr' : 'rtl';
  ctx.textAlign = o.align ?? 'center';
  ctx.textBaseline = o.base ?? 'middle';
  ctx.fillStyle = col(o.color);
  if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
  ctx.font = `${WEIGHT_VALUES[o.weight]} ${size}px ${o.fam}`;
  if (o.maxW) {
    const w = ctx.measureText(s).width;
    if (w > o.maxW) {
      size = Math.max(8, (size * o.maxW) / w);
      ctx.font = `${WEIGHT_VALUES[o.weight]} ${size}px ${o.fam}`;
    }
  }
  ctx.fillText(s, x, y);
  ctx.restore();
}

function seeded(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);
  return () => {
    h = Math.imul(h ^ (h >>> 15), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
}

function star(ctx: Ctx, cx: number, cy: number, spikes: number, ro: number, ri: number, rot = -Math.PI / 2) {
  ctx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const r = i % 2 === 0 ? ro : ri;
    const a = rot + (i * Math.PI) / spikes;
    const px = cx + Math.cos(a) * r, py = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

/** Crescent path in unit coordinates (outer radius 1). */
function crescentPath(ctx: Ctx, R = 1, r2 = 0.8, d = 0.42) {
  const x = (d * d + R * R - r2 * r2) / (2 * d);
  const y = Math.sqrt(Math.max(0, R * R - x * x));
  const alpha = Math.atan2(y, x);
  const beta = Math.atan2(y, x - d);
  ctx.beginPath();
  ctx.arc(0, 0, R, -alpha, alpha, true);
  ctx.arc(d, 0, r2, beta, Math.PI * 2 - beta, false);
  ctx.closePath();
}

// Shapes are drawn in a unit box (-1..1)
function drawShape(ctx: Ctx, shape: ShapeId, color: string) {
  ctx.fillStyle = color;
  ctx.strokeStyle = color;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  switch (shape) {
    case 'crescent':
      ctx.save();
      ctx.rotate(-0.35);
      crescentPath(ctx);
      ctx.fill();
      ctx.restore();
      star(ctx, 0.5, -0.25, 5, 0.2, 0.08);
      ctx.fill();
      break;
    case 'star8':
      star(ctx, 0, 0, 8, 1, 0.62, Math.PI / 8);
      ctx.fill();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(0, 0, 0.16, 0, 7);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      break;
    case 'stars':
      star(ctx, -0.25, 0.1, 5, 0.55, 0.22);
      ctx.fill();
      star(ctx, 0.55, -0.55, 4, 0.34, 0.07, 0);
      ctx.fill();
      star(ctx, 0.6, 0.55, 4, 0.22, 0.05, 0);
      ctx.fill();
      break;
    case 'lantern': {
      ctx.lineWidth = 0.07;
      ctx.beginPath(); ctx.arc(0, -0.95, 0.16, 0, Math.PI * 2); ctx.stroke(); // ring
      ctx.beginPath(); ctx.moveTo(-0.3, -0.65); ctx.lineTo(0.3, -0.65); ctx.lineTo(0.18, -0.8); ctx.lineTo(-0.18, -0.8); ctx.closePath(); ctx.fill();
      ctx.beginPath(); // body
      ctx.moveTo(-0.3, -0.58); ctx.quadraticCurveTo(-0.62, -0.1, -0.3, 0.55); ctx.lineTo(0.3, 0.55); ctx.quadraticCurveTo(0.62, -0.1, 0.3, -0.58); ctx.closePath();
      ctx.save(); ctx.globalAlpha *= 0.35; ctx.fill(); ctx.restore(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, -0.58); ctx.lineTo(0, 0.55); ctx.moveTo(-0.28, -0.05); ctx.lineTo(0.28, -0.05); ctx.lineWidth = 0.04; ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-0.32, 0.6); ctx.lineTo(0.32, 0.6); ctx.lineTo(0.2, 0.75); ctx.lineTo(-0.2, 0.75); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(0, 0.75); ctx.lineTo(0, 0.95); ctx.lineWidth = 0.06; ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0.98, 0.07, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, 0.2, 0.08, 0.14, 0, 0, 7); ctx.fill();
      break;
    }
    case 'minaret': {
      ctx.beginPath(); // shaft
      ctx.moveTo(-0.2, 1); ctx.lineTo(-0.14, -0.1); ctx.lineTo(0.14, -0.1); ctx.lineTo(0.2, 1); ctx.closePath(); ctx.fill();
      ctx.fillRect(-0.3, -0.18, 0.6, 0.1); // balcony
      ctx.beginPath(); ctx.moveTo(-0.12, -0.18); ctx.lineTo(-0.1, -0.55); ctx.lineTo(0.1, -0.55); ctx.lineTo(0.12, -0.18); ctx.closePath(); ctx.fill();
      ctx.fillRect(-0.18, -0.62, 0.36, 0.07);
      ctx.beginPath(); ctx.moveTo(-0.13, -0.62); ctx.quadraticCurveTo(-0.13, -0.88, 0, -1.02); ctx.quadraticCurveTo(0.13, -0.88, 0.13, -0.62); ctx.closePath(); ctx.fill();
      ctx.lineWidth = 0.04; ctx.beginPath(); ctx.moveTo(0, -1.02); ctx.lineTo(0, -1.2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, -1.22, 0.05, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath(); ctx.ellipse(0, 0.35, 0.05, 0.14, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, 0.75, 0.05, 0.14, 0, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      break;
    }
    case 'dome': {
      ctx.beginPath(); ctx.moveTo(-0.8, 0.2); ctx.bezierCurveTo(-0.8, -0.6, -0.3, -0.7, 0, -0.95); ctx.bezierCurveTo(0.3, -0.7, 0.8, -0.6, 0.8, 0.2); ctx.closePath(); ctx.fill();
      ctx.fillRect(-0.9, 0.2, 1.8, 0.12);
      ctx.fillRect(-0.7, 0.32, 1.4, 0.55);
      ctx.lineWidth = 0.05; ctx.beginPath(); ctx.moveTo(0, -0.95); ctx.lineTo(0, -1.2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, -1.22, 0.05, 0, 7); ctx.fill();
      ctx.globalCompositeOperation = 'destination-out';
      for (const x of [-0.4, 0, 0.4]) {
        ctx.beginPath(); ctx.moveTo(x - 0.1, 0.87); ctx.lineTo(x - 0.1, 0.55); ctx.arc(x, 0.55, 0.1, Math.PI, 0); ctx.lineTo(x + 0.1, 0.87); ctx.closePath(); ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
      break;
    }
    case 'geo': {
      ctx.lineWidth = 0.045;
      for (const rot of [0, Math.PI / 4]) {
        ctx.save(); ctx.rotate(rot); ctx.strokeRect(-0.62, -0.62, 1.24, 1.24); ctx.restore();
      }
      ctx.beginPath(); ctx.arc(0, 0, 0.9, 0, 7); ctx.stroke();
      star(ctx, 0, 0, 8, 0.62, 0.36, Math.PI / 8); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, 0.12, 0, 7); ctx.fill();
      break;
    }
  }
}

function framePath(ctx: Ctx, frame: FrameId) {
  switch (frame) {
    case 'circle':
      ctx.beginPath(); ctx.arc(0, 0, 1, 0, Math.PI * 2); break;
    case 'rounded': rr(ctx, -1, -1, 2, 2, 0.3); break;
    case 'crescent': crescentPath(ctx, 1, 0.82, 0.38); break;
    case 'star': star(ctx, 0, 0, 5, 1.05, 0.46); break;
    default: ctx.beginPath(); ctx.rect(-1, -1, 2, 2);
  }
}

function drawCover(ctx: Ctx, img: CanvasImageSource & { width: number; height: number }, x: number, y: number, w: number, h: number, zoom: number, panX: number, panY: number) {
  const iw = (img as HTMLImageElement).naturalWidth || img.width, ih = (img as HTMLImageElement).naturalHeight || img.height;
  const k = Math.max(w / iw, h / ih) * zoom;
  const dw = iw * k, dh = ih * k;
  const mx = Math.max(0, (dw - w) / 2), my = Math.max(0, (dh - h) / 2);
  ctx.drawImage(img, x + (w - dw) / 2 + panX * mx, y + (h - dh) / 2 + panY * my, dw, dh);
}

/** For the editor: how many design pixels the image can move at the current zoom. */
export function coverLimits(img: HTMLImageElement, w: number, h: number, zoom: number) {
  const k = Math.max(w / img.naturalWidth, h / img.naturalHeight) * zoom;
  return { mx: Math.max(1, (img.naturalWidth * k - w) / 2), my: Math.max(1, (img.naturalHeight * k - h) / 2) };
}

let bgCache: { key: string; cv: HTMLCanvasElement } | null = null;

function processedBg(img: HTMLImageElement, id: string, w: number, h: number, S: number, b: WidgetDesign['bg']): HTMLCanvasElement {
  const key = [id, w, h, S, b.zoom, b.panX, b.panY, b.blur, b.brightness, b.contrast].join('|');
  if (bgCache?.key === key) return bgCache.cv;
  const cv = document.createElement('canvas');
  cv.width = Math.round(w * S);
  cv.height = Math.round(h * S);
  const g = cv.getContext('2d')!;
  const hasFilter = typeof (g as any).filter === 'string';
  const m = b.blur * 2 * S; // draw a bit larger so blur doesn't fade at the edges
  if (hasFilter) g.filter = `blur(${b.blur * S}px) brightness(${b.brightness}) contrast(${b.contrast})`;
  drawCover(g, img, -m, -m, cv.width + 2 * m, cv.height + 2 * m, b.zoom, b.panX, b.panY);
  if (!hasFilter && b.blur > 0) {
    // Fallback blur for browsers without ctx.filter: down-scale then up-scale
    const small = document.createElement('canvas');
    const f = 1 / (1 + b.blur * 0.6);
    small.width = Math.max(2, Math.round(cv.width * f));
    small.height = Math.max(2, Math.round(cv.height * f));
    small.getContext('2d')!.drawImage(cv, 0, 0, small.width, small.height);
    g.clearRect(0, 0, cv.width, cv.height);
    g.imageSmoothingQuality = 'high';
    g.drawImage(small, 0, 0, cv.width, cv.height);
  }
  bgCache = { key, cv };
  return cv;
}

function drawIcon(ctx: Ctx, key: PrayerKey, cx: number, cy: number, r: number, color: string) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = Math.max(1.4, r * 0.14);
  ctx.lineCap = 'round';
  const rays = (n: number, a: number, b: number, from = 0, to = Math.PI * 2) => {
    for (let i = 0; i < n; i++) {
      const ang = from + ((to - from) * i) / Math.max(1, n - (to - from >= Math.PI * 2 ? 0 : 1));
      ctx.beginPath();
      ctx.moveTo(Math.cos(ang) * a * r, Math.sin(ang) * a * r);
      ctx.lineTo(Math.cos(ang) * b * r, Math.sin(ang) * b * r);
      ctx.stroke();
    }
  };
  switch (key) {
    case 'dhuhr':
      ctx.beginPath(); ctx.arc(0, 0, r * 0.42, 0, 7); ctx.fill(); rays(8, 0.66, 0.92); break;
    case 'asr':
      ctx.beginPath(); ctx.arc(0, 0, r * 0.38, 0, 7); ctx.fill(); rays(6, 0.62, 0.84); break;
    case 'sunrise':
    case 'maghrib': {
      ctx.beginPath(); ctx.arc(0, r * 0.25, r * 0.4, Math.PI, 0); ctx.fill();
      ctx.beginPath(); ctx.moveTo(-r * 0.9, r * 0.25); ctx.lineTo(r * 0.9, r * 0.25); ctx.stroke();
      rays(5, 0.62, 0.86, Math.PI * 1.1, Math.PI * 1.9);
      ctx.beginPath(); ctx.moveTo(0, r * 0.55); ctx.lineTo(0, r * 0.9);
      ctx.moveTo(-r * 0.15, key === 'sunrise' ? r * 0.7 : r * 0.78); ctx.lineTo(0, key === 'sunrise' ? r * 0.55 : r * 0.92); ctx.lineTo(r * 0.15, key === 'sunrise' ? r * 0.7 : r * 0.78);
      ctx.stroke();
      break;
    }
    case 'fajr':
      ctx.save(); ctx.scale(r * 0.8, r * 0.8); crescentPath(ctx); ctx.fill(); ctx.restore();
      star(ctx, r * 0.55, -r * 0.45, 4, r * 0.28, r * 0.06, 0); ctx.fill(); break;
    default:
      ctx.save(); ctx.scale(r * 0.8, r * 0.8); crescentPath(ctx); ctx.fill(); ctx.restore();
      star(ctx, r * 0.5, -r * 0.4, 5, r * 0.2, r * 0.08); ctx.fill();
      star(ctx, r * 0.1, r * 0.65, 4, r * 0.18, r * 0.04, 0); ctx.fill();
  }
  ctx.restore();
}

function drawSticker(ctx: Ctx, st: WSticker, W: number, H: number, img: HTMLImageElement | null | undefined, borderColor: string) {
  const sz = (st.size * W) / 2;
  ctx.save();
  ctx.translate(st.x * W, st.y * H);
  ctx.rotate((st.rot * Math.PI) / 180);
  ctx.globalAlpha = Math.max(0, Math.min(1, st.opacity));
  ctx.scale(sz, sz);
  if (st.kind === 'shape') {
    drawShape(ctx, st.shape, col(st.color, '#e8c877'));
  } else if (img) {
    ctx.save();
    framePath(ctx, st.frame);
    ctx.clip();
    drawCover(ctx, img, -1, -1, 2, 2, 1, 0, 0);
    ctx.restore();
    if (st.frame !== 'none') {
      framePath(ctx, st.frame);
      ctx.lineWidth = 0.05;
      ctx.strokeStyle = col(borderColor);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawDeco(ctx: Ctx, d: WidgetDesign, e: Eff, x: number, y: number, w: number, h: number) {
  const k = d.layout.deco;
  if (k === 'stars') {
    const rnd = seeded(d.id || 'w');
    ctx.fillStyle = col(e.c.text);
    for (let i = 0; i < 34; i++) {
      const sx = x + rnd() * w, sy = y + rnd() * h, sr = 0.5 + rnd() * 1.4;
      ctx.globalAlpha = 0.18 + rnd() * 0.6;
      ctx.beginPath();
      ctx.arc(sx, sy, sr, 0, 7);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.save();
    ctx.translate(x + w - 38, y + 36);
    ctx.scale(20, 20);
    ctx.globalAlpha = 0.85;
    drawShape(ctx, 'crescent', col(e.c.next));
    ctx.restore();
  } else if (k === 'gold') {
    ctx.strokeStyle = col(e.c.border);
    ctx.globalAlpha = 0.6;
    ctx.lineWidth = 1;
    rr(ctx, x + 9, y + 9, w - 18, h - 18, Math.max(6, d.shape.radius - 9));
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.lineWidth = 2;
    const L = 30;
    for (const [cx, cy, sx, sy] of [[x + 16, y + 16, 1, 1], [x + w - 16, y + 16, -1, 1], [x + 16, y + h - 16, 1, -1], [x + w - 16, y + h - 16, -1, -1]] as const) {
      ctx.beginPath();
      ctx.moveTo(cx, cy + sy * L); ctx.lineTo(cx, cy); ctx.lineTo(cx + sx * L, cy);
      ctx.stroke();
      ctx.save(); ctx.translate(cx + sx * 7, cy + sy * 7); ctx.rotate(Math.PI / 4); ctx.fillStyle = col(e.c.border); ctx.fillRect(-3, -3, 6, 6); ctx.restore();
    }
  } else if (k === 'geo') {
    ctx.strokeStyle = col(e.c.accent);
    ctx.globalAlpha = 0.12;
    ctx.lineWidth = 1.2;
    const step = 64;
    for (let gx = x; gx < x + w + step; gx += step) {
      for (let gy = y; gy < y + h + step; gy += step) {
        star(ctx, gx, gy, 8, 26, 16, Math.PI / 8);
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1;
  }
}

// ───────────── content sections ─────────────
interface Layout {
  d: WidgetDesign;
  e: Eff;
  data: WidgetData;
  fmt: (t: Date) => string;
  num: (n: number | string) => string;
}

const keysFor = (d: WidgetDesign): PrayerKey[] => (['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as PrayerKey[]).filter((k) => k !== 'sunrise' || d.show.sunrise);

function remainingText(L: Layout, at: Date) {
  const m = Math.max(0, Math.round((at.getTime() - L.data.now.getTime()) / 60000));
  const h = Math.floor(m / 60), mm = m % 60;
  return h ? `${L.num(h)} س ${L.num(mm)} د` : `${L.num(mm)} د`;
}

function drawHeader(ctx: Ctx, L: Layout, x: number, y: number, w: number, h: number) {
  const { d, e, data } = L;
  const ts = d.scales.title;
  const small = d.size === 'small';
  const lines: { right?: string; left?: string; color?: string }[] = [];
  const hij = fmtHijri(data.hijri, d.digits);
  const greg = toDigits(new Intl.DateTimeFormat('ar-EG-u-nu-latn-ca-gregory', { timeZone: data.tz, weekday: 'long', day: 'numeric', month: 'long' }).format(data.now), d.digits);
  if (small) {
    if (d.show.city) lines.push({ right: data.city });
    if (d.show.hijri) lines.push({ right: hij, color: e.c.text2 });
  } else {
    lines.push({ right: d.show.city ? data.city : undefined, left: d.show.hijri ? hij : undefined });
    const nxt = d.size === 'medium' && d.show.remaining ? `${PRAYER_NAMES[data.sch.next.key]} بعد ${remainingText(L, data.sch.next.at)}` : undefined;
    if (d.show.gregorian || nxt) lines.push({ right: d.show.gregorian ? greg : undefined, left: nxt, color: e.c.text2 });
  }
  const rows = lines.filter((l) => l.right || l.left);
  if (!rows.length) return;
  const lh = h / Math.max(2, rows.length);
  rows.forEach((l, i) => {
    const cy = y + lh * (i + 0.5);
    const size = Math.min(lh * 0.62, 26) * ts * (i === 0 ? 1 : 0.82);
    if (l.right) txt(ctx, l.right, x + w, cy, { size, weight: i === 0 ? d.weights.title : d.weights.time, fam: i === 0 ? e.fam.title : e.fam.time, color: i === 0 ? e.c.text : l.color ?? e.c.text2, align: 'right', maxW: w * (l.left ? 0.55 : 1) });
    if (l.left) txt(ctx, l.left, x, cy, { size: size * 0.92, weight: d.weights.time, fam: e.fam.time, color: i === 0 ? e.c.text2 : e.c.accent, align: 'left', maxW: w * 0.45, ltr: false });
  });
}

function drawMain(ctx: Ctx, L: Layout, x: number, y: number, w: number, h: number) {
  const { d, e, data } = L;
  const { next, prev } = data.sch;
  const total = next.at.getTime() - prev.at.getTime();
  const prog = Math.min(1, Math.max(0, 1 - (next.at.getTime() - data.now.getTime()) / total));
  const name = PRAYER_NAMES[next.key];
  const rem = d.show.remaining ? remainingText(L, next.at) : L.fmt(next.at);
  const cx = x + w / 2;
  const style = d.layout.main;

  if (style === 'ring') {
    const r = Math.min(w, h) / 2 - 10;
    const cy = y + h / 2;
    ctx.lineWidth = r * 0.13;
    ctx.lineCap = 'round';
    ctx.strokeStyle = fade(e.c.text, 0.14);
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.stroke();
    ctx.save();
    ctx.shadowColor = col(e.c.next); ctx.shadowBlur = 10;
    ctx.strokeStyle = col(e.c.next);
    ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0.01, prog)); ctx.stroke();
    ctx.restore();
    txt(ctx, name, cx, cy - r * 0.42, { size: r * 0.3 * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: e.c.next, maxW: r * 1.4 });
    txt(ctx, rem, cx, cy + r * 0.06, { size: r * 0.34 * d.scales.counter, weight: d.weights.counter, fam: e.fam.counter, color: e.c.text, maxW: r * 1.5 });
    txt(ctx, `الأذان ${L.fmt(next.at)}`, cx, cy + r * 0.5, { size: r * 0.18 * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: e.c.text2, maxW: r * 1.4 });
    return;
  }
  if (style === 'bar') {
    const pad = 4;
    txt(ctx, name, x + w - pad, y + h * 0.3, { size: Math.min(h * 0.36, 44) * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: e.c.next, align: 'right', maxW: w * 0.5 });
    txt(ctx, rem, x + pad, y + h * 0.3, { size: Math.min(h * 0.3, 38) * d.scales.counter, weight: d.weights.counter, fam: e.fam.counter, color: e.c.text, align: 'left', maxW: w * 0.46 });
    const by = y + h * 0.66, bh = Math.max(8, h * 0.1);
    ctx.fillStyle = fade(e.c.text, 0.16);
    rr(ctx, x, by, w, bh, bh / 2); ctx.fill();
    ctx.save();
    ctx.shadowColor = col(e.c.next); ctx.shadowBlur = 8;
    ctx.fillStyle = col(e.c.next);
    rr(ctx, x, by, Math.max(bh, w * prog), bh, bh / 2); ctx.fill();
    ctx.restore();
    txt(ctx, `الأذان ${L.fmt(next.at)}`, x + w - pad, y + h * 0.9, { size: Math.min(h * 0.14, 18) * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: e.c.text2, align: 'right' });
    return;
  }
  // text style
  txt(ctx, 'الصلاة الجاية', cx, y + h * 0.1, { size: Math.min(h * 0.12, 18) * d.scales.title, weight: d.weights.time, fam: e.fam.time, color: e.c.text2 });
  txt(ctx, name, cx, y + h * 0.36, { size: Math.min(h * 0.3, 56) * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: e.c.next, maxW: w * 0.9 });
  txt(ctx, rem, cx, y + h * 0.66, { size: Math.min(h * 0.24, 44) * d.scales.counter, weight: d.weights.counter, fam: e.fam.counter, color: e.c.text, maxW: w * 0.9 });
  txt(ctx, `الأذان ${L.fmt(next.at)}`, cx, y + h * 0.9, { size: Math.min(h * 0.12, 18) * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: e.c.accent, maxW: w * 0.9 });
}

function drawList(ctx: Ctx, L: Layout, x: number, y: number, w: number, h: number) {
  const { d, e, data } = L;
  const keys = keysFor(d);
  const n = keys.length;
  const nowMs = data.now.getTime();
  const isNext = (k: PrayerKey) => k === data.sch.next.key && data.sch.today[k].getTime() === data.sch.next.at.getTime();
  const past = (k: PrayerKey) => data.sch.today[k].getTime() <= nowMs;

  if (d.layout.list === 'rows') {
    const rh = h / n;
    keys.forEach((k, i) => {
      const ry = y + i * rh;
      const nx = isNext(k);
      ctx.save();
      ctx.globalAlpha = past(k) && !nx ? 0.5 : 1;
      if (nx) {
        ctx.fillStyle = fade(e.c.next, 0.16);
        rr(ctx, x, ry + 1.5, w, rh - 3, Math.min(rh * 0.32, 16)); ctx.fill();
        ctx.strokeStyle = col(e.c.next); ctx.lineWidth = 1.4; ctx.stroke();
      }
      const mx = rh * 0.3, fs = Math.min(rh * 0.5, 30);
      let nameX = x + w - mx;
      if (d.show.icons) {
        drawIcon(ctx, k, x + w - mx - rh * 0.27, ry + rh / 2, rh * 0.27, nx ? e.c.next : e.c.icons);
        nameX -= rh * 0.7;
      }
      txt(ctx, PRAYER_NAMES[k], nameX, ry + rh / 2, { size: fs * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: nx ? e.c.next : e.c.text, align: 'right', maxW: w * 0.5 });
      txt(ctx, L.fmt(data.sch.today[k]), x + mx, ry + rh / 2, { size: fs * 0.95 * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: nx ? e.c.next : e.c.text2, align: 'left', ltr: true, maxW: w * 0.35 });
      ctx.restore();
    });
    return;
  }

  const cols = d.layout.list === 'cards' ? (d.size === 'large' ? 3 : n) : d.size === 'large' ? 3 : n;
  const rowsN = Math.ceil(n / cols);
  const gap = d.layout.list === 'cards' ? 8 : 0;
  const cw = (w - (cols - 1) * gap) / cols, ch = (h - (rowsN - 1) * gap) / rowsN;
  keys.forEach((k, i) => {
    const r = Math.floor(i / cols), c = i % cols;
    // RTL: first item at the right
    const cx0 = x + w - (c + 1) * cw - c * gap, cy0 = y + r * (ch + gap);
    const nx = isNext(k);
    ctx.save();
    ctx.globalAlpha = past(k) && !nx ? 0.55 : 1;
    if (d.layout.list === 'cards') {
      ctx.save();
      if (nx) { ctx.shadowColor = fade('#ffffff', 0.8); ctx.shadowBlur = 14; }
      ctx.fillStyle = fade(CARD_COLORS[k], 0.9);
      rr(ctx, cx0, cy0, cw, ch, Math.min(20, d.shape.radius * 0.6)); ctx.fill();
      ctx.restore();
      if (nx) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2.5; rr(ctx, cx0, cy0, cw, ch, Math.min(20, d.shape.radius * 0.6)); ctx.stroke(); }
      const mid = cx0 + cw / 2;
      if (d.show.icons && ch > 64) drawIcon(ctx, k, mid, cy0 + ch * 0.26, Math.min(ch * 0.15, cw * 0.18, 16), '#ffffff');
      txt(ctx, PRAYER_NAMES[k], mid, cy0 + ch * (d.show.icons && ch > 64 ? 0.54 : 0.35), { size: Math.min(ch * 0.2, cw * 0.2, 22) * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: '#ffffff', maxW: cw * 0.9 });
      txt(ctx, L.fmt(data.sch.today[k]), mid, cy0 + ch * (d.show.icons && ch > 64 ? 0.8 : 0.72), { size: Math.min(ch * 0.17, cw * 0.17, 19) * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: '#ffffffdd', ltr: true, maxW: cw * 0.92 });
    } else {
      const mid = cx0 + cw / 2;
      if (nx) {
        ctx.fillStyle = fade(e.c.next, 0.14);
        rr(ctx, cx0 + 3, cy0 + 3, cw - 6, ch - 6, 14); ctx.fill();
      }
      txt(ctx, PRAYER_NAMES[k], mid, cy0 + ch * 0.36, { size: Math.min(ch * 0.26, cw * 0.2, 22) * d.scales.title, weight: d.weights.title, fam: e.fam.title, color: nx ? e.c.next : e.c.text2, maxW: cw * 0.9 });
      txt(ctx, L.fmt(data.sch.today[k]), mid, cy0 + ch * 0.68, { size: Math.min(ch * 0.26, cw * 0.19, 21) * d.scales.time, weight: d.weights.time, fam: e.fam.time, color: nx ? e.c.next : e.c.text, ltr: true, maxW: cw * 0.94 });
    }
    ctx.restore();
  });
}

// ───────────── main entry ─────────────
export async function renderWidget(cv: HTMLCanvasElement, d: WidgetDesign, data: WidgetData, env: WidgetEnv, S = 2): Promise<void> {
  const tok = (((cv as any).__tok as number) || 0) + 1;
  (cv as any).__tok = tok;
  const { w: W, h: H } = SIZE_DIMS[d.size];
  const e = resolve(d, env);
  await ensureFonts(e, d);
  const bgImg = e.bgType === 'image' ? await getImage(d.bg.imageId) : null;
  const sImgs = new Map<string, HTMLImageElement | null>();
  for (const st of d.stickers) if (st.kind === 'image') sImgs.set(st.id, await getImage(st.imageId));
  if ((cv as any).__tok !== tok) return; // a newer render started

  cv.width = Math.round(W * S);
  cv.height = Math.round(H * S);
  const ctx = cv.getContext('2d')!;
  ctx.setTransform(S, 0, 0, S, 0, 0);
  ctx.clearRect(0, 0, W, H);

  const sh = d.shape;
  const m = Math.max(4, sh.shadow * 1.1, sh.glow * 1.2) + 2;
  const X = m, Y = m + sh.shadow * 0.12, RW = W - 2 * m, RH = H - 2 * m - sh.shadow * 0.12;
  const rad = Math.min(sh.radius, RW / 2, RH / 2);

  // Shadow + glow (drawn outside only, so translucent widgets stay translucent)
  const outer = (color: string, blur: number, oy: number) => {
    if (blur <= 0) return;
    ctx.save();
    ctx.shadowColor = col(color, '#000000');
    ctx.shadowBlur = blur * S;
    ctx.shadowOffsetY = oy * S;
    ctx.fillStyle = '#000';
    rr(ctx, X, Y, RW, RH, rad);
    ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    rr(ctx, X, Y, RW, RH, rad);
    ctx.fill();
    ctx.restore();
  };
  outer(e.c.shadow, sh.shadow, sh.shadow * 0.3);
  outer(e.c.border === '' ? e.c.next : e.c.next, sh.glow, 0);

  // Background (clipped to the rounded rect)
  ctx.save();
  rr(ctx, X, Y, RW, RH, rad);
  ctx.clip();
  if (e.bgType === 'image' && bgImg) {
    const pc = processedBg(bgImg, d.bg.imageId, RW, RH, S, d.bg);
    ctx.drawImage(pc, X, Y, RW, RH);
    ctx.fillStyle = col(d.bg.overlay, '#00000000');
    ctx.fillRect(X, Y, RW, RH);
  } else if (e.bgType === 'solid') {
    ctx.fillStyle = col(e.solid, '#0b1026');
    ctx.fillRect(X, Y, RW, RH);
  } else {
    const a = (d.bg.angle * Math.PI) / 180;
    const dx = Math.sin(a), dy = -Math.cos(a);
    const half = (Math.abs(dx) * RW + Math.abs(dy) * RH) / 2;
    const cx = X + RW / 2, cy = Y + RH / 2;
    const g = ctx.createLinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half);
    [...e.stops].sort((p, q) => p.p - q.p).forEach((s) => g.addColorStop(Math.max(0, Math.min(1, s.p)), col(s.c, '#000000')));
    ctx.fillStyle = g;
    ctx.fillRect(X, Y, RW, RH);
  }
  drawDeco(ctx, d, e, X, Y, RW, RH);

  // Stickers (behind the text so the widget stays readable)
  ctx.save();
  ctx.translate(X, Y);
  for (const st of d.stickers) drawSticker(ctx, st, RW, RH, sImgs.get(st.id), e.c.border);
  ctx.restore();

  // Content
  const L: Layout = {
    d, e, data,
    fmt: (t) => fmtTime(t, data.tz, d.hour12, d.digits as DigitMode),
    num: (n) => toDigits(n, d.digits as DigitMode),
  };
  const pad = sh.padding;
  const ix = X + pad, iy = Y + pad * 0.8, iw = RW - 2 * pad, ih = RH - pad * 1.6;
  const avail = d.size === 'small' ? ['header', 'main'] : d.size === 'medium' ? ['header', 'list'] : ['header', 'main', 'list'];
  const order = d.order.filter((k) => avail.includes(k));
  const headerVisible = d.size === 'small' ? d.show.city || d.show.hijri : d.show.city || d.show.hijri || d.show.gregorian || (d.size === 'medium' && d.show.remaining);
  const weights: Record<string, number> = d.size === 'large' ? { header: 0.15, main: 0.36, list: 0.49 } : d.size === 'small' ? { header: 0.24, main: 0.76, list: 0 } : { header: 0.24, main: 0, list: 0.76 };
  const active = order.filter((k) => k !== 'header' || headerVisible);
  const sum = active.reduce((a, k) => a + weights[k], 0) || 1;
  let cy = iy;
  for (const k of active) {
    const hh = (weights[k] / sum) * ih;
    if (k === 'header') drawHeader(ctx, L, ix, cy, iw, hh);
    if (k === 'main') drawMain(ctx, L, ix, cy + 2, iw, hh - 4);
    if (k === 'list') drawList(ctx, L, ix, cy + 2, iw, hh - 4);
    cy += hh;
  }
  ctx.restore();

  // Border
  if (sh.borderW > 0) {
    ctx.save();
    ctx.lineWidth = sh.borderW;
    ctx.strokeStyle = col(e.c.border, '#ffffff33');
    rr(ctx, X + sh.borderW / 2, Y + sh.borderW / 2, RW - sh.borderW, RH - sh.borderW, Math.max(0, rad - sh.borderW / 2));
    ctx.stroke();
    ctx.restore();
  }
  // Return rect info for the editor (sticker hit-testing)
  (cv as any).__rect = { X, Y, RW, RH, W, H };
}

export type { Prayer5 };
