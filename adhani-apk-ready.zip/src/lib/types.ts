// Core domain types shared across the whole app (Domain layer).

export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const;
export type Prayer5 = (typeof PRAYERS)[number];
export type PrayerKey = Prayer5 | 'sunrise';
export const ALL_KEYS: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

export const PRAYER_NAMES: Record<PrayerKey, string> = {
  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

/** What happens when a prayer time arrives. */
export type AlertMode = 'full' | 'short' | 'notify' | 'silent';
export const MODE_LABELS: Record<AlertMode, string> = {
  full: 'أذان كامل',
  short: 'تنبيه قصير',
  notify: 'إشعار فقط',
  silent: 'صامت',
};
export const MODE_ORDER: AlertMode[] = ['full', 'short', 'notify', 'silent'];

export type Rec5<T> = Record<Prayer5, T>;
export type DigitMode = 'arabic' | 'latin';
export type Weight = 'light' | 'normal' | 'bold';
