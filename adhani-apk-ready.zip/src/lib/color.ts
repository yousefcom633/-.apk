// Color utilities. All colors in the app are stored as #RRGGBBAA hex strings.

export interface RGBA {
  r: number;
  g: number;
  b: number;
  a: number; // 0..1
}

export function parseColor(input: string): RGBA | null {
  if (typeof input !== 'string') return null;
  let s = input.trim().replace(/^#/, '');
  if (!/^[0-9a-f]+$/i.test(s)) return null;
  if (s.length === 3 || s.length === 4) s = s.split('').map((c) => c + c).join('');
  if (s.length === 6) s += 'ff';
  if (s.length !== 8) return null;
  const n = (i: number) => parseInt(s.slice(i, i + 2), 16);
  return { r: n(0), g: n(2), b: n(4), a: n(6) / 255 };
}

export const isColor = (s: unknown): s is string => typeof s === 'string' && parseColor(s) !== null;

const h2 = (n: number) => Math.round(Math.max(0, Math.min(255, n))).toString(16).padStart(2, '0');

export function toHex(c: RGBA, withAlpha = true): string {
  return '#' + h2(c.r) + h2(c.g) + h2(c.b) + (withAlpha ? h2(c.a * 255) : '');
}

/** Normalize any valid color string to #rrggbbaa (falls back when invalid). */
export function norm(s: string, fallback = '#000000ff'): string {
  const c = parseColor(s);
  return c ? toHex(c) : fallback;
}

export function rgbToHsv(r: number, g: number, b: number) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
  let h = 0;
  if (d) {
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s: max ? d / max : 0, v: max };
}

export function hsvToRgb(h: number, s: number, v: number) {
  const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c;
  let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
}

export function blend(top: RGBA, bottom: RGBA): RGBA {
  const a = top.a + bottom.a * (1 - top.a);
  if (a === 0) return { r: 0, g: 0, b: 0, a: 0 };
  const f = (t: number, b2: number) => (t * top.a + b2 * bottom.a * (1 - top.a)) / a;
  return { r: f(top.r, bottom.r), g: f(top.g, bottom.g), b: f(top.b, bottom.b), a };
}

export function mix(a: string, b: string, t: number): string {
  const x = parseColor(a) ?? { r: 0, g: 0, b: 0, a: 1 };
  const y = parseColor(b) ?? { r: 0, g: 0, b: 0, a: 1 };
  return toHex({
    r: x.r + (y.r - x.r) * t,
    g: x.g + (y.g - x.g) * t,
    b: x.b + (y.b - x.b) * t,
    a: x.a + (y.a - x.a) * t,
  });
}

/** Multiply the alpha of a color by `k`. */
export function fade(color: string, k: number): string {
  const c = parseColor(color) ?? { r: 0, g: 0, b: 0, a: 1 };
  return toHex({ ...c, a: Math.max(0, Math.min(1, c.a * k)) });
}

export function luminance(c: RGBA): number {
  const f = (v: number) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
}

/** WCAG contrast ratio of fg (alpha-blended on bg) vs bg. */
export function contrast(fg: string, bg: string): number {
  const b = parseColor(bg) ?? { r: 0, g: 0, b: 0, a: 1 };
  const bOpaque = { ...b, a: 1 };
  const f = blend(parseColor(fg) ?? { r: 255, g: 255, b: 255, a: 1 }, bOpaque);
  const l1 = luminance(f), l2 = luminance(bOpaque);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}

/** Black or white text color, whichever is readable on `bg`. */
export function readableOn(bg: string): string {
  const c = parseColor(bg);
  if (!c) return '#ffffff';
  return luminance({ ...c, a: 1 }) > 0.4 ? '#0b1026' : '#ffffff';
}

export function colorName(c: string) {
  return norm(c).slice(0, 7).toUpperCase();
}
