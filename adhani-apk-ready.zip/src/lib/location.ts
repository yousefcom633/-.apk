// Location: GPS (one-shot, on demand / on app open) with offline nearest-city naming, or manual city.
import { nearestCity, type City } from '../config/cities';
import { deviceTz } from './format';
import { settingsStore, toast } from '../state/stores';

let lastGps = 0;

export function setCity(c: City) {
  settingsStore.set((s) => ({ ...s, location: { mode: 'city', lat: c.lat, lon: c.lon, name: c.name, tz: c.tz, cityId: c.id } }));
}

export function setManualCoords(lat: number, lon: number, name: string, tz: string) {
  settingsStore.set((s) => ({ ...s, location: { mode: 'city', lat, lon, name: name || 'موقع مخصص', tz, cityId: '' } }));
}

export function refreshGps(verbose: boolean): Promise<boolean> {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) {
      if (verbose) toast('الجهاز لا يدعم تحديد الموقع — اختر مدينة يدويًا', 'error');
      return resolve(false);
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lon } = pos.coords;
        const c = nearestCity(lat, lon);
        lastGps = Date.now();
        settingsStore.set((s) => ({
          ...s,
          location: {
            mode: 'gps', lat: +lat.toFixed(4), lon: +lon.toFixed(4), tz: deviceTz(), cityId: c?.id ?? '',
            name: c ? c.name : `موقعك (${lat.toFixed(2)}، ${lon.toFixed(2)})`,
          },
        }));
        if (verbose) toast('تم تحديث الموقع والمواقيت', 'ok');
        resolve(true);
      },
      () => {
        if (verbose) toast('تعذّر تحديد الموقع. تأكد من تفعيل GPS والسماح للتطبيق، أو اختر مدينة يدويًا.', 'error');
        resolve(false);
      },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 10 * 60000 }
    );
  });
}

/** Auto-refresh GPS location when returning to the app, and follow timezone changes (travel / DST rule changes). */
export function startLocationWatcher() {
  const check = () => {
    const s = settingsStore.get();
    if (s.location.mode !== 'gps') return;
    const tz = deviceTz();
    if (tz !== s.location.tz) settingsStore.set({ location: { ...s.location, tz } });
    if (Date.now() - lastGps > 30 * 60000) void refreshGps(false);
  };
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && check());
  check();
  setInterval(check, 60000);
}
