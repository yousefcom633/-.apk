// Tiny persistent store (acts like DataStore on the web): localStorage + React subscription.
import { useSyncExternalStore } from 'react';

const PREFIX = 'adhani:';

const isObj = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === 'object' && !Array.isArray(v);

/** Merge `over` into `base` keeping only keys known by base (protects against stale/invalid data). */
export function deepMerge<T>(base: T, over: unknown): T {
  if (over === undefined || over === null) return base;
  if (isObj(base)) {
    if (!isObj(over)) return base;
    const out: Record<string, unknown> = { ...base };
    for (const k of Object.keys(base)) if (k in over) out[k] = deepMerge(base[k], over[k]);
    return out as T;
  }
  if (Array.isArray(base)) return (Array.isArray(over) ? over : base) as T;
  if (typeof base === typeof over) return over as T;
  return base;
}

export function setIn(obj: any, path: string[], v: unknown): any {
  if (!path.length) return v;
  const [h, ...r] = path;
  return { ...(obj ?? {}), [h]: setIn(obj?.[h], r, v) };
}

export interface Store<T> {
  get: () => T;
  set: (u: Partial<T> | ((s: T) => T)) => void;
  /** Immutable update by dotted path, e.g. store.setPath('adjust.fajr', 2) */
  setPath: (path: string, v: unknown) => void;
  replace: (s: T) => void;
  reset: () => void;
  subscribe: (f: () => void) => () => void;
  use: () => T;
}

export function createStore<T>(key: string | null, initial: T, merge = true): Store<T> {
  let state: T = initial;
  if (key) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw) {
        const parsed = JSON.parse(raw);
        state = merge ? deepMerge(initial, parsed) : (parsed as T);
      }
    } catch {
      state = initial;
    }
  }
  const subs = new Set<() => void>();
  const emit = () => {
    if (key) {
      try {
        localStorage.setItem(PREFIX + key, JSON.stringify(state));
      } catch {
        /* storage full: keep in memory */
      }
    }
    subs.forEach((f) => f());
  };
  const get = () => state;
  const subscribe = (f: () => void) => {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  };
  return {
    get,
    subscribe,
    set: (u) => {
      state = typeof u === 'function' ? (u as (s: T) => T)(state) : { ...state, ...u };
      emit();
    },
    setPath: (path, v) => {
      state = setIn(state, path.split('.'), v);
      emit();
    },
    replace: (s) => {
      state = s;
      emit();
    },
    reset: () => {
      state = initial;
      emit();
    },
    use: () => useSyncExternalStore(subscribe, get),
  };
}

export const storageKeyPrefix = PREFIX;
export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
