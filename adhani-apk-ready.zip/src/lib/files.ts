// File helpers: download / share / read JSON.
export function downloadBlob(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(a.href);
    a.remove();
  }, 1500);
}

export function downloadJson(name: string, data: unknown) {
  downloadBlob(name.replace(/[^\w\u0600-\u06FF-]+/g, '_') + '.json', new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
}

export async function readJsonFile(file: File): Promise<any> {
  if (file.size > 40 * 1024 * 1024) throw new Error('الملف كبير جدًا');
  const text = await file.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error('الملف ليس JSON صالحًا');
  }
}

/** Shares a file with the native share sheet when supported, otherwise downloads it. */
export async function shareOrDownload(name: string, blob: Blob) {
  const file = new File([blob], name, { type: blob.type });
  try {
    if (navigator.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], title: name });
      return;
    }
  } catch {
    /* user cancelled or unsupported → download */
  }
  downloadBlob(name, blob);
}
