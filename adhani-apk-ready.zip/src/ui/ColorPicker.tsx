// Full color picker: hue/saturation wheel, brightness + alpha sliders, HEX input, screen eyedropper, image eyedropper.
import { Image as ImageIcon, Pipette } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { contrast, hsvToRgb, parseColor, rgbToHsv, toHex } from '../lib/color';
import { toast } from '../state/stores';

const SIZE = 220;

function drawWheel(cv: HTMLCanvasElement) {
  const g = cv.getContext('2d')!;
  const img = g.createImageData(SIZE, SIZE);
  const r = SIZE / 2;
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const dx = x - r + 0.5, dy = y - r + 0.5;
      const d = Math.sqrt(dx * dx + dy * dy);
      const i = (y * SIZE + x) * 4;
      if (d > r) {
        img.data[i + 3] = 0;
        continue;
      }
      let h = (Math.atan2(dy, dx) * 180) / Math.PI;
      if (h < 0) h += 360;
      const c = hsvToRgb(h, Math.min(1, d / r), 1);
      img.data[i] = c.r; img.data[i + 1] = c.g; img.data[i + 2] = c.b;
      img.data[i + 3] = d > r - 1 ? 180 : 255;
    }
  }
  g.putImageData(img, 0, 0);
}

export function ColorPicker({
  value, onChange, contrastWith, alpha = true,
}: {
  value: string; onChange: (hex: string) => void; contrastWith?: string[]; alpha?: boolean;
}) {
  const parsed = parseColor(value) ?? { r: 255, g: 255, b: 255, a: 1 };
  const init = rgbToHsv(parsed.r, parsed.g, parsed.b);
  const [hsv, setHsv] = useState(init);
  const [a, setA] = useState(parsed.a);
  const [hexText, setHexText] = useState(toHex(parsed, alpha && parsed.a < 1).toUpperCase());
  const [img, setImg] = useState<string | null>(null);
  const wheel = useRef<HTMLCanvasElement>(null);
  const imgCv = useRef<HTMLCanvasElement>(null);
  const last = useRef(toHex(parsed));

  useEffect(() => {
    if (wheel.current) drawWheel(wheel.current);
  }, []);

  // External change (e.g. reset button) → resync
  useEffect(() => {
    if (value.toLowerCase() === last.current) return;
    const p = parseColor(value);
    if (!p) return;
    setHsv(rgbToHsv(p.r, p.g, p.b));
    setA(p.a);
    setHexText(toHex(p, alpha && p.a < 1).toUpperCase());
    last.current = toHex(p);
  }, [value, alpha]);

  const emit = (h: { h: number; s: number; v: number }, al: number) => {
    const c = hsvToRgb(h.h, h.s, h.v);
    const hex = toHex({ ...c, a: alpha ? al : 1 });
    last.current = hex;
    setHexText(toHex({ ...c, a: al }, alpha && al < 1).toUpperCase());
    onChange(hex);
  };

  const setRgb = (r: number, g: number, b: number) => {
    const n = rgbToHsv(r, g, b);
    // keep hue when the color is grey
    const h = { h: n.s === 0 ? hsv.h : n.h, s: n.s, v: n.v };
    setHsv(h);
    emit(h, a);
  };

  const onWheel = (e: React.PointerEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * SIZE - SIZE / 2;
    const y = ((e.clientY - rect.top) / rect.height) * SIZE - SIZE / 2;
    let h = (Math.atan2(y, x) * 180) / Math.PI;
    if (h < 0) h += 360;
    const s = Math.min(1, Math.sqrt(x * x + y * y) / (SIZE / 2));
    const n = { ...hsv, h, s };
    setHsv(n);
    emit(n, a);
  };

  const cur = hsvToRgb(hsv.h, hsv.s, hsv.v);
  const curHex = toHex({ ...cur, a: 1 }, false);
  const rad = (hsv.h * Math.PI) / 180;
  const kx = 50 + 50 * hsv.s * Math.cos(rad), ky = 50 + 50 * hsv.s * Math.sin(rad);

  const pickScreen = async () => {
    try {
      const res = await new (window as any).EyeDropper().open();
      const p = parseColor(res.sRGBHex);
      if (p) setRgb(p.r, p.g, p.b);
    } catch {
      /* user cancelled */
    }
  };

  const openImage = (f?: File) => {
    if (!f) return;
    if (!f.type.startsWith('image/')) return toast('اختر ملف صورة', 'error');
    const u = URL.createObjectURL(f);
    const im = new Image();
    im.onload = () => {
      const cv = imgCv.current;
      if (!cv) return;
      const w = 300, h = Math.max(60, Math.round((im.height / im.width) * w));
      cv.width = w;
      cv.height = h;
      cv.getContext('2d', { willReadFrequently: true })!.drawImage(im, 0, 0, w, h);
      URL.revokeObjectURL(u);
    };
    im.onerror = () => toast('تعذّر فتح الصورة', 'error');
    im.src = u;
    setImg(u);
  };

  const pickFromImage = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const cv = e.currentTarget;
    const rect = cv.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * cv.width);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * cv.height);
    const d = cv.getContext('2d', { willReadFrequently: true })!.getImageData(x, y, 1, 1).data;
    setRgb(d[0], d[1], d[2]);
  };

  const warnings = (contrastWith ?? []).map((bg) => ({ bg, ratio: contrast(toHex({ ...cur, a }), bg) }));
  const worst = warnings.length ? Math.min(...warnings.map((w) => w.ratio)) : 21;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative touch-none" style={{ width: SIZE, height: SIZE }} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); onWheel(e); }} onPointerMove={(e) => e.buttons && onWheel(e)}>
        <canvas ref={wheel} width={SIZE} height={SIZE} className="absolute inset-0 h-full w-full rounded-full" />
        <div className="pointer-events-none absolute inset-0 rounded-full" style={{ background: `rgba(0,0,0,${1 - hsv.v})` }} />
        <div
          className="pointer-events-none absolute h-6 w-6 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{ left: `${kx}%`, top: `${ky}%`, background: curHex, border: '3px solid #fff', boxShadow: '0 0 0 1.5px rgba(0,0,0,.5), 0 2px 8px rgba(0,0,0,.5)' }}
        />
      </div>

      <div className="w-full space-y-3" dir="ltr">
        <label className="block">
          <span className="t2 mb-1 block text-xs" dir="rtl">السطوع</span>
          <input
            type="range" className="grad" min={0} max={1} step={0.005} value={hsv.v}
            style={{ background: `linear-gradient(to right,#000,${toHex({ ...hsvToRgb(hsv.h, hsv.s, 1), a: 1 }, false)})`, height: 10, borderRadius: 99 }}
            onChange={(e) => { const n = { ...hsv, v: +e.target.value }; setHsv(n); emit(n, a); }}
          />
        </label>
        {alpha && (
          <label className="block">
            <span className="t2 mb-1 block text-xs" dir="rtl">الشفافية</span>
            <div className="checker rounded-full">
              <input
                type="range" className="grad" min={0} max={1} step={0.005} value={a}
                style={{ background: `linear-gradient(to right,transparent,${curHex})`, height: 10, borderRadius: 99 }}
                onChange={(e) => { setA(+e.target.value); emit(hsv, +e.target.value); }}
              />
            </div>
          </label>
        )}
      </div>

      <div className="flex w-full items-center gap-2" dir="ltr">
        <span className="checker h-10 w-10 shrink-0 overflow-hidden rounded-xl" style={{ border: '2px solid var(--card-bc)' }}>
          <span className="block h-full w-full" style={{ background: toHex({ ...cur, a }) }} />
        </span>
        <input
          type="text" dir="ltr" value={hexText} maxLength={9} spellCheck={false}
          onChange={(e) => {
            const t = e.target.value.toUpperCase();
            setHexText(t);
            const p = parseColor(t.startsWith('#') ? t : '#' + t);
            if (p && (t.replace('#', '').length === 6 || t.replace('#', '').length === 8 || t.replace('#', '').length === 3)) {
              setHsv(rgbToHsv(p.r, p.g, p.b));
              setA(alpha ? p.a : 1);
              const hex = toHex({ ...p, a: alpha ? p.a : 1 });
              last.current = hex;
              onChange(hex);
            }
          }}
          placeholder="#RRGGBB"
        />
        {'EyeDropper' in window && (
          <button className="btn btn-ghost !p-2.5" onClick={pickScreen} title="قطّارة من الشاشة" aria-label="قطّارة">
            <Pipette size={18} />
          </button>
        )}
        <label className="btn btn-ghost !p-2.5 cursor-pointer" title="قطّارة من صورة">
          <ImageIcon size={18} />
          <input type="file" accept="image/*" className="hidden" onChange={(e) => { openImage(e.target.files?.[0]); e.target.value = ''; }} />
        </label>
      </div>

      <canvas
        ref={imgCv}
        className="w-full max-w-[300px] cursor-crosshair touch-none rounded-xl"
        style={{ display: img ? 'block' : 'none', border: '1px solid var(--card-bc)' }}
        onPointerDown={pickFromImage}
        onPointerMove={(e) => e.buttons && pickFromImage(e)}
      />
      {img && <p className="t2 text-xs">اضغط على أي نقطة في الصورة لالتقاط لونها</p>}

      {warnings.length > 0 && (
        <div
          className="w-full rounded-xl px-3 py-2 text-xs leading-relaxed"
          style={{
            background: worst < 3 ? 'rgba(229,72,77,.18)' : worst < 4.5 ? 'rgba(245,165,36,.16)' : 'rgba(80,200,120,.14)',
            color: 'var(--c-textPrimary)',
          }}
        >
          {worst < 3
            ? `⚠️ التباين ضعيف جدًا (${worst.toFixed(1)}:1) — النص سيكون صعب القراءة.`
            : worst < 4.5
              ? `⚠️ التباين متوسط (${worst.toFixed(1)}:1) — يفضّل لون أوضح.`
              : `✓ التباين جيد (${worst.toFixed(1)}:1).`}
        </div>
      )}
    </div>
  );
}
