// Full-screen adhan view shown while the adhan plays (same theme as the app) + post-prayer adhkar.
import { Play, Square, X } from 'lucide-react';
import { ADHKAR } from '../config/adhkar';
import { playerStore, stopPlayback } from '../lib/audio';
import { useDisplay, useSchedule } from '../lib/hooks';
import { clearNotifications } from '../lib/notify';
import { startAdhanAudio } from '../lib/scheduler';
import { PRAYER_NAMES } from '../lib/types';
import { adhanStore } from '../state/stores';
import { Background } from './Background';

export function AdhanOverlay() {
  const a = adhanStore.use();
  const p = playerStore.use();
  const d = useDisplay();
  const { sch } = useSchedule();
  if (!a.active || !a.prayer) return null;

  const close = () => {
    stopPlayback();
    adhanStore.set({ active: false });
    void clearNotifications();
  };
  const at = sch.today[a.prayer];

  return (
    <div className="fade-enter fixed inset-0 z-[100] overflow-hidden" style={{ background: 'var(--c-bgStart)' }}>
      <Background />
      <div className="relative z-10 flex h-full flex-col items-center justify-between px-6 pb-10 pt-14 text-center">
        {a.phase === 'playing' ? (
          <>
            <div>
              <div className="t2 text-sm" data-edit="textSecondary">{d.settings.location.name}</div>
              <div className="f-heading mt-1 text-lg" style={{ color: 'var(--c-nextGlow)' }}>حان الآن موعد</div>
            </div>
            <div>
              <div
                className="f-heading t1 text-6xl leading-tight"
                style={{ textShadow: '0 0 40px var(--c-nextGlow)' }}
                data-edit="textPrimary"
              >
                {PRAYER_NAMES[a.prayer]}
              </div>
              <div className="f-num tacc mt-3 text-4xl" data-edit="accent">{d.time(at)}</div>
              <div className="t2 mt-5 text-sm" data-edit="textSecondary">حيّ على الصلاة · حيّ على الفلاح</div>
              {p.playing && (
                <div className="mx-auto mt-6 h-1.5 w-56 overflow-hidden rounded-full" style={{ background: 'var(--card-bc)' }}>
                  <div className="h-full rounded-full" style={{ width: `${p.duration ? (p.progress / p.duration) * 100 : 10}%`, background: 'var(--c-accent)' }} />
                </div>
              )}
              {p.playing && <div className="t2 mt-2 text-xs">{p.label}</div>}
              {a.note && (
                <div className="gcard mx-auto mt-5 max-w-xs px-4 py-3 text-xs leading-relaxed" style={{ borderColor: 'var(--c-notif)' }}>
                  {a.note}
                </div>
              )}
            </div>
            <div className="flex w-full max-w-xs flex-col gap-3">
              {a.blocked && (
                <button className="btn !py-4 text-base" onClick={() => void startAdhanAudio(a.prayer!)}>
                  <Play size={20} /> تشغيل الأذان
                </button>
              )}
              <button className={`btn ${a.blocked ? 'btn-ghost' : ''} !py-4 text-base`} onClick={close}>
                <Square size={18} /> إيقاف الأذان
              </button>
            </div>
          </>
        ) : (
          <>
            <div>
              <div className="f-heading t1 text-2xl" data-edit="textPrimary">أذكار بعد الصلاة</div>
              <div className="t2 mt-1 text-xs">تقبّل الله طاعتكم</div>
            </div>
            <div className="no-scrollbar max-h-[62vh] w-full max-w-md space-y-2 overflow-y-auto text-start">
              {ADHKAR.map((z, i) => (
                <div key={i} className="gcard flex items-start justify-between gap-3 px-4 py-3" data-edit="card">
                  <span className="t1 text-sm leading-relaxed">{z.text}</span>
                  {z.count > 1 && <span className="f-num tacc shrink-0 text-sm">×{d.num(z.count)}</span>}
                </div>
              ))}
            </div>
            <button className="btn !px-8 !py-3" onClick={close}>
              <X size={18} /> إغلاق
            </button>
          </>
        )}
      </div>
    </div>
  );
}
