// Animated app background: gradient/solid/image + time-of-day tint + slow twinkling stars + crescent.
import { useEffect, useRef, useState } from 'react';
import { imageUrl } from '../lib/assets';
import { fade } from '../lib/color';
import { useNow } from '../lib/ticker';
import { settingsStore, themeStore } from '../state/stores';

function Stars({ color, density, speed, size }: { color: string; density: number; speed: number; size: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const g = cv.getContext('2d')!;
    let stars: { x: number; y: number; r: number; ph: number; k: number }[] = [];
    const build = () => {
      cv.width = window.innerWidth;
      cv.height = window.innerHeight;
      const n = Math.round(25 + density * 190);
      stars = Array.from({ length: n }, () => ({
        x: Math.random() * cv.width,
        y: Math.random() * cv.height,
        r: (0.4 + Math.random() * 1.2) * size,
        ph: Math.random() * 6.28,
        k: 0.6 + Math.random() * 0.8,
      }));
    };
    const draw = (t: number) => {
      g.clearRect(0, 0, cv.width, cv.height);
      g.fillStyle = color;
      const w = 0.15 + speed * 0.9; // very slow by default
      for (const s of stars) {
        g.globalAlpha = speed === 0 ? 0.7 : 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * w * s.k + s.ph));
        if (s.r < 1) g.fillRect(s.x, s.y, s.r * 1.6, s.r * 1.6);
        else {
          g.beginPath();
          g.arc(s.x, s.y, s.r, 0, 6.2832);
          g.fill();
        }
      }
    };
    build();
    const t0 = Date.now();
    draw(0);
    // ~10 fps is plenty for slow twinkling and is battery friendly
    const id = speed === 0 ? undefined : setInterval(() => !document.hidden && draw((Date.now() - t0) / 1000), 100);
    const rs = () => {
      build();
      draw((Date.now() - t0) / 1000);
    };
    window.addEventListener('resize', rs);
    return () => {
      if (id) clearInterval(id);
      window.removeEventListener('resize', rs);
    };
  }, [color, density, speed, size]);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 h-full w-full" />;
}

function Crescent({ color, pos }: { color: string; pos: 'right' | 'left' | 'center' }) {
  const place = pos === 'right' ? { right: '8%' } : pos === 'left' ? { left: '8%' } : { left: '50%', transform: 'translateX(-50%)' };
  return (
    <svg
      data-edit="crescent"
      viewBox="0 0 100 100"
      className="pointer-events-none absolute top-[1rem] h-20 w-20"
      style={{ ...place, filter: `drop-shadow(0 0 14px ${fade(color, 0.55)})`, opacity: 0.92 }}
    >
      <defs>
        <mask id="cm">
          <rect width="100" height="100" fill="#fff" />
          <circle cx="62" cy="40" r="34" fill="#000" />
        </mask>
      </defs>
      <circle cx="46" cy="52" r="36" fill={color} mask="url(#cm)" />
    </svg>
  );
}

/** Soft color overlay that follows the time of day (dawn → day → sunset → night). */
function tintFor(hour: number): string {
  if (hour >= 4 && hour < 7) return 'linear-gradient(to top, rgba(255,150,120,.16), transparent 65%)';
  if (hour >= 7 && hour < 16) return 'linear-gradient(to bottom, rgba(120,180,255,.10), transparent 70%)';
  if (hour >= 16 && hour < 19.5) return 'linear-gradient(to top, rgba(255,130,80,.17), transparent 70%)';
  return 'linear-gradient(to bottom, rgba(0,0,30,.12), transparent)';
}

export function Background() {
  const t = themeStore.use();
  const now = useNow();
  const tz = settingsStore.use().location.tz;
  const [img, setImg] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    if (t.bg.type === 'image' && t.bg.imageId) void imageUrl(t.bg.imageId).then((u) => alive && setImg(u));
    else setImg(null);
    return () => {
      alive = false;
    };
  }, [t.bg.type, t.bg.imageId]);

  let hour = 22;
  try {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: 'numeric', minute: 'numeric', hourCycle: 'h23' }).formatToParts(now);
    hour = +(parts.find((p) => p.type === 'hour')?.value ?? 22) + +(parts.find((p) => p.type === 'minute')?.value ?? 0) / 60;
  } catch {
    /* ignore */
  }

  const base =
    t.bg.type === 'solid'
      ? t.colors.bgStart
      : `linear-gradient(165deg, ${t.colors.bgStart} 0%, ${t.colors.bgEnd} 100%)`;

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" style={{ background: base }}>
      {t.bg.type === 'image' && img && (
        <div
          className="absolute inset-[-8%]"
          style={{ backgroundImage: `url(${img})`, backgroundSize: 'cover', backgroundPosition: 'center', filter: `blur(${t.bg.blur}px)` }}
        />
      )}
      {t.bg.type === 'image' && (
        <div className="absolute inset-0" style={{ background: fade(t.colors.bgStart, 1), opacity: t.bg.dim }} />
      )}
      {t.bg.timeTint && t.bg.type !== 'image' && <div className="absolute inset-0 transition-opacity duration-[3000ms]" style={{ background: tintFor(hour) }} />}
      {t.stars.on && <Stars color={t.colors.stars} density={t.stars.density} speed={t.stars.speed} size={t.stars.size} />}
      {t.crescent.on && <Crescent color={t.colors.crescent} pos={t.crescent.pos} />}
    </div>
  );
}
