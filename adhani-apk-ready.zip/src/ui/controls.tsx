// Shared UI building blocks. Everything is styled through ThemeState CSS variables.
import { Minus, Plus, X } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { toastStore } from '../state/stores';
import { toDigits } from '../lib/format';
import { themeStore } from '../state/stores';
import { colorName } from '../lib/color';
import { ColorPicker } from './ColorPicker';

export function Section({ title, children, hint, right }: { title?: string; hint?: string; right?: ReactNode; children: ReactNode }) {
  return (
    <section className="mb-4">
      {title && (
        <div className="mb-2 flex items-center justify-between px-1">
          <h3 className="f-heading t1 text-[0.95rem]">{title}</h3>
          {right}
        </div>
      )}
      <div className="gcard divide-y divide-white/5 overflow-hidden">{children}</div>
      {hint && <p className="t2 mt-1.5 px-2 text-xs leading-relaxed">{hint}</p>}
    </section>
  );
}

export function Row({ label, sub, children, col }: { label: ReactNode; sub?: string; children?: ReactNode; col?: boolean }) {
  return (
    <div className={`flex gap-3 px-4 py-3 ${col ? 'flex-col' : 'items-center justify-between'}`}>
      <div className="min-w-0 flex-1">
        <div className="t1 text-sm">{label}</div>
        {sub && <div className="t2 mt-0.5 text-xs leading-relaxed">{sub}</div>}
      </div>
      {children}
    </div>
  );
}

export function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className="relative h-7 w-12 shrink-0 rounded-full transition-colors"
      style={{ background: on ? 'var(--c-button)' : 'var(--card-bc)' }}
    >
      <span
        className="absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all"
        style={{ right: on ? '1.5rem' : '0.125rem', background: on ? 'var(--c-buttonText)' : '#fff' }}
      />
    </button>
  );
}

export function ToggleRow({ label, sub, on, onChange }: { label: string; sub?: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <Row label={label} sub={sub}>
      <Toggle on={on} onChange={onChange} />
    </Row>
  );
}

export function SliderRow({
  label, value, min, max, step = 0.01, onChange, format, sub,
}: {
  label: string; value: number; min: number; max: number; step?: number; sub?: string;
  onChange: (v: number) => void; format?: (v: number) => string;
}) {
  const digits = themeStore.use().digits;
  return (
    <Row label={label} sub={sub} col>
      <div className="flex items-center gap-3">
        <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} />
        <span className="t2 f-num w-14 shrink-0 text-center text-xs">
          {toDigits(format ? format(value) : Math.round(value * 100) / 100, digits)}
        </span>
      </div>
    </Row>
  );
}

export function Segmented<T extends string>({ value, options, onChange }: { value: T; options: { id: T; label: ReactNode }[]; onChange: (v: T) => void }) {
  return (
    <div className="no-scrollbar flex gap-1.5 overflow-x-auto">
      {options.map((o) => (
        <button key={o.id} className="chip" data-on={value === o.id} onClick={() => onChange(o.id)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Stepper({ value, onChange, min = -60, max = 60, step = 1, unit = 'د' }: { value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; unit?: string }) {
  const digits = themeStore.use().digits;
  const clamp = (v: number) => Math.min(max, Math.max(min, v));
  return (
    <div className="flex items-center gap-2" dir="ltr">
      <button className="btn btn-ghost !p-2" onClick={() => onChange(clamp(value - step))} aria-label="أنقص">
        <Minus size={16} />
      </button>
      <span className="f-num t1 w-12 text-center text-sm" dir="ltr">
        {toDigits((value > 0 && min < 0 ? '+' : '') + value, digits)} <span className="t2 text-[0.65rem]">{unit}</span>
      </span>
      <button className="btn btn-ghost !p-2" onClick={() => onChange(clamp(value + step))} aria-label="زِد">
        <Plus size={16} />
      </button>
    </div>
  );
}

export function SelectRow({ label, sub, value, options, onChange }: { label: string; sub?: string; value: string; options: { id: string; name: string }[]; onChange: (v: string) => void }) {
  return (
    <Row label={label} sub={sub} col>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => (
          <option key={o.id} value={o.id}>
            {o.name}
          </option>
        ))}
      </select>
    </Row>
  );
}

export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fade-enter fixed inset-0 z-[80] flex items-end justify-center bg-black/55" onClick={onClose}>
      <div
        className="sheet-enter no-scrollbar max-h-[88vh] w-full max-w-lg overflow-y-auto rounded-t-[28px] p-5"
        style={{ background: 'color-mix(in srgb, var(--c-bgStart) 92%, var(--c-bgEnd))', borderTop: '1px solid var(--card-bc)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="f-heading t1 text-base">{title}</h3>
          <button className="btn btn-ghost !p-2" onClick={onClose} aria-label="إغلاق">
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** Color swatch row that opens the full color picker in a sheet. */
export function ColorField({
  label, value, onChange, onReset, contrastWith, alpha = true,
}: {
  label: string; value: string; onChange: (v: string) => void; onReset?: () => void; contrastWith?: string[]; alpha?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="flex w-full items-center justify-between gap-3 px-4 py-3 text-start" onClick={() => setOpen(true)}>
        <span className="t1 text-sm">{label}</span>
        <span className="flex items-center gap-2">
          <span className="t2 f-num text-[0.7rem]">{colorName(value)}</span>
          <span className="checker h-7 w-7 overflow-hidden rounded-full" style={{ border: '2px solid var(--card-bc)' }}>
            <span className="block h-full w-full" style={{ background: value }} />
          </span>
        </span>
      </button>
      <Sheet open={open} onClose={() => setOpen(false)} title={label}>
        <ColorPicker value={value} onChange={onChange} contrastWith={contrastWith} alpha={alpha} />
        <div className="mt-4 flex gap-2">
          {onReset && (
            <button className="btn btn-ghost flex-1" onClick={onReset}>
              إعادة الضبط
            </button>
          )}
          <button className="btn flex-1" onClick={() => setOpen(false)}>
            تم
          </button>
        </div>
      </Sheet>
    </>
  );
}

export function Toaster() {
  const { items } = toastStore.use();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[120] flex flex-col items-center gap-2 px-4">
      {items.map((t) => (
        <div
          key={t.id}
          className="screen-enter gcard max-w-md px-4 py-2.5 text-center text-sm shadow-lg"
          style={{
            background: 'color-mix(in srgb, var(--c-bgStart) 90%, transparent)',
            borderColor: t.kind === 'error' ? '#e5484d' : t.kind === 'ok' ? 'var(--c-accent)' : 'var(--c-notif)',
            color: 'var(--c-textPrimary)',
          }}
        >
          {t.msg}
        </div>
      ))}
    </div>
  );
}

export function PageHeader({ title, onBack, right }: { title: string; onBack?: () => void; right?: ReactNode }) {
  return (
    <div className="mb-4 flex items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        {onBack && (
          <button className="btn btn-ghost !p-2" onClick={onBack} aria-label="رجوع">
            <span className="text-lg leading-none">›</span>
          </button>
        )}
        <h2 data-edit="textPrimary" className="f-heading t1 text-xl">
          {title}
        </h2>
      </div>
      {right}
    </div>
  );
}
