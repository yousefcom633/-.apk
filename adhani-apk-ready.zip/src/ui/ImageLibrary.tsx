// "My images" library: add from gallery, delete, pick. Shared by app background and widget editor.
import { Plus, Trash2 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { BUILTIN_IMAGES, deleteImage, imageUrl, importImage } from '../lib/assets';
import { imagesStore, toast } from '../state/stores';

function Thumb({ id }: { id: string }) {
  const [u, setU] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    void imageUrl(id).then((x) => alive && setU(x));
    return () => {
      alive = false;
    };
  }, [id]);
  return <div className="h-full w-full bg-cover bg-center" style={{ backgroundImage: u ? `url(${u})` : undefined, background: u ? undefined : 'var(--card-bc)' }} />;
}

export function ImageLibrary({ selected, onPick, pickLabel }: { selected?: string; onPick?: (id: string) => void; pickLabel?: string }) {
  const lib = imagesStore.use();
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const add = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    for (const f of Array.from(files)) {
      try {
        const id = await importImage(f);
        toast('تمت إضافة الصورة إلى مكتبتك', 'ok');
        if (files.length === 1) onPick?.(id);
      } catch (e: any) {
        toast(e.message ?? 'تعذّر إضافة الصورة', 'error');
      }
    }
    setBusy(false);
  };

  const all = [...BUILTIN_IMAGES.map((b) => ({ id: b.id, builtin: true })), ...lib.items.map((i) => ({ id: i.id, builtin: false }))];

  return (
    <div>
      <div className="grid grid-cols-4 gap-2">
        {all.map((im) => (
          <div key={im.id} className="relative aspect-square overflow-hidden rounded-xl" style={{ outline: selected === im.id ? '3px solid var(--c-accent)' : '1px solid var(--card-bc)' }}>
            <button className="h-full w-full" onClick={() => onPick?.(im.id)} aria-label={pickLabel ?? 'اختيار'}>
              <Thumb id={im.id} />
            </button>
            {!im.builtin && (
              <button
                className="absolute left-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/60 text-red-300"
                aria-label="حذف الصورة"
                onClick={async () => {
                  await deleteImage(im.id);
                  toast('تم حذف الصورة');
                }}
              >
                <Trash2 size={12} />
              </button>
            )}
          </div>
        ))}
        <button className="gcard grid aspect-square place-items-center" disabled={busy} onClick={() => ref.current?.click()} aria-label="إضافة صورة">
          <Plus size={24} className="ticon" />
        </button>
      </div>
      <input ref={ref} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { void add(e.target.files); e.target.value = ''; }} />
      <p className="t2 mt-2 text-xs">الصور الكبيرة تُضغط تلقائيًا، والتالفة تُرفض برسالة واضحة.</p>
    </div>
  );
}
