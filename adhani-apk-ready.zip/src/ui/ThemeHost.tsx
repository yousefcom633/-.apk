// Applies ThemeState to CSS variables, runs the long-press edit mode and hosts the global color editor.
import { useEffect } from 'react';
import { COLOR_KEYS, COLOR_META, DEFAULT_THEME, type ColorKey, type ThemeState } from '../config/themes';
import { fontStack, WEIGHT_VALUES } from '../config/fonts';
import { fade, mix, parseColor, readableOn, toHex, luminance } from '../lib/color';
import { fontsRev, themeStore, uiStore } from '../state/stores';
import { ColorPicker } from './ColorPicker';
import { Sheet } from './controls';

export function themeVars(t: ThemeState): Record<string, string> {
  const c = t.colors;
  const v: Record<string, string> = {};
  for (const k of COLOR_KEYS) v['--c-' + k] = c[k];
  v['--c-bgMid'] = mix(c.bgStart, c.bgEnd, 0.5);
  v['--c-buttonText'] = readableOn(c.button);
  v['--f-heading'] = fontStack(t.fonts.heading);
  v['--f-body'] = fontStack(t.fonts.body);
  v['--f-numbers'] = fontStack(t.fonts.numbers);
  v['--fs'] = String(t.fontScale);
  v['--fw'] = String(WEIGHT_VALUES[t.fontWeight]);
  v['--fwh'] = t.fontWeight === 'light' ? '400' : '700';
  const cardColor = parseColor(c.card) ?? { r: 255, g: 255, b: 255, a: 0.08 };
  const border = fade(c.textPrimary, 0.18);
  if (t.card.style === 'glass') {
    v['--card-bg'] = c.card;
    v['--card-blur'] = t.card.blur + 'px';
  } else if (t.card.style === 'solid') {
    v['--card-bg'] = mix(c.bgEnd, toHex({ ...cardColor, a: 1 }), Math.min(0.55, Math.max(0.14, cardColor.a * 1.6)));
    v['--card-blur'] = '0px';
  } else {
    v['--card-bg'] = 'transparent';
    v['--card-blur'] = '0px';
  }
  v['--card-bc'] = border;
  v['--card-r'] = t.card.radius + 'px';
  v['--card-bw'] = t.card.border + 'px';
  return v;
}

export function ThemeHost() {
  const theme = themeStore.use();
  const { rev } = fontsRev.use();
  const ui = uiStore.use();

  useEffect(() => {
    const vars = themeVars(theme);
    const root = document.documentElement;
    for (const k of Object.keys(vars)) root.style.setProperty(k, vars[k]);
    const dark = luminance({ ...(parseColor(theme.colors.bgEnd) ?? { r: 0, g: 0, b: 0, a: 1 }), a: 1 }) < 0.4;
    root.style.colorScheme = dark ? 'dark' : 'light';
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme.colors.bgStart.slice(0, 7));
  }, [theme, rev]);

  useEffect(() => {
    document.body.classList.toggle('edit-mode', ui.editMode);
  }, [ui.editMode]);

  // Long-press anywhere on an element with data-edit="<colorKey>" → open its color editor.
  useEffect(() => {
    if (!ui.editMode) return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let sx = 0, sy = 0;
    const swallow = (e: Event) => {
      e.stopPropagation();
      e.preventDefault();
    };
    const cancel = () => {
      if (timer) clearTimeout(timer);
      timer = undefined;
    };
    const down = (e: PointerEvent) => {
      const el = (e.target as HTMLElement | null)?.closest?.('[data-edit]') as HTMLElement | null;
      if (!el || (e.target as HTMLElement).closest('[data-no-edit]')) return;
      const key = el.dataset.edit as ColorKey;
      if (!(key in COLOR_META)) return;
      sx = e.clientX;
      sy = e.clientY;
      cancel();
      timer = setTimeout(() => {
        navigator.vibrate?.(30);
        uiStore.set({ editKey: key });
        window.addEventListener('click', swallow, { capture: true, once: true });
        setTimeout(() => window.removeEventListener('click', swallow, true), 600);
      }, 520);
    };
    const move = (e: PointerEvent) => {
      if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) > 12) cancel();
    };
    const ctxm = (e: Event) => e.preventDefault();
    document.addEventListener('pointerdown', down, true);
    document.addEventListener('pointermove', move, true);
    document.addEventListener('pointerup', cancel, true);
    document.addEventListener('pointercancel', cancel, true);
    document.addEventListener('contextmenu', ctxm);
    return () => {
      cancel();
      document.removeEventListener('pointerdown', down, true);
      document.removeEventListener('pointermove', move, true);
      document.removeEventListener('pointerup', cancel, true);
      document.removeEventListener('pointercancel', cancel, true);
      document.removeEventListener('contextmenu', ctxm);
    };
  }, [ui.editMode]);

  const key = ui.editKey;
  return (
    <>
      {ui.editMode && (
        <div
          data-no-edit
          className="fixed inset-x-0 bottom-20 z-[70] mx-auto flex max-w-sm items-center justify-between gap-2 rounded-full px-4 py-2 text-xs shadow-xl"
          style={{ background: 'var(--c-button)', color: 'var(--c-buttonText)' }}
        >
          <span>وضع التعديل: اضغط مطوّلًا على أي عنصر لتغيير لونه</span>
          <button className="font-bold underline" onClick={() => uiStore.set({ editMode: false })}>
            إنهاء
          </button>
        </div>
      )}
      <Sheet open={!!key} onClose={() => uiStore.set({ editKey: null })} title={key ? COLOR_META[key].label : ''}>
        {key && (
          <>
            <ColorPicker
              value={theme.colors[key]}
              onChange={(hex) => themeStore.setPath('colors.' + key, hex)}
              contrastWith={['textPrimary', 'textSecondary', 'accent', 'ring', 'icons', 'nextGlow'].includes(key) ? [theme.colors.bgStart, theme.colors.bgEnd] : undefined}
            />
            <div className="mt-4 flex gap-2">
              <button className="btn btn-ghost flex-1" onClick={() => themeStore.setPath('colors.' + key, DEFAULT_THEME.colors[key])}>
                إعادة ضبط هذا العنصر
              </button>
              <button className="btn flex-1" onClick={() => uiStore.set({ editKey: null })}>
                تم
              </button>
            </div>
          </>
        )}
      </Sheet>
    </>
  );
}
