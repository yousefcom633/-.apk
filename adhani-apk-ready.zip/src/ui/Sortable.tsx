// Pointer-based drag-to-reorder list (works with touch, unlike HTML5 drag & drop).
import { GripVertical } from 'lucide-react';
import { useRef, useState, type ReactNode } from 'react';

export function Sortable({
  items, onChange, render,
}: {
  items: string[];
  onChange: (next: string[]) => void;
  render: (id: string) => ReactNode;
}) {
  const [drag, setDrag] = useState<{ from: number; to: number; dy: number; h: number } | null>(null);
  const startY = useRef(0);
  const refs = useRef<(HTMLDivElement | null)[]>([]);

  const begin = (e: React.PointerEvent, i: number) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    startY.current = e.clientY;
    const h = (refs.current[i]?.getBoundingClientRect().height ?? 48) + 0;
    setDrag({ from: i, to: i, dy: 0, h });
  };
  const move = (e: React.PointerEvent) => {
    if (!drag) return;
    const dy = e.clientY - startY.current;
    const to = Math.max(0, Math.min(items.length - 1, drag.from + Math.round(dy / drag.h)));
    setDrag({ ...drag, dy, to });
  };
  const end = () => {
    if (!drag) return;
    if (drag.to !== drag.from) {
      const n = [...items];
      const [m] = n.splice(drag.from, 1);
      n.splice(drag.to, 0, m);
      onChange(n);
    }
    setDrag(null);
  };

  return (
    <div>
      {items.map((id, i) => {
        let ty = 0;
        if (drag) {
          if (i === drag.from) ty = drag.dy;
          else if (drag.from < drag.to && i > drag.from && i <= drag.to) ty = -drag.h;
          else if (drag.from > drag.to && i >= drag.to && i < drag.from) ty = drag.h;
        }
        const active = drag?.from === i;
        return (
          <div
            key={id}
            ref={(el) => {
              refs.current[i] = el;
            }}
            className="flex items-center gap-2 px-3 py-2.5"
            style={{
              transform: `translateY(${ty}px)`,
              transition: active ? 'none' : 'transform .18s',
              zIndex: active ? 5 : 0,
              position: 'relative',
              background: active ? 'var(--card-bg)' : undefined,
              boxShadow: active ? '0 8px 24px rgba(0,0,0,.4)' : undefined,
              borderRadius: active ? 14 : 0,
            }}
          >
            <button
              className="ticon touch-none p-1"
              aria-label="اسحب لإعادة الترتيب"
              onPointerDown={(e) => begin(e, i)}
              onPointerMove={move}
              onPointerUp={end}
              onPointerCancel={end}
            >
              <GripVertical size={20} />
            </button>
            <div className="min-w-0 flex-1">{render(id)}</div>
          </div>
        );
      })}
    </div>
  );
}
