ضع ملفات الأذان هنا (mp3 أو ogg) بالأسماء المعرّفة في src/config/adhanSounds.ts:

  afasy.mp3    مشاري العفاسي
  makkah.mp3   الحرم المكي
  madinah.mp3  الحرم المدني
  aqsa.mp3     المسجد الأقصى
  tobar.mp3    نصر الدين طوبار
  fajr.mp3     أذان الفجر (الصلاة خير من النوم)

لإضافة مؤذن جديد أو تبديل ملف: عدّل المصفوفة ADHAN_SOUNDS في ملف adhanSounds.ts فقط — بدون تعديل أي كود آخر.
