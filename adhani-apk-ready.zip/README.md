# أذاني — Adhani (Web / PWA build)

React + Vite + Tailwind. Offline prayer times (Adhan lib), full theme system, canvas widget editor.

## Run
    npm install
    npm run dev        # development
    npm run build      # outputs dist/index.html (single file)

## Adhan audio
Put mp3/ogg files in `public/sounds/` and edit `src/config/adhanSounds.ts` (name, path, isFajr).

## Structure
- `src/config`  – sounds list, cities, fonts, themes (ThemeState), settings defaults
- `src/lib`     – prayer calc, scheduler, audio, notifications, assets (IndexedDB), widget renderer
- `src/state`   – persisted stores (DataStore equivalent) + navigation
- `src/screens` – Home, Sounds, Settings, Appearance, WidgetEditor, Qibla, Tracker, Tasbih, Calendar…
- `src/ui`      – theme host, background, color picker, controls

## Web limits
A browser cannot fire the adhan while the app is fully closed (no AlarmManager / Foreground Service / BootReceiver),
cannot create real home-screen widgets, notification channels, or toggle system silent mode.
See the in-app screen "حدود تطبيق الويب".

## Android APK (GitHub Actions)
1. Put the adhan audio files in `public/sounds/` (afasy, makkah, madinah, aqsa, tobar, fajr — `.mp3`).
2. Push to GitHub → Actions → "Build Android APK" → download the `Adhani-APK` artifact.
3. The APK is fully offline: web app + fonts + audio are bundled; alarms are scheduled natively (AlarmManager).
